
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<!-- <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-620232d4edbccef1"></script> -->



<section class="subscribe-modal-popup" style="padding:0px;">
	<!-- Modal -->
	<div class="modal fade" id="subscribeModal" tabindex="-1" role="dialog" aria-labelledby="subscribeModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header-wrap">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true"><i class="icon icon-cross"></i></span>
					</button>
				</div>
				<div class="modal-body col-md-9 m-auto text-center">
					<?php if( get_field('subscription_form_heading', 'option') ): ?>
					<h5 class="modal-title mb-4 pb-2 px-1" id="subscribeModalLabel"><?php the_field('subscription_form_heading', 'option'); ?></h5>
					<?php endif; ?>
					<?php $form_short_code_pop = get_field('subscription_form_short_code', 'option');
					echo do_shortcode($form_short_code_pop); ?>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- End Subscibe -->

<footer class="footer-bottom bb-footer d-none d-md-block">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-3 footer-logo-sec-wrap footer-sec-col order-1 order-md-0">
				<div class="footer-sections">
					<?php if ( is_active_sidebar('footer-1' ) ) { ?>
						<?php
						dynamic_sidebar( 'footer-1' ); ?>
					<?php } ?>
				</div>
				<div class="foter-menu-title-menus-upper"><?php the_field('designed_by_text', 'option'); ?></div>
				<div class="foter-menu-title-menus"><a href="https://www.cara-consulting.sg/" target="_blank"><img src="<?php the_field('designed_by_image', 'option'); ?>" alt="Cara"><span  style="margin-left:14px;">Cara</span></a></div>
			</div>
			<div class="col-lg-3 col-md-3 footer-logo-sec-wrap  footer-sec-col">
				<div class="footer-sections">
					<?php if ( is_active_sidebar('footer-2' ) ) { ?>
						<?php
						dynamic_sidebar( 'footer-2' ); ?>
					<?php } ?>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 footer-logo-sec-wrap  footer-sec-col">
				<div class="footer-sections">
					<?php if ( is_active_sidebar('footer-3' ) ) { ?>
						<?php
						dynamic_sidebar( 'footer-3' ); ?>
					<?php } ?>
				</div>
			</div>
			<div class="col-lg-3 col-md-3 footer-logo-sec-wrap footer-sec-col">
				<div class="footer-sections">
					<?php if ( is_active_sidebar('footer-4' ) ) { ?>
						<?php
						dynamic_sidebar( 'footer-4' ); ?>
					<?php } ?>
				</div>	
			</div>
		</div>
    </div>
</footer>

<!-- Footer for Mobile Devices -->
<footer class="footer-bottom mobile-footer d-block d-md-none">
	<div class="container px-none">
		<div class="icon-section">
			<div class="row">
				<div class="col-4 pr-0">
					<a href="https://www.instagram.com/map_academy/?hl=en" target="_blank"><span class="facebook-share"><i class="icon icon-instagram"></i></span> Instagram</a>
				</div>
				<div class="col-4 pr-0">
					<a href="https://www.linkedin.com/company/museumofartandphotography" target="_blank"><span class="twitter-share"><i class="icon icon-linkedin"></i></span> LinkedIn</a>
				</div>
				<div class="col-4 pr-0">
					<a href="mailto:hellomapacademy@map-india.org?&subject=&cc=&bcc=&body=<?php the_title(); ?>&url=<?php the_permalink(); ?>;%0A" target="_blank"><span class="email-share"><i class="icon icon-mail"></i></span> Contact</a>
				</div>
			</div>
		</div>
	</div>
</footer>
<!-- desktop popup -->
<section class="desktop-popup">
	<div class="modal fade" id="desktop-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"> 
		<div class="modal-dialog modal-lg">    
			<div class="modal-content">      	
					<div class="modal-body">
					<a target="_blank"href="https://mapacademy.io/academy/courses/textiles-from-the-indian-subcontinent-short-course/">
					<img src="http://mapacademy.io/wp-content/uploads/2022/10/sharp-mayank-mansingh-kaul-pop-up.jpg" alt="alternate popup" width="900px" height="auto">
					</a>
					<!-- <a href="https://mapacademy.io/academy/courses/textiles-from-the-indian-subcontinent-short-course/"><button type="button" class="follow-us btn" >Find out more</button></a> -->
					</div>      
			</div>
		</div>
	</div>
</section>
<!-- Subscribe Modal -->
<section class="instagram-pop">
<div class="modal fade" id="modal-subscribe" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
		<?php 
					$link = get_field('social_popup_link', 'option');
					if( $link ): 
						$link_url = $link['url'];
						$link_title = $link['title'];
						$link_target = $link['target'] ? $link['target'] : '_self';
						?> 
			<a id = "insta-follow" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>">
			<img src="<?php the_field('social_popup_image', 'option'); ?>" class="img-fluid" alt="">
			<!-- <div class="modal-header border-0">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel"></h4>
			</div> -->
			<div class="modal-body">
				<h1 class="text-center text-uppercase"><?php the_field('social_popup_heading', 'option'); ?></h1>
				<div class="row">
					<div class="col-sm-12">
						<p class="text-center"><?php the_field('social_popup_sub_heading', 'option'); ?></p>
					</div>
				</div>
				<div class="text-center">
						<span  class="follow-us" ><?php echo esc_html( $link_title ); ?></span>
					
				</div>
			</div>
					</a>
					<?php endif; ?>
		</div>

		<div class="d-flex justify-content-center mt-3"><button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true"><img src="<?= get_template_directory_uri() ?>/images/close-circle.svg"></span></button></div>
	</div>
</div>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>

<?php wp_footer(); ?>

<!-- jquery cookie plugin -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>

<script>
	$(window).ready (function () {
	setTimeout (function () {
		$ ('#modal-subscribe').modal ("show")
	}, 30000)
})	
$('#modal-subscribe').on('show.bs.modal', function (e) {
  if (window.innerWidth >= 700) {
  	return e.preventDefault();
  }
})

if (typeof $.cookie('modal_shown') === 'undefined'){ // no cookie

// popup to display
	$(window).ready (function () {
		setTimeout (function () {
			$ ('#desktop-modal').modal ("show")
		}, 1000)
	});
// avoid if device is mobile
	$('#desktop-modal').on('show.bs.modal', function (e) {
		if (window.innerWidth < 700) {
			return e.preventDefault();
		}
	});
	$("#desktop-modal").on("shown.bs.modal", function(){
		$('.modal-backdrop.show').css('opacity', '0.7');
	});
	$.cookie('modal_shown', 'yes', { expires: 1 }); // set cookie expiry to 1 day
} 
else { 
// popup will not be displayed
}
</script>

</body>
</html>