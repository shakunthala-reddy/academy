$(document).ready(function() {


    jQuery("input#adv_search").on("keyup", function (event) {
        var minval = jQuery('#adv_search').attr('minlength');
        if (this.value.length >= minval || this.value.length == null || this.value.length == '') {
            var searchtext = jQuery('#adv_search').val();
            var siteurl = WPURL.ajaxurl;
            jQuery.post(siteurl, {
                    action: 'get_adv_search',
                    search_text: searchtext,
                },
                function (data, status) {
                    //jQuery('.loading_img').hide();
                    jQuery('#search_listing').html(data);
                    jQuery('#search_listing').show();
                });
        }
    });
//for mobile
    jQuery("input#adv_searchmobile").on("keyup", function (event) {
        //alert(searchtext);
        var minval = jQuery('#adv_searchmobile').attr('minlength');


        if (this.value.length >= minval || this.value.length == null || this.value.length == '') {

            //jQuery('.loading_img').show();
            var searchtext = jQuery('#adv_searchmobile').val();
            //alert(searchtext);
            var siteurl = ajax_siteurl;

            jQuery.post(siteurl, {
                    action: 'get_adv_search',
                    search_text: searchtext,
                },
                function (data, status) {
                    //jQuery('.loading_img').hide();
                    jQuery('#search_listingmobile').html(data);

                });


        }
    });

    $('.hidden-menu').hide();
    $('#show-hidden-menus').click(function () {
        $('.hidden-menu').slideToggle("slow");
        $('.hidden-menu').show();
    });

    $('.third-button').on('click', function () {
        $('.animated-icon3').toggleClass('open');
    });
    $('.explore-drpdown').on('click', function () {
        $('.animated-icon3').removeClass('open');
    });
    $('.explore-drpdown').on('click', function () {
        $('#navbarSupportedContent22').removeClass('show');
    });


  /***************************************************/
    var searchtext = jQuery('#artw-one span').text();
    if (searchtext != "") {
        var siteurl = ajax_siteurl;

        jQuery.post(siteurl, {
                action: 'get_adv_searchpage',
                search_text: searchtext,
            },
            function (data, status) {
                //jQuery('.loading_img').hide();
                jQuery('#search_listingpage').html(data);
                if ($.trim(status) != '') {
                    jQuery(".countrest").empty();
                    jQuery(".counterresult").appendTo('.countrest');
                }
            });
    }
    // $(".sub-menu a").each(function(){
    //   $(this).removeAttr("href");
    // });
    $(document).ready(function () {
        jQuery(".countrest").empty();
        jQuery(".counterresult").appendTo('.countrest');
        var numberNotChecked = $('input:checkbox:checked').length;
        $("#filtercount").text(numberNotChecked);
    });

    $("#mobileapply").on("click", function () {
        $("body").css("background-color", "#fff");
        $("#overlay-filter").css("display", "none");
    });

});
