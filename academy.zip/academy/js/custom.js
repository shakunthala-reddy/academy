var page_article_desk = 1;
var currentscrollHeight = 0;
jQuery(function($) {
    $(window).on("scroll", function () {
        var post_id_article_desk = $('.activepost').val();
        //alert(post_id);
        const scrollHeight = $(document).height();
        const scrollPos = Math.floor($(window).height() + $(window).scrollTop());
        const isBottom = scrollHeight - 100 < scrollPos;
        if (isBottom && currentscrollHeight < scrollHeight) {
        var data = {
            'action': 'load_posts_by_ajax',
            'page_article_desk': page_article_desk,            
            'security': article.security,
            'post_id_article_desk': post_id_article_desk,
        };
  
        $.post(article.ajaxurl, data, function(response) {
            if($.trim(response) != '') {
                $('.blog-posts').append(response);
                page_article_desk++; 
            } else {
                $('.loadmore').hide();
            }
        });
        currentscrollHeight = scrollHeight;
        }

    });
});

