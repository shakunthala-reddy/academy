var page_blog_desk = 1;
var currentscrollHeight = 0;
jQuery(function($) {
    $(window).on("scroll", function () {
        var post_id_blog_desk = $('.activeblog').val();
        //alert(post_id);
        const scrollHeight = $(document).height();
        const scrollPos = Math.floor($(window).height() + $(window).scrollTop());
        const isBottom = scrollHeight - 1 <= scrollPos;
        if (isBottom && currentscrollHeight <= scrollHeight) {
        var data = {
            'action': 'load_blogs_by_ajax',
            'page_blog_desk': page_blog_desk,            
            'security': blog.security,
            'post_id_blog_desk': post_id_blog_desk,
        };
        
        $.post(blog.ajaxurl, data, function(response) {
            if($.trim(response) != '') {
                $('.posts-list').append(response);
                page_blog_desk++; 
            } else {
                $('.loadmore').hide();
            }
        });
        currentscrollHeight = scrollHeight;
        }

    });
});


/***************************************************/


