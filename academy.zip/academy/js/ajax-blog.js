
var scrolled = false;
function ajax_blog_call() {
    console.log(scrolled);
    console.log(runAjax);
    if (!scrolled) {
        scrolled = true;
        if (runAjax) {
            $('.loading').show();
            jQuery.ajax({
                type: 'POST',
                url: WP_URLS.ajaxurl,
                data: {
                    action: 'get_blogs',
                    security: WP_URLS.security,
                    currentPost: WP_URLS.current_post_id,
                    excludedArticlePosts: WP_URLS.excluded_article_posts,
                    excludedBlogPosts: WP_URLS.excluded_blog_posts,
                    counter: WP_URLS.counter,
                },
                success: function (data, status) {
                    $('.scroll-result').append(data);
                    $('.loading').hide();
                    scrolled = false;
                    // do the carousels after all the images have loaded
                    setTimeout(()=> {
                        carousel1Init();
                    carousel2Init();
                    carousel3Init();
                },200);
                }
            });
        }
    }
}


var currentscrollHeight = 0;

jQuery(function ($) {

    $(window).on("scroll", function () {

        const scrollHeight = $(document).height();
        const scrollPos = Math.floor($(window).height() + $(window).scrollTop());
        const isBottom = scrollHeight - 500 < scrollPos;
        if (isBottom && currentscrollHeight < scrollHeight) {
            console.log("sccc")

                ajax_blog_call();

            currentscrollHeight = scrollHeight;
        }
    });
});

