
var ppp = 4;
var page = 0; // What page we are on.
var runAjax = true;
var sorter = 'r';
var filterCounter = 0;
var site_url=WP_URLS.url;
var url = site_url+"/encyclopedia-search/";


function reset_call() {
    $(".result-add").html('');
    page = 0;
    runAjax = true;
    ajax_call();

}

function ajax_call() {
    if (runAjax) {
        $('.loading').show();
        var post_types = $("#post-types :input").serialize();
        var categories = $("#categories :input").serialize();
        var departments = $("#departments :input").serialize();
        var period = $("#period :input").serialize();
        var region = $("#region :input").serialize();
        var occupation = $("#occupation :input").serialize();
        var search_term = $("#adv_search").val();
        var offset = page * ppp;
        var ajaxurl = WP_URLS.ajaxurl;
        var url = site_url+"/encyclopedia-search/";

        var url_old      = window.location.href;


        if (search_term || post_types || categories || departments || period || region || occupation) {

            console.log("old"+url_old);
            console.log("new"+url);

            if(url_old != url){


                url=url_old;
            }
            else{
                url = url + "?";
            }

            if (search_term) {
                url = url + "result=" + search_term;
            }
            if (post_types) {
                url = url + "&" + post_types;
            }
            if (departments) {
                url = url + "&" + departments;
            }
            if (categories) {
                url = url + "&" + categories;
            }
            if (period) {
                url = url + "&" + period;
            }
            if (region) {
                url = url + "&" + region;
            }
            if (occupation) {
                url = url + "&" + occupation;
            }
        }
        window.history.pushState('', '', url);

        if (($(".filter-feedback").children().length > 0) && ($(".clear-all").children().length == 0)) {
            $(".filter-feedback").append(' <span class="sort-title  mr-3 clear-all "><a href="'+url+'"class="clear-allbtn">Clear all</a></span>');
        }

        $(".clear-all").appendTo(".filter-feedback");
        jQuery.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {
                action: 'get_adv_searchpagetag',
                security: WP_URLS.security,
                search_term: search_term,
                post_types: post_types,
                categories: categories,
                departments: departments,
                period: period,
                region: region,
                occupation: occupation,
                sort: sorter,
                offset: offset,
                ppp: ppp

            },
            success: function (data, status) {
                $('.loading').hide();
                $(".result-add").append(data.content);
                $(".result-count").html("(" + data.count + " results)");
                page++;
                if (!runAjax) {
                    $(".result-subbox:last .icon-box").css({"border-bottom": "none"});
                }

            }
        });
    }
}


ajax_call();

$(document).ready(function () {

    $('.result').bind('scroll', function(){
        if($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight){
            ajax_call();
        }
    });


    // When Filter is checked
    $(document).on("change", ".formInput", function () {
        var text = $(this).data("text");
        var value = $(this).val();
        var checked = $(this).is(":checked");

        // if the filter is checked then give feed back pills under the sorting dropdown. unchecked hide it
        if (checked) {
            $(".filter-feedback").append(
                '<span  class="sort-title  mr-3 " data-linker="' + value + '"> <span class="close-pill">  <img src="'+site_url+'/wp-content/themes/academy/images/close-icon.svg" class="mr-1" alt="close" ></span> <span >' + text + '</span> </span>'
            );
        }
        else {
            $('[data-linker="' + value + '"]').hide();
        }
        reset_call();
    });

//        Get result on sorting selection (Relevance, A-Z , Z-A , Time)
    $(".filter-sorting").change(function () {
        sorter = $(".filter-sorting").val();
        reset_call();
    });


    $(".mobi-filter-dropdown-elements .list-group-item").click(function () {
        sorter = $(this).val();
        $(".mobi-filter-dropdown-elements").hide();
        // console.log(sorter);
        reset_call();
    });


});


// When filter feedback pills are closed -> uncheck filters

$(document).on("click", ".filter-feedback .close-pill", function () {
    var dataLinker = $(this).parent().data("linker");
    $(this).parent().remove();
    $("#" + dataLinker).prop('checked', false);
    reset_call();

});

// When search term feed back pill is closed -> clear search text
$(document).on("click", ".filter-feedback .search-text", function () {
    $(this).parent().remove();
    $("#adv_search").val("");
    reset_call();
});



// Filter Dropdown (Hide and show filter options)

$(document).ready(function () {
    $(document).on("click", ".filter-dropdown", function () {
        $(this).siblings('.form-check').toggle();
    });
});




// Mobile Filter


$(document).ready(function () {
    if ($(window).width() < 768) {
        var html = $(".filter-elements").html();
        $(".append-block").html(html);
        fillCounter();
    }
    $(".mobi-filter-wrapper").hide();
});

$(window).bind('orientationchange', function (event) {
    location.reload(true);
});

$(".toggle-filter").click(function () {
    $(".mobi-filter-wrapper").toggle();
});

$(".reset-button").click(function () {
    window.location.href = url;
});

function fillCounter() {
    var totalChecked = 0;
    $(".mobi-filter input[type=checkbox]:checked").each(function () {
        totalChecked++;
    });
    // console.log(totalChecked);
    if (totalChecked > 0) {
        $(".filter-counter").show();
        $(".filter-counter").html(totalChecked);
    }
}

$(".apply-button").click(function () {
    $(".mobi-filter-wrapper").hide();
    fillCounter();
});

$(".mobi-filter-dropdown").click(function () {
    // console.log("asdf");
    $(".mobi-filter-dropdown-elements").toggle();
});

