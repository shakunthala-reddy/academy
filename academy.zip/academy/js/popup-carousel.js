console.log("popup-carouse.js initialised");

$(document).ready(function () {
    loadImageData();
});

function loadImageData() {
    console.log("Carousel Script Loaded");

    $('.article-post').on('click', '.slide-image', function(){
        console.log("Clicked");
        var id=$(this).closest('.article-post').attr('data-id');
        // alert(id);
        console.log("Image Clicked on article : "+id);
        //openSlider(id);


    });

}