jQuery(document).ready(function ($) {
    bioAdnFeed();
    icons();
    author_details();
    carousel1Init();
    carousel2Init();
    carousel3Init();
    newlatter_radion_text();
});

function bioAdnFeed() {
    $("body").on("click", ".bio", function () {
        var wrap_id = $(this).attr('data-wrap');
        var element = '#bio_wrap_' + wrap_id;
        console.log(element);
        $(element).toggle();
    });

    $("body").on("click", ".feed", function () {
        var wrap_id = $(this).attr('data-wrap');
        var element = '#feed_wrap_' + wrap_id;
        console.log(element);
        $(element).toggle();
    });
}
function icons() {
    //share icon
    $('.upload').on("mouseover", function () {
        $(this).addClass("active");
        $('.share-icons').css({
            "opacity": "1",
            "visibility": "visible"
        });
    });
    $('.share-icons').on("mouseleave", function () {
        $('.upload').removeClass("active");
        $('.share-icons').css({
            "opacity": "0",
            "visibility": "hidden"
        });
    });
    //bio


    //feed
    // $(".feed").click(function () {
    //     $(this).next().find(".feed_wrap").slideToggle("slow");
    // });
}

function author_details() {
    $("body").on("mouseover", ".author-profile", function () {
        $(this).addClass("active");
        var auth_icon_id = $(this).attr('data-wrap');
        var display_element = '#' + auth_icon_id;
        $(display_element).css({
            "opacity": "0",
            "visibility": "hidden",
            "display": "none"
        });
    });
    $("body").on("mouseleave", ".author-hover-details", function () {
        $('.author-profile').removeClass("active");
        $('.author-hover-details').css({
            "opacity": "0",
            "visibility": "hidden",
            "display": "none"
        });
    });
    //author
    // $('.author-profile').on("mouseover", function () {
    //     $('.author-hover-details').css({
    //         "opacity": "1",
    //         "display": "block",
    //         "overflow": "visible"
    //     });

    // });
    // $('.author-hover-details').on("mouseleave", function () {
    //     $('.author-hover-details').css({
    //         "opacity": "0",
    //         "display": "none",
    //         "overflow": "hidden"
    //     });
    // });
}

/*********************After Ajax Load***********************/
$(document).ajaxComplete(function () {
    icons();
    //CopyToClipboard();
    author_details();
    newlatter_radion_text();
});


function carousel1Init() {
    //Carousel Type 1 (Image right, Meta below)
    $('.article-post').find('.content-carousel.carousel-right-below-extended').each(function (i) {


        const slideOptions = {
            slidesToShow: 1,
            slidesToScroll: 1,
            prevArrow: $(".pp1"),
            nextArrow: $(".nn1"),

            fade: true,
            adaptiveHeight: false,
            centerMode: true,
            centerPadding: false,
            infinite: true,
            focusOnSelect: true
        };

        mainCarousel = $(this);
        //
        // mainCarousel.find('.slick-prev').addClass("pp1"+i);
        // mainCarousel.find('.slick-next').addClass("nn1"+i);


        if (!mainCarousel.hasClass('slick-initialized')) {
            articleWrap = mainCarousel.closest('.article-post');
            moveCarousel = mainCarousel.detach();


            mainCarousel.on('init', function () {
                articleWrap.find('.right-slider-location').prepend(moveCarousel);
            });

            mainCarousel.slick(slideOptions);
            mainCarousel.addClass('slick-initialized');
            $(window).trigger('resize');

            var intialBox = articleWrap.find('.initial-content-box .content-section');

            if (isEmpty(intialBox)) {
                console.log("first block empty");

                var moveContent = $(".added-by-right-slider .content-section").detach();
                $('.initial-content-box').html(moveContent);
                $('.initial-content-box').removeClass("initial-content-box");
            }

        }
    });
}

function isEmpty(el) {
    return !$.trim(el.html())
}


//Carousel Type 2 (Image Center, Meta left)
function carousel2Init() {
    $('.article-post').find('.content-carousel.carousel-left-content-image-full-extended').each(function (i) {
        let mainCarousel = $(this),
            articleWrap = mainCarousel.closest('.article-post'),
            metaCarousel = articleWrap.find('.carousel-left-content-image-full-extended-meta');

        // add a custom class to identify the sliders
        mainCarousel.addClass(`clcifes-carousel${i}`);
        metaCarousel.addClass(`clcifes-meta${i}`);

        const slideMainOptions = {
                slidesToShow: 1,
                slidesToScroll: 1,
                prevArrow: $(".pppp2"),
                nextArrow: $(".nnnn2"),
                fade: true,
                asNavFor: metaCarousel,
                centerMode: true,
                centerPadding: false,
                focusOnSelect: true,
                infinite: true,
                rows: 0
            },
            slideNavOptions = {
                slidesToShow: 1,
                slidesToScroll: 1,
                dots: false,
                infinite: true,
                fade: true,
                arrows: false,
                centerMode: false,
                focusOnSelect: true
            };

        if (!mainCarousel.hasClass('slick-initialized')) {
            mainCarousel.slick(slideMainOptions);
        }

        // $(window).on('load resize', function (e) {
        //     metaCarousel.on('init', function (event, slick) {
        //         // get position of the carousel from top
        //         var mainCarouselPos = mainCarousel.offset(),
        //             contentWrapPos = articleWrap.offset();
        //
        //         var yPos = mainCarouselPos.top - contentWrapPos.top - articleWrap.find('.entry-header').innerHeight() - 10;
        //
        //         metaCarousel.css({
        //             'position': 'absolute',
        //             'top': yPos,
        //         });
        //     });
        //
        //     var slider = metaCarousel.detach();
        //     articleWrap.find('.left-sidebar').append(slider);
        // });

        if (!metaCarousel.hasClass('slick-initialized')) {
            metaCarousel.slick(slideNavOptions);
            $(window).trigger('resize');
        }
    });
}

//Carousel Type 3 (Image Center, Meta right)
function carousel3Init() {
    $('.article-post').find('.content-carousel.carousel-center-extended').each(function (i) {
        var mainCarousel = $(this);
        var articleWrap = mainCarousel.closest('.article-post');
        var metaCarousel = articleWrap.find('.content-carousel.carousel-center-extended-meta');

        const slideMainOptions = {
                slidesToShow: 1,
                slidesToScroll: 1,
                prevArrow: "<button class='slick-prev'><span class='icon icon-arrow-left'></span></button>",
                nextArrow: "<button class='slick-next'><span class='icon icon-arrow-right'></span></button>",

                arrows: true,
                fade: true,
                asNavFor: metaCarousel,
                centerMode: true,
                centerPadding: false,
                focusOnSelect: true,
                infinite: true,

                rows: 0
            },
            slideNavOptions = {
                slidesToShow: 1,
                slidesToScroll: 1,
                dots: false,
                infinite: true,
                fade: true,
                arrows: false,
                centerMode: false,
                focusOnSelect: true
            };

        if (!mainCarousel.hasClass('slick-initialized')) {
            mainCarousel.slick(slideMainOptions);
        }


        if (!metaCarousel.hasClass('slick-initialized')) {
            metaCarousel.slick(slideNavOptions);


        }

    });


    //Coordinate system Type 3 (Image Center, Meta right)
    /* $(window).on('load', function() {
     $('.carousel-within-content').each(function (index, elem) {
     //Carousel
     var within_carousel = $('.carousel-within-content').offset();
     var within_carousel_x = within_carousel.left;
     var within_carousel_y = within_carousel.top;
     //Meta
     var right_section_id = $(elem).data('linking');
     var within_meta = $('#' + right_section_id).offset();
     $('#' + right_section_id).css({
     "position": "relative",
     "top": within_carousel_y - 640
     });
     });
     }).resize(); */
}

/************************end***************************/
/*************************Print()*****************************/
function print_this(idname) {
    var backup = document.body.innerHTML;
    var printindiv = document.getElementById(idname).innerHTML;
    document.body.innerHTML = printindiv;
    window.print();
    document.body.innerHTML = backup;
}
/******************Copy to clipboard*********************/
function CopyToClipboard(containerid) {
    if (document.selection) {
        var range = document.body.createTextRange();
        range.moveToElementText(document.getElementById(containerid));
        range.select().createTextRange();
        document.execCommand("copy");
    } else if (window.getSelection) {
        var range = document.createRange();
        range.selectNode(document.getElementById(containerid));
        window.getSelection().removeAllRanges(range);
        window.getSelection().addRange(range);
        document.execCommand("copy");
    }
    document.getElementById("custom-tooltip").style.display = "inline";
    setTimeout(function () {
        document.getElementById("custom-tooltip").style.display = "none";
    }, 1000);
}
/***************************************/
function newlatter_radion_text() {
    jQuery(document).ready(function () {
        jQuery('.subscribetonewsletter .wpcf7-list-item-label').html("Clicking submit means you agree to our <a href='https://mapeia.langoorqa.net/privacy-policy/' target='_blank'>Privacy Policy</a>");
        jQuery('.subscribetonewsletter2 .wpcf7-list-item-label').html("I have read and understood the <a href='https://mapeia.langoorqa.net/privacy-policy/' target='_blank'>Privacy Policy</a>");
    })
}