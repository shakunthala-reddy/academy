// do everything about the main menu

// explore menu toggle
$(document).on('click', '#exploreMenuToggler', function(e) {
  e.preventDefault;

  if ($('#navbarToggler').hasClass('show')) {
      // $('body').removeClass('no-overflow');
      $('#navbarToggler').removeClass('show');
      $('#mainMenu').removeClass('show');
  }

  $(this).toggleClass('show');
  $('#exploreMenu').toggleClass('show');
  // $('body').toggleClass('no-overflow');
});



// main menu toggle
$(document).on('click', '#navbarToggler', function(e) {
  e.preventDefault;

  if ($('#exploreMenuToggler').hasClass('show')) {
      $('body').removeClass('no-overflow');
      $('#exploreMenuToggler').removeClass('show');
      $('#exploreMenu').removeClass('show');
  }

  $(this).toggleClass('show');
  $('#mainMenu').toggleClass('show');
  // $('body').toggleClass('no-overflow');


});

// Hide Main Menu when clicked outside the menu dropdown
$('.nav-link').click(function(event) {

      if ($('#navbarToggler').hasClass('show')) {
          $('body').removeClass('no-overflow');
          $('#navbarToggler').removeClass('show');
          $('#mainMenu').removeClass('show');
      }

});

$('html').click(function(event) {
  if ($(event.target).closest('#mainMenu').length === 0 && $(event.target).closest('#navbarToggler').length === 0) {
      console.log("htmld");
      if ($('#navbarToggler').hasClass('show')) {
          $('body').removeClass('no-overflow');
          $('#navbarToggler').removeClass('show');
          $('#mainMenu').removeClass('show');
      }
  }
});

// Responsive Search Toggle
$(document).on('click', '#searchToggler', function(e) {
  e.preventDefault;

  if ($('#navbarToggler').hasClass('show')) {
      // $('body').removeClass('no-overflow');
      $('#navbarToggler').removeClass('show');
      $('#mainMenu').removeClass('show');
  }

  $(this).toggleClass('show');
  $('#mobileSearch').addClass('show');
  // $('body').toggleClass('no-overflow');
});

$(document).on('click', '.clear-lable', function(e) {
  e.preventDefault;
  
  $('#mobileSearch').removeClass('show');
  // $('#adv_search').val('');
});

// fix the width of the search bar based on the dummy .col-md-6
$(window).on('load', function(e) {
  var dummyCol = $('header .dummy-container').find('.col-md-6');

  $('header').find('.center-section').css({
      'float': 'none !important',
      'width': dummyCol.width()
  });
}).resize();

/*subscribe form functionality*/
$(document).ready(function(){
  $('#subscribe').click(function() {
      setTimeout(function(){  
          if($("form").hasClass("sent"))
           {
          $(".wpcf7-response-output").prepend("<div class='blue-round-back'><span id='tick-mark'></span></div>")
           }
          }, 4000);
  });
  });
   
  $(document).ready(function(){
  $('#subscribe').click(function() {
    setTimeout(function(){  
      if($("form").hasClass("sent"))
     {
    $(".wpcf7-response-output").append("<div class='sub-sub-cont'></div>")
     $(".form-group.col-md-12").attr("style","display: none !important");
     $("#subscribeModalLabel").attr("style","display: none !important");
     $("input.wpcf7-form-control.has-spinner.wpcf7-submit, .modal-footer-wrap, span.wpcf7-list-item-label, span.wpcf7-form-control-wrap").attr("style","display: none !important");
     $(".wpcf7-response-output").attr("style","display: block !important");        
     }
    }, 4000);
  });
  
  });
  /* side menu active links */
  $(document).ready(function(){
    function isVisible($el) {
      var winTop = $(window).scrollTop();
      var winBottom = winTop + $(window).height();
      var elTop = $el.offset().top;
      var elBottom = elTop + $el.height();

      return ((elBottom<= winBottom) && (elTop >= winTop));
    }
    $(function() {
     
      $(window).scroll(function() {
        var isfound = 0;
        $('h2[id]').each(function () {
          var hid = $(this).attr('id');
      if(isVisible($("#"+hid)) && (isfound == 0))
        {
            //alert(abc);
         $('a').removeClass('active');
         $('a[href="#'+hid+'"]').addClass('active');
         isfound = 1;
        }
      });
   });
    });
  });

  /*active links if ts in span*/
  $(document).ready(function(){
      function isVisiblespan($el) {
        var winTop = $(window).scrollTop();
        var winBottom = winTop + $(window).height();
        var elTop = $el.offset().top;
        var elBottom = elTop + $el.height();
     // alert(winTop);
        if (winTop == 0)
        {
          $('a').removeClass('active');
        $('a[href="#terms-and-conditions"]').addClass('active'); 
        $('a[href="#privacy-policy"]').addClass('active'); 
        $('a[href="#what-is-art-history"]').addClass('active'); 
        $('a[href="#about-us"]').addClass('active'); 
        $('a[href="#cookies-policy"]').addClass('active'); 
        
        }
        return ((elBottom<= winBottom) && (elTop >= winTop));
       
      }
      $(function() {
      
        $(window).scroll(function() {
          var isfound = 0;
          $('span[id]').each(function () {
            var sid = $(this).attr('id');
           
        if(isVisiblespan($("#"+sid)) && (isfound == 0))
          {
           $('a').removeClass('active');
           $('a[href="#'+sid+'"]').addClass('active');
           isfound = 1;
          }
        
        });
     });
      });
    });