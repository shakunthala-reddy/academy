var scrolled = false;
function ajax_article_call() {
    console.log(scrolled);
    console.log(runAjax);
    if (!scrolled) {
        scrolled = true;
        if (runAjax) {
            console.log("Ajax called");
            $('.loading').show();
            jQuery.ajax({
                type: 'POST',
                url: WP_URLS.ajaxurl,
                data: {
                    action: 'get_articles',
                    security: WP_URLS.security,
                    currentPost: WP_URLS.current_post_id,
                    excludedArticlePosts: WP_URLS.excluded_article_posts,
                    excludedClusterPosts: WP_URLS.excluded_cluster_posts,
                    excludedBlogPosts: WP_URLS.excluded_blog_posts,
                    taxQuery: WP_URLS.tax_query,
                    counter: WP_URLS.counter,
                    blogOrCluster: WP_URLS.blogOrCluster,
                },
                success: function (data, status) {

                    console.log("data loaded");
                    scrolled = false;
                    // console.log(WP_URLS.excluded_posts);
                    // $('.article-result').append(data.content);
                    $('.article-post').removeClass('article-post-new');
                    $('.article-result').append(data);
                    $('.loading').hide();

                    // do the carousels after all the images have loaded
                    setTimeout(()=> {

                    carousel1Init();
                    carousel2Init();
                    carousel3Init();
                    $('.article-post').css("visibility","visible");

                    glossaryTooltip();
                    glossaryTooltipmobile();
                    cfTitleFetch();
                    loadImageData();
                    },200);

                }
            });
        }
        $('.article-post').css("visibility","visible");
    }
}

var currentscrollHeight = 0;

jQuery(function ($) {

    $(window).on("scroll", function () {
        if(WP_URLS.counter < 3) {


            // console.log("Scroll Detected");
            const scrollHeight = $(document).height();
            const scrollPos = Math.floor($(window).height() + $(window).scrollTop());
            const isBottom = (scrollHeight - 800) < scrollPos;

            if (isBottom) {
                console.log("condition pass");
                console.log("boottom" + isBottom);
                console.log("current height" + currentscrollHeight);
                console.log("scrollHeightt" + scrollHeight);
                console.log("scrollPos" + scrollPos);

                ajax_article_call();
                $('.article-post').css("visibility", "visible");
                currentscrollHeight = scrollHeight;
            }
        }
    });
});

// version-3
function copyToClipboard(element) {
    var text = $(element).clone().find('br').prepend('\r\n').end().text();
    text = text.replace(/\[mapeiacarousel id=[0-9]+\]/gi, '');
    text = text.replace(/\%newline\%/gi, '\r\n');
    element = $('<textarea>').appendTo('body').val(text).select();
    // console.log(text);
    // window.alert("Copied to ClipBoard!");
    document.execCommand('copy');
    element.remove();
    // a message display for copy
    $('#copy-message').css({"display" : "inline-block"})
    setTimeout(function() {
        //your code to be executed after 1 second
        $('#copy-message').css({"display" : "none"})
    }, 1000);
}