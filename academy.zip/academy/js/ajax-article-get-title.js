function cfTitleFetch () {
        $("body").on("click", ".feed", function () {
        var artpostid = $(this).attr('data-wrap');
        //alert(artpostid);
        jQuery.ajax({
            type: 'POST',
            url: WP_URLS.ajaxurl,
            data: {
                action: 'get_artile_title',
                security: WP_URLS.security,
                artpostid: artpostid
            },
            success: function (data, status) {
                console.log(data.content);
                $('#cfposttitle').val(data.content);
            }

        });
       
    });
}

$(document).ready(function () {
    cfTitleFetch ()
 })