var page = 1;
var currentscrollHeight = 0;
jQuery(function($) {
    $(window).on("scroll", function () {
        var post_id = $('.activeblogmobile').val();
        //alert(post_id);
        const scrollHeight = $(document).height();
        const scrollPos = Math.floor($(window).height() + $(window).scrollTop());
        const isBottom = scrollHeight - 1 <= scrollPos;
        if (isBottom && currentscrollHeight <= scrollHeight) {
        var data = {
            'action': 'load_blogs_mobile_by_ajax',
            'page': page,
            'security': blogmobile.security,
            'post_id': post_id,
        };
  
        $.post(blogmobile.ajaxurl, data, function(response) {
            if($.trim(response) != '') {
                $('.posts-list-mobile').append(response);
                page++; 
            } else {
                $('.loadmore').hide();
            }
        });
        currentscrollHeight = scrollHeight;
        }

    });
});


/***************************************************/


