function glossaryTooltip() {
    $('.glossary-link').on("mouseover", function () {
        console.log('mousehoverd');
        var glossarylink = $(this).attr('href');
        gllink = $(this);
        //console.log(glossarylink);
        //alert(glossarylink);
        jQuery.ajax({
            type: 'POST',
            url: WP_URLS.ajaxurl,
            data: {
                action: 'get_glossary_details',
                security: WP_URLS.security,
                glossarylink: glossarylink
            },
            success: function (data, status) {
                //console.log(data);
                //gllink.after("<span class='hide'>"+data+"</span>");   
                gllink.attr('data-title', data.content);
                gllink.attr('data-toggle', 'tooltip');
                gllink.attr('data-placement', 'bottom');
                gllink.attr('data-html', 'true');
                $('[data-toggle="tooltip"]').tooltip();
                if ($('.glossary-link:hover').length != 0) {
                    gllink.tooltip('show');
                }
            }

        });
    });
}

/*for mobile and tab*/
function glossaryTooltipmobile() {
    /* $(".glossary-link").on('touchstart touchend', function(e) {

     var glossarylink = $(this).attr('href');
     gllink = $(this);
     e.preventDefault();
     jQuery.ajax({
     type: 'POST',
     url: WP_URLS.ajaxurl,
     data: {
     action: 'get_glossary_details',
     security: WP_URLS.security,
     glossarylink: glossarylink
     },
     success: function (data, status) {
     console.log(data);

     //gllink.after("<span class='hide'>"+data+"</span>");
     gllink.attr('data-title', data);
     gllink.attr('data-toggle', 'tooltip');
     gllink.attr('data-placement', 'bottom');
     gllink.attr('data-html', 'true');
     $('[data-toggle="tooltip"]').tooltip();

     }

     });
     });*/
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        $('.glossary-link').click(function (e) {
            var clicks = $(this).data('clicks');
            if (clicks) {
                //gllink = $(this);
                //alert(clicks);
                console.log(clicks);
                //console.log('even');
                //gllink.removeAttr('data-toggle', 'tooltip');
            }
            else {
                //console.log('odd');
                var glossarylink = $(this).attr('href');
                gllink = $(this);
                e.preventDefault();
                jQuery.ajax({
                    type: 'POST',
                    url: WP_URLS.ajaxurl,
                    data: {
                        action: 'get_glossary_details',
                        security: WP_URLS.security,
                        glossarylink: glossarylink
                    },
                    success: function (data, status) {
                        console.log(data.content);

                        //gllink.after("<span class='hide'>"+data+"</span>");
                        gllink.attr('data-title', data.content);
                        gllink.attr('data-toggle', 'tooltip');
                        gllink.attr('data-placement', 'bottom');
                        gllink.attr('data-html', 'true');
                        $('[data-toggle="tooltip"]').tooltip();
                        $('.glossary-link').tooltip('hide');
                        gllink.tooltip('show');

                    }

                });
            }
            $(this).data("clicks", !clicks);
        });
    }
}


$(document).ready(function () {
    glossaryTooltip();
    glossaryTooltipmobile();

})



