<!DOCTYPE html>
<html 
<?php $lang_toggle = get_field('is_hindi') ?>

<?php 
if($lang_toggle){
echo 'lang="hi-IN"';
}else{
echo 'lang="en-US"';
} 
?>

>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#126BBF">
    <link rel="shortcut icon" href="<?php the_field('favicon', 'option'); ?>" type="image/x-icon">
    <!-- GTM Updated -->
    <!-- Google Tag Manager -->
    <script>(function (w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(), event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-KHHK29T');</script>
    <!-- End Google Tag Manager -->

    <?php wp_head(); ?>
    <script src="<?=get_template_directory_uri()?>/popup/openseadragon.js"></script>
</head>
<body <?php body_class(); ?> id="overchal">

<!-- Google Tag Manager (noscript) -->
<noscript>
    <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KHHK29T"
            height="0" width="0" style="display:none;visibility:hidden"></iframe>
</noscript>
<!-- End Google Tag Manager (noscript) -->

<header>
    <?php get_template_part('template-parts/header/main-nav'); ?>
    <?php //get_template_part('template-parts/header/nav-container-test'); ?>
</header>