<?php

add_action('wp_ajax_nopriv_get_artile_title', 'get_artile_title');
add_action('wp_ajax_get_artile_title', 'get_artile_title');

function get_artile_title()
{
    
    $post_id = $_POST['artpostid'];
    $post_content =  get_the_title($post_id);   
    ob_start();
    $response = array("content" => $post_content);
    ob_end_clean();
    wp_send_json($response);
    die();
}

