<?php


add_action('wp_ajax_nopriv_get_articles', 'get_articles');
add_action('wp_ajax_get_articles', 'get_articles');

/**
 *
 */
function get_articles()
{

    $currentPost = $_POST['currentPost'];
    $excludedArticlePosts = $_POST['excludedArticlePosts'];

    $tax_query[] = $_POST['taxQuery'];


    $args = array(
        'post_type' => 'article',
        'ignore_sticky_posts' => 1,
        'post_status' => 'publish',
        'post__not_in' => $excludedArticlePosts,
        'posts_per_page' => 1,
        'tax_query' => $tax_query,
    );

    $query = new WP_Query($args);
    $count = $query->found_posts;
    while($count==0){
        ?>
<script>
    console.log("No Posts Found");
</script>
<?php
//        echo "<h1>Count 0</h1>";
        $tax='department';
        $terms = get_the_terms($excludedArticlePosts[array_rand($excludedArticlePosts)], $tax);
        shuffle($terms);

        $term_slug = $terms[0]->slug;
        $tax_query = [
            'taxonomy' => $tax,
            'field' => 'slug',
            'terms' => $term_slug
        ];
        $args = array(
            'post_type' => 'article',
            'ignore_sticky_posts' => 1,
            'post_status' => 'publish',
            'post__not_in' => $excludedArticlePosts,
            'posts_per_page' => 1,
            'tax_query' => $tax_query,
        );
        $query = new WP_Query($args);
        $count = $query->found_posts;

    }

//    ob_start();
    get_template_part('/template-parts/article/result-articles', null, $args);
//    $response = array("content" => ob_get_contents());
//    ob_end_clean();
//    wp_send_json($response);
    die();
}
