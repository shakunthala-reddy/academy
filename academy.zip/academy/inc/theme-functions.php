<?php
// quick image path inside the theme
function theme_image($name) {
    $path = get_bloginfo('template_directory') . '/images/' . $name;
    return $path;
}