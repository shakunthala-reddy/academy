<?php
function framework_scripts()
{

    $path = get_template_directory_uri();
    $version="1.0.6";
    // Load site libs js files in footer
    //wp_deregister_script('bootstrap'); // to prevent clash with plugins calling bootstrap

    // Adding scripts file in the footer
    wp_enqueue_script('tolltip', 'https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js', array(), $version, true);
    wp_enqueue_script('mapeia-jquery', '//ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js', array(), $version, false);
    wp_enqueue_script('bootstrap4', '//maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', array(), $version, true);
    wp_enqueue_script('pooper', '//cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js', array(), $version, true);
    wp_enqueue_script('mapeia-owl', $path . '/js/owlcarousel_js/owl.carousel.min.js', array(), $version, true);
    wp_enqueue_script('mapeia-slick', '//cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js', array(), $version, true);
    wp_enqueue_script('mapeia-imagesloaded', '//unpkg.com/imagesloaded@5/imagesloaded.pkgd.js', array(), $version, true);
    wp_enqueue_script('mapeia-main', $path . '/js/main-js.js', array(), $version, true);
//    wp_enqueue_script('mapeia-scroll', $path . '/js/scrollpagination.js', array(), $version, false);
//    wp_enqueue_script('mapeia-waypoints', $path . '/js/jquery.waypoints.min.js', array(), $version, false);
//    wp_enqueue_script('mapeia-waypoints-infinite', $path . '/js/infinite.min.js', array(), $version, false);
    wp_enqueue_script('mapeia-customize', $path . '/js/customize.js', array(), $version, true);
    wp_enqueue_script('mapeia-main-menu', $path . '/js/main-menu.js', array(), $version, true);
    wp_enqueue_script('mapeia-hotspot', $path . '/js/image-hotspot.js', array(), $version, true);
    wp_enqueue_script('mapeia-animation', 'https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js', array(), $version, true);
  

//    if (is_page_template('page-templates/page-search.php')) {
//        wp_enqueue_script('mapeia-search-ajax', $path . '/js/ajax-search.js', array(), $version, false );
//        wp_localize_script('mapeia-search-ajax', 'WP_URLS', array(
//            'ajaxurl'   => admin_url('admin-ajax.php'),
//            'security' => wp_create_nonce( 'load_more_posts' ),
//            'url'=>site_url()
//        ));
//    }

    wp_localize_script('mapeia-main', 'WPURL', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
    ));

    if (is_singular('article')) {
        wp_enqueue_script('mapeia-aricle-ajax', $path . '/js/ajax-article.js', array('mapeia-jquery'), $version, false);
        wp_localize_script('mapeia-aricle-ajax', 'WP_URLS', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'security' => wp_create_nonce('load_more_posts'),
            'excluded_article_posts' => [],
            'imageinfo'=>[]
        ));

        wp_enqueue_script('mapeia-popup-carousel', get_stylesheet_directory_uri().'/popup/js/myscript.js', array('mapeia-jquery'), $version, false);
        wp_localize_script('mapeia-popup-carousel', 'WP_URLS', array(
            'imageinfo'=>[]
        ));
    }

    if (is_singular('post')) {
        wp_enqueue_script('mapeia-blog-ajax', $path . '/js/ajax-blog.js', array(), $version, false);
        wp_localize_script('mapeia-blog-ajax', 'WP_URLS', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'security' => wp_create_nonce('load_more_posts'),
            'excluded_article_posts' => []
        ));
    }

    if (is_singular('glossary')) {
        wp_enqueue_script('mapeia-blog-ajax', $path . '/js/ajax-glossary.js', array(), $version, false);
        wp_localize_script('mapeia-blog-ajax', 'WP_URLS', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'security' => wp_create_nonce('load_more_posts'),
            'excluded_article_posts' => []
        ));
    }

    if (is_singular('article')) {
        wp_enqueue_script('mapeia-glassray-pop', $path . '/js/ajax-glossary-popup.js', array('mapeia-jquery'), $version, false);
        wp_localize_script('mapeia-glassray-pop', 'WP_URLS', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'security' => wp_create_nonce('load_more_posts')
        ));
    }

    if (is_singular('article')) {
        wp_enqueue_script('mapeia-article-title', $path . '/js/ajax-article-get-title.js', array('mapeia-jquery'), $version, false);
        wp_localize_script('mapeia-article-title', 'WP_URLS', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'security' => wp_create_nonce('load_more_posts')
        ));
    }

}

add_action('wp_enqueue_scripts', 'framework_scripts', 1000);


function framework_styles()
{
    global $wp_styles; // Call global $wp_styles variable to add conditional wrapper around ie stylesheet the WordPress way
    $path = get_template_directory_uri();
    $version="1.0.1";
    // libraries
    wp_enqueue_style('mapeiacss-bootstrap', '//maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css', array(), $version);
    wp_enqueue_style('mapeiacss-owl', $path . '/css/owlcarousel_styles/owl.carousel.min.css', array(), $version);
    wp_enqueue_style('mapeiacss-owl-theme', $path . '/css/owlcarousel_styles/owl.theme.default.min.css', array(), $version);
    wp_enqueue_style('mapeiacss-slick', '//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css', array(), $version);



    // Register Custom Font
    // wp_enqueue_style('site-font', '//fonts.googleapis.com/css?family=Montserrat:400,700|Roboto:300&display=swap', '', '');

    // Register main stylesheet
    wp_enqueue_style('site-fontawesome', '//use.fontawesome.com/releases/v5.5.0/css/all.css', array(), '', 'all');
    // wp_enqueue_style('site-css', $path . '/assets/css/app.min.css', array(), '', 'all');

    wp_enqueue_style('mapeiacss-main', $path . '/css/main-style.css', array(), $version);
    wp_enqueue_style('mapeiacss-style-css', $path . '/css/style-css.css', array(), $version);
    wp_enqueue_style('mapeiacss-style-css', $path . '/css/style-css.css', array(), $version);
    wp_enqueue_style('mapeiacss-search', $path . '/css/search.css', array(), $version);
    wp_enqueue_style('eia-custom-icon', $path . '/custom-fonts/eia-icons.css', '', time(), '');
    wp_enqueue_style('custom-font', $path . '/custom-fonts/custom-font.css', '', time(), '');
    wp_enqueue_style('mapeiacss-style', get_stylesheet_uri());
}

add_action('wp_enqueue_scripts', 'framework_styles', 1000);



add_action('wp_enqueue_scripts', 'tutsplus_enqueue_custom_js');

function tutsplus_enqueue_custom_js() {
    wp_enqueue_style('custom', get_stylesheet_directory_uri().'/popup/css/mycss.css', array(), 1.2);
//    wp_enqueue_script('custom', get_stylesheet_directory_uri().'/popup/js/myscript.js', 'in_footer');
}