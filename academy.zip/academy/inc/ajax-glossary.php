<?php


add_action('wp_ajax_nopriv_get_glossary', 'get_glossary');
add_action('wp_ajax_get_glossary', 'get_glossary');

function get_glossary()
{

    $excludedBlogPosts = $_POST['excludedBlogPosts'];



    $args = array(
        'post_type' => 'glossary',
        'ignore_sticky_posts' => 1,
        'post_status' => 'publish',
        'post__not_in' => $excludedBlogPosts,
        'posts_per_page' => 1,
        'orderby' => 'title',
        'order'   => 'ASC',

    );


//    ob_start();
    get_template_part('/template-parts/glossary/result-glossary', null, $args);
//    $response = array("content" => ob_get_contents());
//    ob_end_clean();
//    wp_send_json($response);
    die();
}
