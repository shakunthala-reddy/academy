<?php

add_action('wp_ajax_nopriv_get_glossary_details', 'get_glossary_details');
add_action('wp_ajax_get_glossary_details', 'get_glossary_details');

function get_glossary_details()
{
    
    $link = $_POST['glossarylink'];
    $post_id = url_to_postid($link);
    $post_12 = get_post($post_id); 
    $post_content = $post_12->post_content;
    if (strlen($post_content) > 350) {
    $post_content =  substr($post_content, 0, 350) . "... " . substr($post_content);
    }
    //$post_content = wp_trim_words( $post_content, 50, '...' );
  
    ob_start();
    $response = array("content" => $post_content);
    ob_end_clean();
    wp_send_json($response);
    die();
}
?>
