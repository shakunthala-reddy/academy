<?php

add_action('wp_ajax_nopriv_get_adv_searchpagetag', 'get_adv_searchpagetag');
add_action('wp_ajax_get_adv_searchpagetag', 'get_adv_searchpagetag');


function get_array($inputQuery)
{
    $query = explode('&', $inputQuery);
    $params = array();

    foreach ($query as $param) {
        if (strpos($param, '=') === false) $param += '=';

        list($name, $value) = explode('=', $param, 2);
        $params[urldecode($name)][] = urldecode($value);
    }
    $array = $params[$name];

    foreach ($array as $key => $value) {
        if (empty($value)) {
            unset($array[$key]);
        }
    }

    return $array;
}

$postCount = 0;
function get_adv_searchpagetag()
{
    global $wpdb;
    global $postCount;

    $search_term = $_REQUEST['search_term'];

    $postTypes = $_REQUEST['post_types'];
    $postTypes_a = get_array($postTypes);

    $categories = $_REQUEST['categories'];
    $categories_a = get_array($categories);


    $departments = $_REQUEST['departments'];
    $departments_a = get_array($departments);


    $period = $_REQUEST['period'];
    $period_a = get_array($period);

    $region = $_REQUEST['region'];
    $region_a = get_array($region);

    $occupation = $_REQUEST['occupation'];
    $occupation_a = get_array($occupation);

    $sort = $_REQUEST['sort'];
    $offset = $_REQUEST["offset"];
    $ppp = $_REQUEST["ppp"];


    if (!empty($postTypes_a)) {

//        if (in_array("article", $postTypes_a)){
//            array_push($postTypes_a, 'glossary');
//        }
        $post_types_query = $postTypes_a;
    } else {
        $post_types_query = array('post', 'article', 'glossary', 'cluster');
//        $post_types_query = array('article', 'glossary', 'cluster');
    }

    $tax_query = array('relation' => 'AND');
    if (!empty($categories_a)) {
        $tax_query[] = array(
            'taxonomy' => 'custom_category',
            'field' => 'slug',
            'terms' => $categories_a
        );
    }
    if (!empty($departments_a)) {
        $tax_query[] = array(
            'taxonomy' => 'department',
            'field' => 'slug',
            'terms' => $departments_a
        );
    }

    if (!empty($period_a)) {
        $tax_query[] = array(
            'taxonomy' => 'period',
            'field' => 'slug',
            'terms' => $period_a
        );
    }

    if (!empty($region_a)) {
        $tax_query[] = array(
            'taxonomy' => 'region',
            'field' => 'slug',
            'terms' => $region_a
        );
    }

    if (!empty($occupation_a)) {
        $tax_query[] = array(
            'taxonomy' => 'occupation',
            'field' => 'slug',
            'terms' => $occupation_a
        );
    }

    if ($sort == 'r') {


    }

    if ($sort == 'a') {
        $orderby = array(
            'title' => 'ASC',
        );
    }
    if ($sort == 'z') {
        $orderby = array(
            'title' => 'DESC',
        );
    }

    if ($sort == 't') {
        $orderby = array(
            'date' => 'ASC',
        );
    }


    // Query to get number of posts
    $args = array(
        'post_type' => $post_types_query,
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'tax_query' => $tax_query,
        's' => $search_term,
//        'orderby' => $orderby,
    );
    $getAllPosts = new WP_Query($args);
    $postCount = $getAllPosts->post_count;


    $args = array(
        'post_type' => $post_types_query,
        'post_status' => 'publish',
        'tax_query' => $tax_query,
        's' => $search_term,
        'orderby' => $orderby,
        'posts_per_page' => $ppp,
        'offset' => $offset,
    );
    get_results($args);
}


function get_results($args)
{
    global $postCount;
    ob_start();
    get_template_part('/template-parts/search/result-thumb', null, $args);
    $response = array("content" => ob_get_contents(), "count" => $postCount);
    ob_end_clean();
    wp_send_json($response);
    die();
}