<?php
add_action('wp_ajax_nopriv_get_adv_search', 'get_adv_search');
add_action('wp_ajax_get_adv_search', 'get_adv_search');

function get_adv_search()
{
    global $wpdb;

    $search_text = htmlspecialchars($_POST['search_text'], ENT_QUOTES, 'UTF-8');
    if (!empty($search_text)) {
        $search_results = $wpdb->get_results("SELECT DISTINCT wp_posts.ID , wp_posts.post_type from wp_posts join wp_postmeta on wp_posts.ID = wp_postmeta.post_id where (((wp_postmeta.meta_key = 'bibliography') AND wp_postmeta.meta_value like '%" . $search_text . "%') OR (wp_posts.post_title like '%" . $search_text . "%')) AND (wp_posts.post_status = 'publish' AND wp_posts.post_type IN ('article', 'post', 'glossary' ,'cluster'))", ARRAY_A);

                if (!empty($search_results)) {
            ?>
            <div class="psuedo-cover"></div>
            <div class="autocomplete-wrapper">
            <div class="search-box-sec">
            <?php

            $post_types_query = array('post', 'article', 'glossary', 'cluster');
            $args = array(
                'post_type' => $post_types_query,
                'post_status' => 'publish',
                's' => $search_text,
                'posts_per_page' => 8,
            );
            $query = new WP_Query($args);
            if ($query->have_posts()) {
                while ($query->have_posts()) {
                    $query->the_post();
                    if (get_post_type( $post ) == "post") {
                        $posttype = "Blog";
                    } else {
                        $posttype = get_post_type( $post );
                    }
                    ?>
                    <li>
                        <a href="<?php echo get_permalink($post->ID); ?>"><?php echo get_the_title($post->ID); ?><span
                                    class="tag-name"><?php echo $posttype; ?></span></a></li>
                    <?php
                }
            }

                ?>


            </div></div>
            <?php
        } else { ?>
            <h5 class="noimagefound" align="center" style="width: 100%;">No Record Found</h5>
        <?php }
    } else {

    }
    die();
}

