<?php
/*
    core function partials for custom post types
    author: ajasra das    
*/

// add custom column to content carousel post type
add_filter('manage_edit-mapeia-carousel_columns', 'mapeia_set_carousel_cpt_columns');
function mapeia_set_carousel_cpt_columns($columns) {
    $title  = $columns['title'];
    $date   = $columns['date'];
    
    unset($columns['date']);

    $columns['shortcode']   = __('Shortcode', 'mapeia');
    $columns['date']        = $date;

    return $columns;
}

// add data to the custom column in content carousel post type
add_filter('manage_mapeia-carousel_posts_custom_column', 'mapeia_carousel_cpt_columns_data', 10, 2);
function mapeia_carousel_cpt_columns_data($column, $post_id) {
    switch ($column) :
        case 'shortcode':
            // print the shortcode to be copied
            $shortcode = "[mapeiacarousel id={$post_id}]";

            echo $shortcode;
            break;
        
    endswitch;
}
