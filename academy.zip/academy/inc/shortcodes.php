<?php
/* 
    custom shortcodes to be used in the theme
    author: ajasra das
*/


// content carousel
add_shortcode('mapeiacarousel', 'mapeiacarousel_callback');
function mapeiacarousel_callback($atts) {
    $post_id = $atts['id'];

    if ($post_id) :
        ob_start();
        // get the appropriate template part depending on the carousel style
        switch (get_field('carousel_style', $post_id)) :
            case 'right':
                get_template_part('template-parts/carousels/right', null, ['post_id' => $post_id]);
                break;
            case 'center':
                get_template_part('template-parts/carousels/center', null, ['post_id' => $post_id]);
                break;
            case 'center_ext':
                get_template_part('template-parts/carousels/center', 'ext', ['post_id' => $post_id]);
                break;
        endswitch;

        return ob_get_clean();
    else: 
        return false;
    endif;
}