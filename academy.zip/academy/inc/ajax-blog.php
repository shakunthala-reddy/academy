<?php


add_action('wp_ajax_nopriv_get_blogs', 'get_blogs');
add_action('wp_ajax_get_blogs', 'get_blogs');

function get_blogs()
{

    $excludedBlogPosts = $_POST['excludedBlogPosts'];



    $args = array(
        'post_type' => 'post',
        'ignore_sticky_posts' => 1,
        'post_status' => 'publish',
        'post__not_in' => $excludedBlogPosts,
        'posts_per_page' => 1,
        'orderby' => 'publish_date',
        'order' => 'ASC',

    );


//    ob_start();
    get_template_part('/template-parts/blog/result-blogs', null, $args);
//    $response = array("content" => ob_get_contents());
//    ob_end_clean();
//    wp_send_json($response);
    die();
}
