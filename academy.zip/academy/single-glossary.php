<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage MAPEIA
 * @since MAPEIA 1.0
 */
//test
get_header();

$excludedBlogPosts = [];
$excludedArticlePosts = [];

global $post;
$terms = get_the_terms($post->ID, 'glossary_cat');
$term = array_shift($terms);
$termsname = $term->slug;

?>
<div class="main-wrapper-div">
    <?php
    $current_post_id = get_the_ID();
    array_push($excludedBlogPosts, $current_post_id);

    ?>
    <style>
        :target {
            display: block;
            position: relative;
            top: -120px;
            /*visibility: hidden;*/
        }
    </style>

    <script>
        WP_URLS.current_post_id = <?=$current_post_id ?>;
        WP_URLS.excluded_article_posts = <?php echo json_encode($excludedArticlePosts);?>;
        WP_URLS.excluded_blog_posts = <?php echo json_encode($excludedBlogPosts);?>;
        WP_URLS.counter = 1;
        runAjax = true;
    </script>

    <!-- Glossary 1-->
    <?php while (have_posts()): the_post(); ?>
        <?php $post_id = get_the_ID(); ?>
        <?php $current_post_id = get_the_ID(); ?>
        <div class="container" id="p-<?php echo $current_post_id; ?>">
            <div class="row">
                <div class="col-lg-9 order-lg-2 px-none">
                    <div class="glossary-content-box">
                        <div class="w-100">
                            <h5 class="result-label-title">Glossary</h5>
                        </div>
                        <a class="black-link" href="<?php echo get_permalink() ?>"><h4><?php the_title(); ?></h4></a>
                        <div class="the-content">
                            <div class="row">
                                <div class="col-lg-4 order-lg-2  d-none d-lg-block">
                                    <?php
                                    if (get_the_post_thumbnail_url()) {
                                        $thumb_url = get_the_post_thumbnail_url($post_id, 'thumbnail');
                                    } else {
                                        $thumb_url = get_field('default_thumbnail', 'option');
                                    }
                                    ?>
                                    <img src="<?= $thumb_url ?>" class=" img-fluid" alt="<?php the_title(); ?>">
                                </div>
                                <div class="col-lg-8 order-lg-1 px-none fw-300">
                                    <?php the_content(); ?>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-lg-3 order-lg-1">
                    <aside class="left-sidebar">
                        <div class="author-details">
                            <div class="wrap-filed-info">
                                <p class="filed-under-lable">FILED UNDER</p>
                                <p class="under-listing">
                                    <?php
                                    $filed_taxterms = get_the_terms(get_the_ID(), 'department');
                                    foreach ($filed_taxterms as $filed_list) { ?>
                                        <a href="<?php echo home_url(); ?>/encyclopedia-search/?&department=<?php echo $filed_list->slug; ?>"><?php echo $filed_list->name;
                                            ?>
                                        </a>
                                    <?php } ?>
                                </p>
                            </div>
                        </div>
                        
                        <?php
                            get_template_part('/template-parts/social-icon/social-icon');
                        ?>


                    </aside>
                </div>

            </div>
            <div class="row">
                <!-- Desktop List View Alphabets-->
                <div class="col-lg-3 d-none d-lg-block">
                    <div class="alpha-index-block">
                        <?php
                        foreach (range('A', 'Z') as $char) {
                            ?>
                            <a href="#<?= $char ?>" class="alpha-index">
                            <span class="circle-bg">
                                <?= $char ?>
                            </span>
                            </a>
                            <?php
                        }
                        ?>
                    </div>
                </div>

                <!-- For Mobile Dropdown Alphabets -->
                <div class="col-lg-3 px-none d-block d-lg-none">
                    <div class="mt-4">
                        <div class="dropdown">
                            <a class="btn btn-light dropdown-toggle" href="javascript:void(0)" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-expanded="false">
                                Choose A-Z
                            </a>

                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <a class="dropdown-item" href="#A">A</a>
                                <a class="dropdown-item" href="#B">B</a>
                                <a class="dropdown-item" href="#C">C</a>
                                <a class="dropdown-item" href="#D">D</a>
                                <a class="dropdown-item" href="#E">E</a>
                                <a class="dropdown-item" href="#F">F</a>
                                <a class="dropdown-item" href="#G">G</a>
                                <a class="dropdown-item" href="#H">H</a>
                                <a class="dropdown-item" href="#I">I</a>
                                <a class="dropdown-item" href="#J">J</a>
                                <a class="dropdown-item" href="#K">K</a>
                                <a class="dropdown-item" href="#L">L</a>
                                <a class="dropdown-item" href="#M">M</a>
                                <a class="dropdown-item" href="#N">N</a>
                                <a class="dropdown-item" href="#O">O</a>
                                <a class="dropdown-item" href="#P">P</a>
                                <a class="dropdown-item" href="#Q">Q</a>
                                <a class="dropdown-item" href="#R">R</a>
                                <a class="dropdown-item" href="#S">S</a>
                                <a class="dropdown-item" href="#T">T</a>
                                <a class="dropdown-item" href="#U">U</a>
                                <a class="dropdown-item" href="#V">V</a>
                                <a class="dropdown-item" href="#W">W</a>
                                <a class="dropdown-item" href="#X">X</a>
                                <a class="dropdown-item" href="#Z">Z</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9 glossary-index px-none">
                    <?php
                    $doorOpen = 0;
                    foreach (range('A', 'Z') as $char) {
                        if ($doorOpen == 1) {
                            echo '</div>';
                        }
                        echo '<a id="' . $char . '"></a>';
                        echo '<div class="row group_letter">';
                        echo '<div class="col-12 letter" >' . $char . '</div>';
                        $args = array(
                            'post_type' => 'glossary',
                            'posts_per_page' => -1,
                            'search_prod_title' => $char,
                            'post_status' => 'publish',
                            'orderby' => 'title',
                            'order' => 'ASC'
                        );
                        $the_query = new WP_Query($args);
                        $count = $the_query->found_posts;
                        $sets = [];
                        if ($the_query->have_posts()) :
                            while ($the_query->have_posts()) : $the_query->the_post();
                                $title = get_the_title();
                                $initial = strtoupper(substr($title, 0, 1));
                                if ($initial == $char) {
                                    array_push($sets, get_the_ID());
                                }
                            endwhile;
                            wp_reset_postdata();
                        endif;

                        $countSets = count($sets);
                        // echo "ccc". ($countSets);
                        $colItemsCount = (int)($countSets / 3);
                        $counter = 0;
                        foreach ($sets as $i => $set) {
                            $counter++;
                            if ($counter == 1) {
                            // echo $doorOpen;

                                $doorOpen = 1;
                                echo '<div class="col-12 col-md-4">';
                            }
                            echo '<a href="' . get_the_permalink($set) . '" class="w-100 d-block glossary-index-title">' . get_the_title($set) . '</a>';
                            if ($counter == $colItemsCount + 1) {
                                echo '</div>';
                                $counter = 0;
                                $doorOpen = 0;
                            }
                        }
                        if($countSets!=0){
                        echo '</div>';
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    <?php endwhile; ?>
</div>

<?php get_footer(); ?>

