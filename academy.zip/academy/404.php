<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package profieldtech
 */

get_header();
?>

<div class="main-wrapper-div-404">
	<div class="content-section-404">
		<h1 class="page-heaing-404">404</h1>
		<h2 class="sorry-message">Sorry, the page you are looking for is not available</h2>
		<p class="btn-msg">Click the button below to return to the home page</p>
		<div class="divider-404"></div>
		<div class="home-btn">
			<a href="<?php echo home_url(); ?>" class="btn-home-link">Home</a>
		</div>
	</div>
</div>


<?php
get_footer();
