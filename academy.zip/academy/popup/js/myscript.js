function openSlider(val, src, imgId, siteUrl, highRes) {
    $('#myModal').modal('hide');
    $(".uwy").hide(); //hiding accessibility feature on this page
    $(".notice").hide();
    $("div[title|='Zoom in']").css('opacity', '1');
    $("div[title|='Zoom out']").css('opacity', '1');

    $("#appendBox").append("<div id='openseadragon1' class='openseadragon' style='width:100%;height:100vh;'></div>");
    $("#appendBoxSidebar").append("<div id='navigatorDiv1' class='navigatorDiv'></div>");

    $("#container #slider").html('');
    $("#catalogue-info").html('');


    var articleData = localStorage.getItem("postData");
    articleData = JSON.parse(articleData);

    $.each(articleData, function (index, keyValue) {
        $.each(keyValue.post, function (index1, keyValue1) {
            $.each(keyValue1.image, function (index2, keyValue2) {
                console.log("hi" + keyValue2.high_res_url);
                var urlImage;
                var highReso = 0;
                if (keyValue2.high_res_url != 0) {
                    urlImage = "'" + keyValue2.high_res_url + "'";
                    highReso = 1;
                }
                else {
                    urlImage = "'" + keyValue2.url + "'";
                    highReso = 0;
                }
                var htmlData = '<div class="slide"><img src="' + keyValue2.url + '" onclick="updateImage(' + index2 + ',' + urlImage + ',' + val + ',' + keyValue2.id + ',' + "'" + siteUrl + "'" + ',' + highReso + ')"></div>';

                if (val == keyValue1.postid) {
                    if (index2 == 0) {

                        console.log("before first image "+highRes);
                        firstImage(index2, src, val, imgId, siteUrl, highRes);
                    }

                    $("#container #slider").append(htmlData);
                }

            });
        });
    });

}

function disable_zoom() {
    $(".notice").show();
    $("div[title|='Zoom in']").css('opacity', '0.3');
    $("div[title|='Zoom out']").css('opacity', '0.3');
    viewer.navigator.element.style.display = "inline-block";
}

function enable_zoom() {
    $(".notice").hide();
    $("div[title|='Zoom in']").css('opacity', '1');
    $("div[title|='Zoom out']").css('opacity', '1');
}

function firstImage(val, src, id, imgId, siteUrl, highRes) {

    var mouse;
    var dzl=0.6;
    if(highRes==1){
        dzl=1.5;
        mouse=true;
    }else{
        dzl=0.8
        mouse=false;
    }

    viewer = OpenSeadragon({
        id: 'openseadragon1',
        prefixUrl: siteUrl + '/wp-content/themes/academy/popup/images/',
        tileSources: {
            type: 'image',
            url: src
        },
        showNavigator: true,
        navigatorAutoFade: false,
        showHomeControl: false,
        showFullPageControl: false,
        mouseNavEnabled: mouse,
        navigatorId: "navigatorDiv1",
        defaultZoomLevel: 0.55,
        maxZoomPixelRatio: 1,
        minZoomLevel: 0.3,
        autoHideControls: false,
        zoomPerClick:1.2,

    });

    $("#myModal, .modal-backdrop").show();
    $("body").addClass("modal-open");

    catelogue(val, src, id, imgId, highRes);
    console.log("fimage"+highRes);


}

function updateImage(val, src, id, imgId, siteUrl, highRes) {
    $(".openseadragon").remove();
    $("#appendBoxSidebar div").remove();
    $("#myModal, .modal-backdrop").show();

    $("#appendBox").append("<div id='openseadragon" + val + "' class='openseadragon' style='width:100%;height:100vh;'></div>");
    $("#appendBoxSidebar").append("<div id='navigatorDiv" + val + "' class='navigatorDiv'></div>");

    var dzl=0.6;
    var mouse;
    if(highRes==1){
        dzl=1;
        mouse=true;
    }else{
        dzl=0.6
        mouse=false;
    }
    viewer = OpenSeadragon({
        id: 'openseadragon' + val,
        prefixUrl: siteUrl + '/wp-content/themes/academy/popup/images/',
        tileSources: {
            type: 'image',
            url: src
        },
        showNavigator: true,
        showHomeControl: false,
        navigatorAutoFade: false,
        showFullPageControl: false,
        mouseNavEnabled: mouse,
        navigatorId: "navigatorDiv" + val,
        defaultZoomLevel: 0.4,
        maxZoomPixelRatio: 1,
        minZoomLevel: 0.3,
        autoHideControls: false,
        zoomPerClick:1.2,

    });

    catelogue(val, src, id, imgId, highRes);

    console.log("second image");
}

function catelogue(val, src, id, imgId, highRes) {
    /*-------update catelogue-------*/

    $("#catalogue-info").html('');

    var articleData = localStorage.getItem("postData");
    articleData = JSON.parse(articleData);

    $.each(articleData, function (index, keyValue) {
        $.each(keyValue.post, function (index1, keyValue1) {
            $.each(keyValue1.image, function (index2, keyValue2) {

                $.each(keyValue2.catalogue, function (index3, keyValue3) {
                    var imgJsonId = keyValue2.id;
                    console.log(imgJsonId + '-' + imgId);
                    if (imgJsonId == imgId && id == keyValue1.postid) {
                        var urlImage;
                        highRes = 0;
                        if (keyValue2.high_res_url != 0) {
                            urlImage = "'" + keyValue2.high_res_url + "'";
                            highRes = 1;
                        }
                        else {
                            urlImage = "'" + keyValue2.url + "'";
                            highRes = 0;
                        }
                        var htmlData1 = '<li>' + keyValue3.catalogue + '</li>'
                        $("#catalogue-info").append(htmlData1);
                    }
                });
            });
        });
    });
    // Swapping the positions of zoom in / out icons
    $("div[title|='Zoom in']").before($("div[title|='Zoom out']"));
    if (highRes == 0) {
        disable_zoom();
    }
    else {
        enable_zoom();
    }

    /*-------end update catelogue-------*/
}

function closeBox() {
    hideModal();
    $(".uwy").show();
}

function hideModal() {
    $("#myModal, .modal-backdrop").hide();
    $(".openseadragon").remove();
    $("#appendBoxSidebar div").remove();
    $("body").removeClass("modal-open");
}

