<div class="article-popup modal fade" id="myModal" role="dialog">
    <div class="row">

        <div class="col-sm-9 text-center main-img" id="appendBox">
            <div class="notice-text notice">High resolution not available</div>
            <div class="notice-overlay notice"></div>

        </div>
        <div class="col-sm-3 main-sidebar">
            <div class="close-details-wrapper">
                <img src="<?php echo site_url(); ?>/wp-content/themes/academy/popup/images/close.svg" class="close-details">
            </div>
            <div class="details-wrapper">
                <div class="result"></div>
            </div>
            <div class="close-main">
                <img src="<?php echo site_url(); ?>/wp-content/themes/academy/popup/images/close.svg" class="f-right" data-dismiss="modal" onclick="closeBox()" onmouseover="hover(this);" onmouseout="unhover(this);">
                <script>
                    function hover(element) {
                        element.setAttribute('src', '<?=get_template_directory_uri()?>/popup/images/close_hover.svg');
                    }

                    function unhover(element) {
                        element.setAttribute('src', '<?=get_template_directory_uri()?>/popup/images/close.svg');
                    }
                </script>
            </div>
            <div class="small-img text-center" id="appendBoxSidebar">

            </div>
            <div id="container">
                <div class="small-text text-center mb-2 mt-3">More images from this article</div>
                <div id="slider-container">
                    <!--                    <span onclick="slideRight()" class="arrow"></span>-->
                    <div id="slider">

                    </div>
                    <button onclick="slideRight()" class="slick-prev slick-arrow mt-2 ml-2" style=""><span class="icon icon-arrow-left" data-uw-styling-context="true"></span></button>
                    <button onclick="slideLeft()" class="slick-next slick-arrow mt-2 mr-2" style=""><span class="icon icon-arrow-right" data-uw-styling-context="true"></span></button>

                    <!--                    <span onclick="slideLeft()" class="arrow"></span>-->
                </div>
            </div>

            <div class="catalogue text-center">
                <!--                <h2>Image Details</h2>-->
                <ul id="catalogue-info">
                </ul>
                <a href="#" class="badge badge-light show-more-details">Show More Details</a>

            </div>
        </div>

    </div>
</div>
