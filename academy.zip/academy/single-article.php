<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage MAPEIA
 * @since MAPEIA 1.0
 */


get_header();


$current_post_id = null;
$excludedArticlePosts = array();
?>

<div class="main-wrapper-div">
    <!-- <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" onclick="openSlider(1)">Slider 1</button> -->

    <?php while (have_posts()) : the_post();

        $current_post_id = get_the_ID();
        array_push($excludedArticlePosts, $current_post_id);

        //get current term
        $tax = 'department';


        $terms = get_the_terms($current_post_id, 'department');
        shuffle($terms);

        $term_slug = $terms[0]->slug;
        $tax_query = [
            'taxonomy' => $tax,
            'field' => 'slug',
            'terms' => $term_slug
        ];
        ?>

        <script>
            var excludedArticlesStored = localStorage.getItem('excludedArticlesStored');
            var excludedClustersStored = localStorage.getItem('excludedClustersStored');

            if (excludedArticlesStored == null) {
                WP_URLS.excluded_article_posts = <?php echo json_encode($excludedArticlePosts);?>;
            }
            else{
                WP_URLS.excluded_article_posts=excludedArticlesStored.split(',');
            }

            if (excludedClustersStored == null) {
                WP_URLS.excluded_cluster_posts = [];
            }
            else{
                WP_URLS.excluded_cluster_posts = excludedClustersStored.split(',');
            }
            WP_URLS.current_post_id = <?=$current_post_id ?>;

            WP_URLS.excluded_blog_posts = [];
            WP_URLS.tax_query = <?php echo json_encode($tax_query);?>;
            WP_URLS.counter = 1;
            WP_URLS.blogOrCluster="cluster"; // to show cluster section and blog section alternatively after every 4th post
            runAjax = true;
            WP_URLS.imageinfo=[];
            postData=[];

        </script>

        <div class="d-none">
            <?php echo do_shortcode('[contact-form-7 id="110" title="Article Feedback" html_class="article-form"]'); ?>
        </div>

        <?php require_once(WP_CONTENT_DIR. '/themes/academy/popup/popup.php'); ?>
        <?php
        get_template_part('/template-parts/article/article-single');
        ?>




    <?php endwhile; ?>



    <div class="article-result"></div>
    <div class="loading text-center">
        <img src="<?= get_template_directory_uri() ?>/images/loading.svg" alt="loading">
    </div>


</div>
<script>
    $(document).ready(function() {


        // This will fire when document is ready:
        $(window).resize(function() {
            // This will fire each time the window is resized:
            if($(window).height() < 730) {
                // if larger or equal
                $('#catalogue-info').css("max-height","10vh");
                $(".show-more-details").show();
            } else {
                $('#catalogue-info').css("max-height","400px");
                $(".show-more-details").hide();
            }
        }).resize(); // This will simulate a resize to trigger the initial run.
    });


    $(".show-more-details").click(function () {

        $(".catalogue").clone().appendTo(".details-wrapper .result");
        $('.details-wrapper').show();
        $('#catalogue-info').css("max-height","400px");
        $(".show-more-details").hide();
        $(".close-details-wrapper").show();
    });

    $(".close-details").click(function () {
        $(".details-wrapper .result").html("");
        $('.details-wrapper').hide();
        $('#catalogue-info').css("max-height","10vh");
        $(".show-more-details").show();
        $(".close-details-wrapper").hide();
    });
</script>

<script>
    $('.article-post').css("visibility","hidden");
    var container = document.getElementById('container');
    var slider = document.getElementById('slider');
    //var slides = document.getElementsByClassName('slide').length;
    var slides = 6;
    var buttons = document.getElementsByClassName('arrow');

    var currentPosition = 0;
    var currentMargin = 0;
    var slidesPerPage = 0;
    var slidesCount = slides - slidesPerPage;
    var containerWidth = container.offsetWidth;
    var prevKeyActive = false;
    var nextKeyActive = true;

    window.addEventListener("resize", checkWidth);

    function checkWidth() {
        containerWidth = container.offsetWidth;
        setParams(containerWidth);
    }

    function setParams(w) {
        if (w < 551) {
            slidesPerPage = 1;
        } else {
            if (w < 901) {
                slidesPerPage = 2;
            } else {
                if (w < 1101) {
                    slidesPerPage = 3;
                } else {
                    slidesPerPage = 4;
                }
            }
        }
        slidesCount = slides - slidesPerPage;
        if (currentPosition > slidesCount) {
            currentPosition -= slidesPerPage;
        };
        currentMargin = - currentPosition * (100 / slidesPerPage);
        slider.style.marginLeft = currentMargin + '%';
        if (currentPosition > 0) {
            buttons[0].classList.remove('inactive');
        }
        if (currentPosition < slidesCount) {
            buttons[1].classList.remove('inactive');
        }
        if (currentPosition >= slidesCount) {
            buttons[1].classList.add('inactive');
        }
    }

    setParams();

    function slideRight() {
        if (currentPosition != 0) {
            slider.style.marginLeft = currentMargin + (100 / slidesPerPage) + '%';
            currentMargin += (100 / slidesPerPage);
            currentPosition--;
        };
        if (currentPosition === 0) {
            buttons[0].classList.add('inactive');
        }
        if (currentPosition < slidesCount) {
            buttons[1].classList.remove('inactive');
        }
    }

    function slideLeft() {
        if (currentPosition != slidesCount) {
            slider.style.marginLeft = currentMargin - (100 / slidesPerPage) + '%';
            currentMargin -= (100 / slidesPerPage);
            currentPosition++;
        };
        if (currentPosition == slidesCount) {
            buttons[1].classList.add('inactive');
        }
        if (currentPosition > 0) {
            buttons[0].classList.remove('inactive');
        }
    }
</script>

<?php //wp_footer(); ?>
<?php


get_footer();


?>




