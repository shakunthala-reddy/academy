<?php
require_once('../../../wp-load.php');

	/*--Sorting--*/
    echo $post->ID;
    global $depart_id;
    $depart_id = "";
    $dept_taxterms = wp_get_object_terms( $post->ID, 'department', array('fields' => 'ids') );      
    $args = array(
        'post_type' => 'article', 
        'post_status' => 'publish', 
        'posts_per_page' => '1', 
        'paged' => 1,  
        'post__not_in' => array ($post->ID),
            'tax_query' => array(
                array(
                    'taxonomy' => 'department',
                    'field' => 'id',
                    'terms' => $dept_taxterms,
                    'operator' => 'IN'
                )
            ),
        );
    $related_items = new WP_Query( $args );
    if ($related_items->have_posts()) :?>
    <?php    
    while ( $related_items->have_posts() ) : $related_items->the_post();
        $depart_id = get_the_ID();
    ?>
    <h3>Department</h3> 
    <section class="divider-section my-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">&nbsp;</div>
                <div class="col-lg-6 pr-0">
                    <div class="tagy-border-top"></div>
                </div>
                <div class="col-lg-3">&nbsp;</div>
            </div>
        </div>
    </section>
    <section class="photographer-section pt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">&nbsp;</div>
                <div class="col-lg-6 pr-0">
                    <h5 class="label-title article">ARTICLE</h5>
                    <h2 class="phtograph-heading"><?php the_title(); ?></h2>
                    <p class="phtograph-subheading"><span class="mr-lg-3 mr-2"> <?php the_field('author_name'); ?></span></br> <span class="mr-lg-3 mr-2"><?php the_modified_time('F jS, Y'); ?></span></p>
                </div>
                <div class="col-lg-3">&nbsp;</div>
            </div>
        </div>
    </section>
    <section class="Article-description-section mb-5 pb-5 pt-1">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="icon-bar">
                        <div class="col-12 p-0"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/download-fix.png" class="img-fluid fixy10 extra-icon"></a></div> 
                        <div class="col-12 p-0"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/share-fix.png" class="img-fluid fixy10 extra-icon"></a></div> 
                        <div class="col-12 p-0"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/qoute-fix.png" class="img-fluid fixy10 extra-icon"></a></div> 
                    </div>
                </div>
                <div class="col-lg-6 pr-0">
                    <div class="pcontent">
                        <?php the_content(); ?>
                    </div>
                    <div class="biblo-feed">
                        <h6 class="bio">Bibliography<h6>  
                        <div class="bio_wrap">
                            <?php the_field('bibliography'); ?>
                        </div>
                    </div>
                    <div class="biblo-feed">
                        <h6 class="feed">Feedback<h6> 
                        <div class="feed_wrap">
                            <?php echo do_shortcode('[contact-form-7 id="110" title="Article Feedback"]'); ?> 
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="owl-carousel owl-theme xxx-carousel gallery_article p-0" id="datail-right-carousel">
                        <?php 
                        if(have_rows('gallery')):
                            while(have_rows('gallery')): the_row();
                                $gallery_image = get_sub_field('gallery_image');
                        ?>
                        <div class="item">
                            <img src="<?php echo $gallery_image; ?>" alt="">
                        </div>
                        <?php endwhile; endif; wp_reset_query(); ?>
                    </div>
                </div>
          </div>
      </div>
    </section>
    <?php endwhile; 
    ?>
    <?php endif; wp_reset_postdata(); ?>
    <!--end department-->

    <!--Custom Category-->
    <?php 
    echo $depart_id;
    global $category_id;
    $category_id = "";
    $custom_category_taxterms = wp_get_object_terms( $depart_id, 'custom_category', array('fields' => 'ids') );       
    $args = array(
        'post_type' => 'article', 
        'post_status' => 'publish', 
        'posts_per_page' => '1', 
        'paged' => 1,  
        'post__not_in' => array ($depart_id),
            'tax_query' => array(
                array(
                    'taxonomy' => 'custom_category',
                    'field' => 'id',
                    'terms' => $custom_category_taxterms,
                    'operator' => 'IN'
                )
            ),
        );
    $related_items = new WP_Query( $args );
    if ($related_items->have_posts()) :?>    
    <?php    
    while ( $related_items->have_posts() ) : $related_items->the_post();
        $category_id = get_the_ID();
    ?> 
    <h3>Category</h3>
    <section class="divider-section my-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">&nbsp;</div>
                <div class="col-lg-6 pr-0">
                    <div class="tagy-border-top"></div>
                </div>
                <div class="col-lg-3">&nbsp;</div>
            </div>
        </div>
    </section>
    <section class="photographer-section pt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">&nbsp;</div>
                <div class="col-lg-6 pr-0">
                    <h5 class="label-title article">ARTICLE</h5>
                    <h2 class="phtograph-heading"><?php the_title(); ?></h2>
                    <p class="phtograph-subheading"><span class="mr-lg-3 mr-2"> <?php the_field('author_name'); ?></span></br> <span class="mr-lg-3 mr-2"><?php the_modified_time('F jS, Y'); ?></span></p>
                </div>
                <div class="col-lg-3">&nbsp;</div>
            </div>
        </div>
    </section>
    <section class="Article-description-section mb-5 pb-5 pt-1">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="icon-bar">
                        <div class="col-12 p-0"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/download-fix.png" class="img-fluid fixy10 extra-icon"></a></div> 
                        <div class="col-12 p-0"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/share-fix.png" class="img-fluid fixy10 extra-icon"></a></div> 
                        <div class="col-12 p-0"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/qoute-fix.png" class="img-fluid fixy10 extra-icon"></a></div> 
                    </div>
                </div>
                <div class="col-lg-6 pr-0">
                    <div class="pcontent">
                        <?php the_content(); ?>
                    </div>
                    <div class="biblo-feed">
                        <h6 class="bio">Bibliography<h6>  
                        <div class="bio_wrap">
                            <?php the_field('bibliography'); ?>
                        </div>
                    </div>
                    <div class="biblo-feed">
                        <h6 class="feed">Feedback<h6> 
                        <div class="feed_wrap">
                            <?php echo do_shortcode('[contact-form-7 id="110" title="Article Feedback"]'); ?> 
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="owl-carousel owl-theme xxx-carousel gallery_article p-0" id="datail-right-carousel">
                        <?php 
                        if(have_rows('gallery')):
                            while(have_rows('gallery')): the_row();
                                $gallery_image = get_sub_field('gallery_image');
                        ?>
                        <div class="item">
                            <img src="<?php echo $gallery_image; ?>" alt="">
                        </div>
                        <?php endwhile; endif; wp_reset_query(); ?>
                    </div>
                </div>
          </div>
      </div>
    </section>
    <?php endwhile; 
    ?>
    <?php endif; wp_reset_postdata(); ?>
    <!--end Custom Category-->

    <!--Period-->
    <?php 
    echo $category_id; 
    global $period_id;
    $period_id = "";
    $period_taxterms = wp_get_object_terms( $category_id, 'period', array('fields' => 'ids') );       
    $args = array(
        'post_type' => 'article', 
        'post_status' => 'publish', 
        'posts_per_page' => '1', 
        'paged' => 1,  
        'post__not_in' => array ($category_id),
            'tax_query' => array(
                array(
                    'taxonomy' => 'period',
                    'field' => 'id',
                    'terms' => $period_taxterms,
                    'operator' => 'IN'
                )
            ),
        );
    $related_items = new WP_Query( $args );
    if ($related_items->have_posts()) :?>
    <?php    
    while ( $related_items->have_posts() ) : $related_items->the_post();
        $period_id = get_the_ID();
    ?> 
    <h3>Period</h3>
    <section class="divider-section my-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">&nbsp;</div>
                <div class="col-lg-6 pr-0">
                    <div class="tagy-border-top"></div>
                </div>
                <div class="col-lg-3">&nbsp;</div>
            </div>
        </div>
    </section>
    <section class="photographer-section pt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">&nbsp;</div>
                <div class="col-lg-6 pr-0">
                    <h5 class="label-title article">ARTICLE</h5>
                    <h2 class="phtograph-heading"><?php the_title(); ?></h2>
                    <p class="phtograph-subheading"><span class="mr-lg-3 mr-2"> <?php the_field('author_name'); ?></span></br> <span class="mr-lg-3 mr-2"><?php the_modified_time('F jS, Y'); ?></span></p>
                </div>
                <div class="col-lg-3">&nbsp;</div>
            </div>
        </div>
    </section>
    <section class="Article-description-section mb-5 pb-5 pt-1">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="icon-bar">
                        <div class="col-12 p-0"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/download-fix.png" class="img-fluid fixy10 extra-icon"></a></div> 
                        <div class="col-12 p-0"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/share-fix.png" class="img-fluid fixy10 extra-icon"></a></div> 
                        <div class="col-12 p-0"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/qoute-fix.png" class="img-fluid fixy10 extra-icon"></a></div> 
                    </div>
                </div>
                <div class="col-lg-6 pr-0">
                    <div class="pcontent">
                        <?php the_content(); ?>
                    </div>
                    <div class="biblo-feed">
                        <h6 class="bio">Bibliography<h6>  
                        <div class="bio_wrap">
                            <?php the_field('bibliography'); ?>
                        </div>
                    </div>
                    <div class="biblo-feed">
                        <h6 class="feed">Feedback<h6> 
                        <div class="feed_wrap">
                            <?php echo do_shortcode('[contact-form-7 id="110" title="Article Feedback"]'); ?> 
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="owl-carousel owl-theme xxx-carousel gallery_article p-0" id="datail-right-carousel">
                        <?php 
                        if(have_rows('gallery')):
                            while(have_rows('gallery')): the_row();
                                $gallery_image = get_sub_field('gallery_image');
                        ?>
                        <div class="item">
                            <img src="<?php echo $gallery_image; ?>" alt="">
                        </div>
                        <?php endwhile; endif; wp_reset_query(); ?>
                    </div>
                </div>
          </div>
      </div>
    </section>
    <?php endwhile; 
    ?>
    <?php endif; wp_reset_postdata(); ?>
    <!--end Period-->

    <!--Region-->
    <?php 
    echo $period_id;
    global $region_id;
    $region_id = "";
    $region_taxterms = wp_get_object_terms( $period_id, 'region', array('fields' => 'ids') );       
    $args = array(
        'post_type' => 'article', 
        'post_status' => 'publish', 
        'posts_per_page' => '1', 
        'paged' => 1,  
        'post__not_in' => array ($period_id),
            'tax_query' => array(
                array(
                    'taxonomy' => 'region',
                    'field' => 'id',
                    'terms' => $region_taxterms,
                    'operator' => 'IN'
                )
            ),
        );
    $related_items = new WP_Query( $args );
    if ($related_items->have_posts()) :?>
    <?php    
    while ( $related_items->have_posts() ) : $related_items->the_post();
        $region_id = get_the_ID();
    ?> 
    <h3>Region</h3>
    <section class="divider-section my-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">&nbsp;</div>
                <div class="col-lg-6 pr-0">
                    <div class="tagy-border-top"></div>
                </div>
                <div class="col-lg-3">&nbsp;</div>
            </div>
        </div>
    </section>
    <section class="photographer-section pt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">&nbsp;</div>
                <div class="col-lg-6 pr-0">
                    <h5 class="label-title article">ARTICLE</h5>
                    <h2 class="phtograph-heading"><?php the_title(); ?></h2>
                    <p class="phtograph-subheading"><span class="mr-lg-3 mr-2"> <?php the_field('author_name'); ?></span></br> <span class="mr-lg-3 mr-2"><?php the_modified_time('F jS, Y'); ?></span></p>
                </div>
                <div class="col-lg-3">&nbsp;</div>
            </div>
        </div>
    </section>
    <section class="Article-description-section mb-5 pb-5 pt-1">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="icon-bar">
                        <div class="col-12 p-0"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/download-fix.png" class="img-fluid fixy10 extra-icon"></a></div> 
                        <div class="col-12 p-0"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/share-fix.png" class="img-fluid fixy10 extra-icon"></a></div> 
                        <div class="col-12 p-0"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/qoute-fix.png" class="img-fluid fixy10 extra-icon"></a></div> 
                    </div>
                </div>
                <div class="col-lg-6 pr-0">
                    <div class="pcontent">
                        <?php the_content(); ?>
                    </div>
                    <div class="biblo-feed">
                        <h6 class="bio">Bibliography<h6>  
                        <div class="bio_wrap">
                            <?php the_field('bibliography'); ?>
                        </div>
                    </div>
                    <div class="biblo-feed">
                        <h6 class="feed">Feedback<h6> 
                        <div class="feed_wrap">
                            <?php echo do_shortcode('[contact-form-7 id="110" title="Article Feedback"]'); ?> 
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="owl-carousel owl-theme xxx-carousel gallery_article p-0" id="datail-right-carousel">
                        <?php 
                        if(have_rows('gallery')):
                            while(have_rows('gallery')): the_row();
                                $gallery_image = get_sub_field('gallery_image');
                        ?>
                        <div class="item">
                            <img src="<?php echo $gallery_image; ?>" alt="">
                        </div>
                        <?php endwhile; endif; wp_reset_query(); ?>
                    </div>
                </div>
          </div>
      </div>
    </section>
    <?php endwhile; 
    ?>
    <?php endif; wp_reset_postdata(); ?>
    <!--end Region-->

    <!--Occupation-->
    <?php 
    echo $region_id;
    global $occupation_id;
    $occupation_id = "";
    $occupation_taxterms = wp_get_object_terms( $region_id, 'occupation', array('fields' => 'ids') );       
    $args = array(
        'post_type' => 'article', 
        'post_status' => 'publish', 
        'posts_per_page' => '1', 
        'paged' => 1,  
        'post__not_in' => array ($region_id),
            'tax_query' => array(
                array(
                    'taxonomy' => 'occupation',
                    'field' => 'id',
                    'terms' => $occupation_taxterms,
                    'operator' => 'IN'
                )
            ),
        );
    $related_items = new WP_Query( $args );
    if ($related_items->have_posts()) :?>
    <?php    
    while ( $related_items->have_posts() ) : $related_items->the_post();
    ?> 
    <h3>Occupation</h3>
    <section class="divider-section my-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">&nbsp;</div>
                <div class="col-lg-6 pr-0">
                    <div class="tagy-border-top"></div>
                </div>
                <div class="col-lg-3">&nbsp;</div>
            </div>
        </div>
    </section>
    <section class="photographer-section pt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">&nbsp;</div>
                <div class="col-lg-6 pr-0">
                    <h5 class="label-title article">ARTICLE</h5>
                    <h2 class="phtograph-heading"><?php the_title(); ?></h2>
                    <p class="phtograph-subheading"><span class="mr-lg-3 mr-2"> <?php the_field('author_name'); ?></span></br> <span class="mr-lg-3 mr-2"><?php the_modified_time('F jS, Y'); ?></span></p>
                </div>
                <div class="col-lg-3">&nbsp;</div>
            </div>
        </div>
    </section>
    <section class="Article-description-section mb-5 pb-5 pt-1">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="icon-bar">
                        <div class="col-12 p-0"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/download-fix.png" class="img-fluid fixy10 extra-icon"></a></div> 
                        <div class="col-12 p-0"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/share-fix.png" class="img-fluid fixy10 extra-icon"></a></div> 
                        <div class="col-12 p-0"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/qoute-fix.png" class="img-fluid fixy10 extra-icon"></a></div> 
                    </div>
                </div>
                <div class="col-lg-6 pr-0">
                    <div class="pcontent">
                        <?php the_content(); ?>
                    </div>
                    <div class="biblo-feed">
                        <h6 class="bio">Bibliography<h6>  
                        <div class="bio_wrap">
                            <?php the_field('bibliography'); ?>
                        </div>
                    </div>
                    <div class="biblo-feed">
                        <h6 class="feed">Feedback<h6> 
                        <div class="feed_wrap">
                            <?php echo do_shortcode('[contact-form-7 id="110" title="Article Feedback"]'); ?> 
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="owl-carousel owl-theme xxx-carousel gallery_article p-0" id="datail-right-carousel">
                        <?php 
                        if(have_rows('gallery')):
                            while(have_rows('gallery')): the_row();
                                $gallery_image = get_sub_field('gallery_image');
                        ?>
                        <div class="item">
                            <img src="<?php echo $gallery_image; ?>" alt="">
                        </div>
                        <?php endwhile; endif; wp_reset_query(); ?>
                    </div>
                </div>
          </div>
      </div>
    </section>
    <?php endwhile; 
    ?>
    <?php endif; wp_reset_postdata(); ?>
    <!--end Occupation-->
    
?>