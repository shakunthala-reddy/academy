<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage MAPEIA
 * @since MAPEIA 1.0
 */

get_header();

global $post;
$terms = get_the_terms( $post->ID, 'cluster_cat' );
$term = array_shift( $terms );
$termsname = $term->slug;
$postid = $post->ID;

?>
<!--Desktop-->
<!-- Glossary 1-->
<div class="desktop-version">
    <?php while(have_posts()): the_post(); ?>
    <div class="print-section-cluster" id="p-<?php echo $postid; ?>">

    <section class="photograpers-banner-section">
        <div class="container-fluid">
            <div class="row">
                <article class="col-lg-12 p-0">
                    <img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid w-100 d-lg-block d-none" alt="<?php the_title(); ?>">
                    <img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid w-100 d-lg-none d-block" alt="<?php the_title(); ?>">
                </article>
            </div>
        </div>
    </section>

    <section class="photographer-section mb-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12"></div>
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                    <div class="label-section">
                        <h5 class="label-title cluster"><a href="<?php the_permalink(2); ?>">CLUSTER</a></h5>
                        <h2 class="phtograph-heading"><?php the_title(); ?></h2>
                        <?php
                            get_template_part('/template-parts/author/author-details');
                        ?>
                    </div>
                </div>
                <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12"></div>
            </div>
        </div>
    </section>

    <section class="cluster-description-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <aside class="left-sidebar">
                        <div class="author-details">
                            <div class="wrap-filed-info">
                                <p class="first-published">FIRST PUBLISHED</p>
                                <p class="published-date"><?php the_time('F j, Y'); ?></p>
                            </div>
                        </div>
                        <?php
                            get_template_part('/template-parts/social-icon/social-icon');
                        ?>
                    </aside>
                </div>
                <div class="col-lg-6">
                    <div class="pcontent">
                        <?php the_content(); ?>
                    </div>
                </div>
                <div class="col-lg-3">
                    <aside class="right-sidebar d-none d-lg-block">
                        <div class="right-section"></div>
                        <?php
                            get_template_part('/template-parts/related-content/related-content');
                        ?>
                    </aside>
                </div>
            </div>
        </div>
    </section>
        <section class="article-section one-col-section article-listing">
            <div class="container">
                <div class="row">
                    <?php

                    $list = get_the_terms( $postid, 'cluster_cat' );
                    foreach ( $list as $tax ) {
                        ?>
                        <?php
                        $args = array('post_type' => 'article',
                            'post_status' => 'publish',
                            'orderby'        => 'post_date',
                            'order' => 'DESC',
                            'posts_per_page'=> -1,
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'cluster_cat',
                                    'field' => 'slug',
                                    'terms' => $tax->name,
                                ),
                            ),
                        );
                        $loop = new WP_Query($args);
                        if($loop->have_posts()) :
                            while($loop->have_posts()) : $loop->the_post();
                                ?>
                                <div class="col-lg-3 col-6">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php
                                        if (get_the_post_thumbnail_url()) {
                                            $thumb_url = get_the_post_thumbnail_url();
                                        } else {
                                            $thumb_url = get_field('default_thumbnail', 'option');
                                        }
                                        ?>
                                        <img src="<?php echo $thumb_url; ?>" class="img-responsive" alt="<?php the_title(); ?>">
                                    </a>
                                    <div class="btm-part">
                                        <p class="article-lable">ARTICLE</p>
                                        <div class="article-summary-wrap">
                                            <a class="article-title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                            <?php
                                            $content=wp_strip_all_tags(get_the_content());
                                            $pattern = "/(\[)(.*?)(\])/";
                                            $content = preg_replace($pattern, '', $content);
                                            ?>

                                            <p class="article-description"><?php echo $content; ?></p>
                                        </div>
                                        <div class="col-12 p-0 double-part d-flex flex-row flex-wrap justify-content-between">
                                            <div class="read-more p-0"><?php //echo $est; ?> <a href="<?php the_permalink(); ?>">Read More</a></div>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; endif; wp_reset_query(); ?>
                    <?php } ?>
                </div>
            </div>
        </section>
    </div>
    <!-- end -->
    <?php endwhile; ?>

    <?php 
    $args = array('post_type' => 'cluster', 'post_status' => 'publish', 'orderby' => 'post_date', 'order' => 'DESC', 'post__not_in' => array ($post->ID));
    $related_items = new WP_Query( $args );
    if ($related_items->have_posts()) :
    while ( $related_items->have_posts() ) : $related_items->the_post();
        $post_id = $post->ID;
    ?>

    <div class="print-section-cluster" id="p-<?php echo $post_id; ?>">

    <?php
        get_template_part('/template-parts/divider/divider');
    ?>

    <section class="photograpers-banner-section">
        <div class="container-fluid">
            <div class="row">
                <article class="col-lg-12 p-0">
                    <img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid w-100 d-lg-block d-none" alt="<?php the_title(); ?>">
                    <img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid w-100 d-lg-none d-block " alt="<?php the_title(); ?>">
                </article>
            </div>
        </div>
    </section>

    <section class="photographer-section mb-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12"></div>
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                    <div class="label-section">
                        <h5 class="label-title cluster"><a href="<?php the_permalink(2); ?>">CLUSTER</a></h5>
                        <h2 class="phtograph-heading"><?php the_title(); ?></h2>
                        <?php
                            get_template_part('/template-parts/author/author-details');
                        ?>
                    </div>
                </div>
                <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12"></div>
            </div>
        </div>
    </section>

    <section class="cluster-description-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <aside class="left-sidebar">
                        <div class="author-details">
                            <div class="wrap-filed-info">
                                <p class="first-published">FIRST PUBLISHED</p>
                                <p class="published-date"><?php the_time('F j, Y'); ?></p>
                            </div>
                        </div>
                        <?php
                            get_template_part('/template-parts/social-icon/social-icon');
                        ?>
                    </aside>
                </div>
                <div class="col-lg-6">
                    <div class="pcontent">
                        <?php the_content(); ?>
                    </div>
                </div>
                <div class="col-lg-3">
                    <aside class="right-sidebar d-none d-lg-block">
                        <div class="right-section"></div>
                        <?php
                            get_template_part('/template-parts/related-content/related-content');
                        ?>
                    </aside>
                </div>                
            </div>
        </div>
    </section>
        <section class="article-section one-col-section article-listing">
            <div class="container">
                <div class="row">
                    <?php

                    $list = get_the_terms( $post_id, 'cluster_cat' );
                    foreach ( $list as $tax ) {
                        ?>
                        <?php
                        $args = array('post_type' => 'article',
                            'post_status' => 'publish',
                            'orderby'        => 'post_date',
                            'order' => 'DESC',
                            'posts_per_page'=> -1,
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'cluster_cat',
                                    'field' => 'slug',
                                    'terms' => $tax->name,
                                ),
                            ),
                        );
                        $loop = new WP_Query($args);
                        if($loop->have_posts()) :
                            while($loop->have_posts()) : $loop->the_post();
                                ?>
                                <div class="col-lg-3 col-6">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php
                                        if (get_the_post_thumbnail_url()) {
                                            $thumb_url = get_the_post_thumbnail_url();
                                        } else {
                                            $thumb_url = get_field('default_thumbnail', 'option');
                                        }
                                        ?>
                                        <img src="<?php echo $thumb_url; ?>" class="img-responsive" alt="<?php the_title(); ?>">
                                    </a>
                                    <div class="btm-part">
                                        <p class="article-lable">ARTICLE</p>
                                        <div class="article-summary-wrap">
                                            <a class="article-title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                            <?php
                                            $content=wp_strip_all_tags(get_the_content());
                                            $pattern = "/(\[)(.*?)(\])/";
                                            $content = preg_replace($pattern, '', $content);
                                            ?>

                                            <p class="article-description"><?php echo $content; ?></p>
                                        </div>
                                        <div class="col-12 p-0 double-part d-flex flex-row flex-wrap justify-content-between">
                                            <div class="read-more p-0"><?php //echo $est; ?> <a href="<?php the_permalink(); ?>">Read More</a></div>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; endif; wp_reset_query(); ?>
                    <?php } ?>
                </div>
            </div>
        </section>
    </div>

    <?php endwhile; endif; wp_reset_query(); ?>

</div> 
<!--end Desktop-->


<!--Mobile-->
<div class="mobile-version">
    <div class="main-wrapper-div pt-5 mt-4">
        <?php while(have_posts()): the_post(); ?>
        <div class="print-section-cluster" id="p-<?php echo $postid; ?>">

        <!-- Image Banner Section -->
        <section class="photograpers-banner-section">
            <div class="container-full">
                <div class="row">
                    <article class="col-12 p-0">
                        <img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid w-100 d-lg-block d-none pt-0" alt="<?php the_title(); ?>">
                        <img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid w-100 d-lg-none d-block pt-0" alt="<?php the_title(); ?>">
                    </article>
                    <div class="col-12 p-0 d-none">
                        <span class="cluster-photo-caption">
                            <?php
                            $comma=0;
                            if(get_field('artist_name')){
                                echo get_field('artist_name');
                                $comma=1;
                            }
                            if(get_field('artwork_name')){
                                if($comma){ echo ', '; }
                                echo get_field('artwork_name');
                                $comma=1;
                            }
                            if(get_field('courtesy')){
                                if($comma){ echo ', '; }
                                echo get_field('courtesy');
                                $comma=1;
                            }
                            if(get_field('copyright')){
                                if($comma){ echo ', '; }
                                echo get_field('copyright');
                                $comma=1;
                            }
                            if($comma){ echo '. '; }

                            ?>

                        </span>
                    </div>
                </div>
            </div>
        </section>

        <!-- Title Section -->
        <section class="photographer-section mb-4">
            <div class="container">
                <div class="row">
                    <article class="col-lg-12 inrow-1 col-wrapper d-flex flex-row flex-wrap justify-content-between p-0">
                        <div class="col-lg-2 col-md-12 col-sm-12 col-xs-12">
                        </div>
                        <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12 p-0 mx-auto column1">
                            <div class="center-section">
                                <div class="col-12 p-0">
                                    <div class="col-lg-12 col-12 p-0">
                                        <h5 class="label-title cluster">CLUSTER</h5>
                                        <h2 class="phtograph-heading"><?php the_title(); ?></h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-12 col-sm-12 col-xs-12">
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <!-- Author & Content Section -->
        <section class="cluster-description-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 order-1 order-md-0 p-0 d-none">
                        <aside class="left-sidebar">
                            <div class="author-details-cluster">
                                <p class="author-lable">AUTHOR(S)</p>
                                <p class="author-title"><?php the_field('author_name'); ?></p>
                                <p class="first-published">FIRST PUBLISHED</p>
                                <p class="published-date"><?php the_time('F j, Y'); ?></p>
                            </div>
                            <div class="icon-section">
                                <span class="icon-upload"><img src="<?php echo get_template_directory_uri(); ?>/images/upload-icon.svg"></span>
                                <span class="icon-download" onclick="print_this('p-<?php echo $post_id; ?>')"><img src="<?php echo get_template_directory_uri(); ?>/images/download-icon.svg"></span>
                                <span class="icon-quote"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/quote-icon.svg"></a></span>
                            </div>
                            <div class="share-icons">
                                <span class="facebook-share"><a href="https://www.facebook.com/sharer?u=<?php the_permalink();?>&t=<?php the_title(); ?>" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/facebook-share.svg"></a></span>
                                <span class="twitter-share"><a href="http://twitter.com/intent/tweet?text=Currently reading <?php the_title(); ?>&url=<?php the_permalink(); ?>;" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/twitter-share.svg"></a></span>
                                <span class="email-share"><a href="mailto:vivek.kumar@langoor.com?&subject=&cc=&bcc=&body=<?php the_title(); ?>&url=<?php the_permalink(); ?>;%0A" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/email-share.svg"></a></span>
                                <span class="whatsaap-share"><a href="https://api.whatsapp.com/send?text=<?php the_title(); ?>%20%E2%80%93%20<?php the_permalink(); ?>" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/whatsaap-share.svg"></a></span>
                            </div>
                        </aside>
                    </div>
                    <div class="col-lg-6 p-0">
                        <div class="pcontent">
                            <?php the_content(); ?>
                        </div>
                    </div>
                    <div class="col-lg-3">&nbsp;</div>
                </div>
            </div>
        </section>

        <!-- Related Articles Section-->
        <section class="article-section one-col-section article-listing">
            <div class="container">
                <ul class="d-block d-lg-none p-0">
                    <?php
                    wp_reset_query();
                    $list = get_the_terms( $postid, 'cluster_cat' );

                    foreach ( $list as $tax ) {
                        ?>
                        <?php
                        $args8 = array('post_type' => 'article',
                            'post_status' => 'publish',
                            'orderby'        => 'post_date',
                            'order' => 'DESC',
                            'posts_per_page'=> -1,
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'cluster_cat',
                                    'field' => 'slug',
                                    'terms' => $tax->slug,
                                ),
                            ),
                        );
                        $loop = new WP_Query($args8);
                        if($loop->have_posts()) :
                            while($loop->have_posts()) : $loop->the_post();
                                ?>
                                <?php
                                if (get_the_post_thumbnail_url($post->ID)) {
                                    $thumb_url = get_the_post_thumbnail_url($post->ID, 'thumbnail');
                                } else {
                                    $thumb_url = get_field('default_thumbnail', 'option');
                                }
                                ?>
                                <li class="media list-view">
                                    <a href="<?php the_permalink(); ?>">
                                        <img src="<?php echo $thumb_url; ?>" class="art-img" alt="<?php the_title(); ?>">
                                    </a>
                                    <div class="media-body">
                                        <h5 class="mt-0"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                        <p class="pb-2"><?php
                                            $content = get_post_field('post_content');
                                            $pattern = "/(\[)(.*?)(\])/";
                                            $content = preg_replace($pattern, '', $content);
                                            $content = wp_trim_words($content, 11);

                                            echo $content;
                                            ?></p>

                                        <hr class="hr-border mt-4">
                                    </div>
                                </li>
                    <?php endwhile; endif; wp_reset_query(); ?>
                    <?php } ?>
                </ul>
            </div>
        </section>

        </div>
        <!-- end -->
        <?php endwhile; ?>


        <?php
        $args = array('post_type' => 'cluster', 'post_status' => 'publish', 'orderby' => 'post_date', 'order' => 'DESC', 'post__not_in' => array ($post->ID));
        $related_items = new WP_Query( $args );
        if ($related_items->have_posts()) :
        while ( $related_items->have_posts() ) : $related_items->the_post();
            $post_id = $post->ID;
        ?>

        <div class="print-section-cluster" id="p-<?php echo $post_id; ?>">

        <section class="photograpers-banner-section">
            <div class="container-full">
                <div class="row">
                    <article class="col-12 p-0">
                        <img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid w-100 d-lg-block d-none" alt="<?php the_title(); ?>">
                        <img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid w-100 d-lg-none d-block " alt="<?php the_title(); ?>">
                    </article>
                    <div class="col-12 p-0 d-none">
                        <span class="cluster-photo-caption">
                            <?php
                            $comma=0;
                            if(get_field('artist_name')){
                                echo get_field('artist_name');
                                $comma=1;
                            }
                            if(get_field('artwork_name')){
                                if($comma){ echo ', '; }
                                echo get_field('artwork_name');
                                $comma=1;
                            }
                            if(get_field('courtesy')){
                                if($comma){ echo ', '; }
                                echo get_field('courtesy');
                                $comma=1;
                            }
                            if(get_field('copyright')){
                                if($comma){ echo ', '; }
                                echo get_field('copyright');
                                $comma=1;
                            }
                            if($comma){ echo '. '; }

                            ?>

                        </span>
                    </div>
                </div>
            </div>
        </section>

        <section class="photographer-section mb-4">
            <div class="container">
                <div class="row">
                    <article class="col-lg-12 inrow-1 col-wrapper d-flex flex-row flex-wrap justify-content-between p-0">
                        <div class="col-lg-2 col-md-12 col-sm-12 col-xs-12">
                        </div>
                        <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12 p-0 mx-auto column1">
                            <div class="center-section">
                                <div class="col-12 p-0">
                                    <div class="col-lg-12 col-12 p-0">
                                        <h5 class="label-title cluster">CLUSTER</h5>
                                        <h2 class="phtograph-heading"><?php the_title(); ?></h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-12 col-sm-12 col-xs-12">
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <section class="cluster-description-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 order-1 order-md-0 p-0 d-none">
                        <aside class="left-sidebar">
                            <div class="author-details-cluster">
                                <p class="author-lable">AUTHOR(S)</p>
                                <p class="author-title"><?php the_field('author_name'); ?></p>
                                <p class="first-published">FIRST PUBLISHED</p>
                                <p class="published-date"><?php the_time('F j, Y'); ?></p>
                            </div>
                            <div class="icon-section">
                                <span class="icon-upload"><img src="<?php echo get_template_directory_uri(); ?>/images/upload-icon.svg"></span>
                                <span class="icon-download" onclick="print_this('p-<?php echo $post_id; ?>')"><img src="<?php echo get_template_directory_uri(); ?>/images/download-icon.svg"></span>
                                <span class="icon-quote"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/quote-icon.svg"></a></span>
                            </div>
                            <div class="share-icons">
                                <span class="facebook-share"><a href="https://www.facebook.com/sharer?u=<?php the_permalink();?>&t=<?php the_title(); ?>" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/facebook-share.svg"></a></span>
                                <span class="twitter-share"><a href="http://twitter.com/intent/tweet?text=Currently reading <?php the_title(); ?>&url=<?php the_permalink(); ?>;" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/twitter-share.svg"></a></span>
                                <span class="email-share"><a href="mailto:vivek.kumar@langoor.com?&subject=&cc=&bcc=&body=<?php the_title(); ?>&url=<?php the_permalink(); ?>;%0A" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/email-share.svg"></a></span>
                                <span class="whatsaap-share"><a href="https://api.whatsapp.com/send?text=<?php the_title(); ?>%20%E2%80%93%20<?php the_permalink(); ?>" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/whatsaap-share.svg"></a></span>
                            </div>
                        </aside>
                    </div>
                    <div class="col-lg-6 p-0">
                        <div class="pcontent">
                            <?php the_content(); ?>
                        </div>
                    </div>
                    <div class="col-lg-3">&nbsp;</div>
                </div>
            </div>
        </section>

        <!-- Related Articles -->
        <section class="article-section one-col-section article-listing">
            <div class="container">
                <ul class="d-block d-lg-none p-0 pb-5">
<?php
                    $list = get_the_terms( $post_id, 'cluster_cat' );
                    foreach ( $list as $tax ) {
                        ?>
                        <?php
                        $args = array('post_type' => 'article',
                            'post_status' => 'publish',
                            'orderby' => 'post_date',
                            'order' => 'DESC',
                            'posts_per_page' => -1,
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'cluster_cat',
                                    'field' => 'slug',
                                    'terms' => $tax->name,
                                ),
                            ),
                        );
                        $loop = new WP_Query($args);
                        if ($loop->have_posts()) :
                            while ($loop->have_posts()) : $loop->the_post();


                                if (get_the_post_thumbnail_url($post->ID)) {
                                    $thumb_url = get_the_post_thumbnail_url($post->ID, 'thumbnail');
                                } else {
                                    $thumb_url = get_field('default_thumbnail', 'option');
                                }
                                ?>
                                <li class="media list-view">
                                    <a href="<?php the_permalink(); ?>">
                                        <img src="<?php echo $thumb_url; ?>" class="art-img"
                                             alt="<?php the_title(); ?>">
                                    </a>
                                    <div class="media-body">
                                        <h5 class="mt-0"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                        </h5>
                                        <p class="pb-2"><?php
                                            $content = wp_trim_words(get_post_field('post_content'), 15);
                                            $pattern = "/(\[)(.*?)(\])/";
                                            $content = preg_replace($pattern, '', $content);
                                            echo $content;
                                            ?></p>

                                        <hr class="hr-border mt-4">
                                    </div>
                                </li>
                                <?php wp_reset_postdata(); endwhile; endif; ?>

                        </ul>
                        </div>
                        </section>

                        </div>

                        <?php
                    }
    endwhile;
    endif;
    wp_reset_query(); ?>

    </div>
</div>
<!-- end Mobile-->
    

<?php get_footer(); ?>

<script>
    $('.owl-carousel').owlCarousel({
        loop:true,
        margin:10,
        autoplay:true,
        nav:false,
        dots: false,
        responsive:{
            0:{
                items:1.1
            },
            
            1000:{
                items:3.1
            }
        }
    });
</script>
