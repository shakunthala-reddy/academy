<?php
// general theme helpers
require_once(get_template_directory() . '/inc/enqueue-scripts.php');
require_once(get_template_directory() . '/inc/theme-functions.php');
require_once(get_template_directory() . '/inc/cpt.php');
require_once(get_template_directory() . '/inc/shortcodes.php');


function myTheme_Support(){
	//Title (auto added when wp_head() is added)
	add_theme_support('title-tag');
	//Logo (the_custom_logo())
	add_theme_support( 'custom-logo', array(
	    'height'      => 100,
	    'width'       => 400,
	    'flex-height' => true,
	    'flex-width'  => true,
	    'header-text' => array( 'site-title', 'site-description' ),
	) );
	//Thumbnail
	add_theme_support('post-thumbnails');
	// post formats
    add_theme_support( 'post-formats',
    	array('aside','image','gallery','video','audio','link','quote','status')
    );
	// Set up the WordPress core custom background feature.(auto added when wp_head() is added)
	add_theme_support(
		'custom-background',
		apply_filters(
			'custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);
	//Header BG  (img src="echo get_header_image())
	add_theme_support( 'custom-header' );
	//html5
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);
	//Feed Link
	add_theme_support( 'automatic-feed-links' );
}
add_action('after_setup_theme', 'myTheme_Support');
require get_template_directory() . '/inc/ajax-autocomplete.php';
require get_template_directory() . '/inc/ajax-article.php';
require get_template_directory() . '/inc/ajax-blog.php';
require get_template_directory() . '/inc/ajax-glossary.php';
require get_template_directory() . '/inc/ajax-search.php';
require get_template_directory() . '/inc/ajax-glossary-details.php';
require get_template_directory() . '/inc/ajax-article-title.php';
//Register Nav menu
register_nav_menus(
	array(
		'menu-1' => esc_html__('Primary', 'myTheme'),
		'explore-menu' => esc_html__('explore', 'myTheme'),
		'quick-link' => esc_html__('Quick Link', 'myTheme'),
		'important-link' => esc_html__('Important Link', 'myTheme'),
        'social-link' => esc_html__('Social Link', 'myTheme'),
	)
);

/*********************li class add**********************/
add_filter ( 'nav_menu_css_class', 'so_37823371_menu_item_class', 10, 4 );
function so_37823371_menu_item_class ( $classes, $item, $args, $depth ){
  $classes[] = 'nav-item';
  return $classes;
}
/****************li a class add******************/
function add_link_atts($atts) {
  $atts['class'] = "nav-link";
  return $atts;
}
add_filter( 'nav_menu_link_attributes', 'add_link_atts');
/****************Active class********************/
add_filter('nav_menu_css_class' , 'special_nav_class' , 10 , 2);
function special_nav_class ($classes, $item) {
    if (in_array('current-menu-item', $classes) ){
        $classes[] = 'active ';
    }
    return $classes;
}

//article
function article() {
	$labels = array(
		'name'                  => _x( 'Article', 'Article General Name', 'Article' ),
		'singular_name'         => _x( 'Article', 'Article Singular Name', 'Article' ),
		'menu_name'             => __( 'Article', 'Article' ),
		'name_admin_bar'        => __( 'Article', 'Article' ),
		'archives'              => __( 'Article Archives', 'Article' ),
		'parent_item_colon'     => __( 'Parent Article:', 'Article' ),
		'all_items'             => __( 'All Article', 'Article' ),
		'add_new_item'          => __( 'Add New Article', 'Article' ),
		'add_new'               => __( 'Add Article', 'Article' ),
		'new_item'              => __( 'New Article', 'Article' ),
		'edit_item'             => __( 'Edit Article', 'Article' ),
		'update_item'           => __( 'Update Article', 'Article' ),
		'view_item'             => __( 'View Article', 'Article' ),
		'search_items'          => __( 'Search Article', 'Article' ),
		'not_found'             => __( 'Not found', 'Article' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'Article' ),
		'featured_image'        => __( 'Featured Image', 'Article' ),
		'set_featured_image'    => __( 'Set featured image', 'Article' ),
		'remove_featured_image' => __( 'Remove featured image', 'Article' ),
		'use_featured_image'    => __( 'Use as featured image', 'Article' ),
		'insert_into_item'      => __( 'Insert into item', 'Article' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'Article' ),
		'items_list'            => __( 'Items list', 'Article' ),
		'items_list_navigation' => __( 'Items list navigation', 'Article' ),
		'filter_items_list'     => __( 'Filter items list', 'Article' ),
	);
	$args = array(
		'label'                 => __( 'Article', 'Article' ),
		'description'           => __( 'Article Description', 'Article' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'trackbacks', 'revisions', 'custom-fields', 'page-attributes', 'post-formats', ),
		//'taxonomies'            => array( 'category', 'post_tag' ),
		//'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-admin-post',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => false,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
        "show_in_rest" => true,
        "rest_base" => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
		//'rewrite'				=> false
	);
	register_post_type( 'article', $args );
}
add_action( 'init', 'article', 0 );

//glossary
function glossary() {
	$labels = array(
		'name'                  => _x( 'Glossary', 'Glossary General Name', 'Glossary' ),
		'singular_name'         => _x( 'Glossary', 'Glossary Singular Name', 'Glossary' ),
		'menu_name'             => __( 'Glossary', 'Glossary' ),
		'name_admin_bar'        => __( 'Glossary', 'Glossary' ),
		'archives'              => __( 'Glossary Archives', 'Glossary' ),
		'parent_item_colon'     => __( 'Parent Glossary:', 'Glossary' ),
		'all_items'             => __( 'All Glossary', 'Glossary' ),
		'add_new_item'          => __( 'Add New Glossary', 'Glossary' ),
		'add_new'               => __( 'Add Glossary', 'Glossary' ),
		'new_item'              => __( 'New Glossary', 'Glossary' ),
		'edit_item'             => __( 'Edit Glossary', 'Glossary' ),
		'update_item'           => __( 'Update Glossary', 'Glossary' ),
		'view_item'             => __( 'View Glossary', 'Glossary' ),
		'search_items'          => __( 'Search Glossary', 'Glossary' ),
		'not_found'             => __( 'Not found', 'Glossary' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'Glossary' ),
		'featured_image'        => __( 'Featured Image', 'Glossary' ),
		'set_featured_image'    => __( 'Set featured image', 'Glossary' ),
		'remove_featured_image' => __( 'Remove featured image', 'Glossary' ),
		'use_featured_image'    => __( 'Use as featured image', 'Glossary' ),
		'insert_into_item'      => __( 'Insert into item', 'Glossary' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'Glossary' ),
		'items_list'            => __( 'Items list', 'Glossary' ),
		'items_list_navigation' => __( 'Items list navigation', 'Glossary' ),
		'filter_items_list'     => __( 'Filter items list', 'Glossary' ),
	);
	$args = array(
		'label'                 => __( 'Glossary', 'Glossary' ),
		'description'           => __( 'Glossary Description', 'Glossary' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'trackbacks', 'revisions', 'custom-fields', 'page-attributes', 'post-formats', ),
		//'taxonomies'            => array( 'category', 'post_tag' ),
		//'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-admin-post',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => false,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
		//'rewrite'				=> false
        "show_in_rest" => true,
        "rest_base" => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
	);
	register_post_type( 'glossary', $args );
}
add_action( 'init', 'glossary', 0 );

//Cluster
function cluster() {
	$labels = array(
		'name'                  => _x( 'Cluster', 'Cluster General Name', 'Cluster' ),
		'singular_name'         => _x( 'Cluster', 'Cluster Singular Name', 'Cluster' ),
		'menu_name'             => __( 'Cluster', 'Cluster' ),
		'name_admin_bar'        => __( 'Cluster', 'Cluster' ),
		'archives'              => __( 'Cluster Archives', 'Cluster' ),
		'parent_item_colon'     => __( 'Parent Cluster:', 'Cluster' ),
		'all_items'             => __( 'All Cluster', 'Cluster' ),
		'add_new_item'          => __( 'Add New Cluster', 'Cluster' ),
		'add_new'               => __( 'Add Cluster', 'Cluster' ),
		'new_item'              => __( 'New Cluster', 'Cluster' ),
		'edit_item'             => __( 'Edit Cluster', 'Cluster' ),
		'update_item'           => __( 'Update Cluster', 'Cluster' ),
		'view_item'             => __( 'View Cluster', 'Cluster' ),
		'search_items'          => __( 'Search Cluster', 'Cluster' ),
		'not_found'             => __( 'Not found', 'Cluster' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'Cluster' ),
		'featured_image'        => __( 'Featured Image', 'Cluster' ),
		'set_featured_image'    => __( 'Set featured image', 'Cluster' ),
		'remove_featured_image' => __( 'Remove featured image', 'Cluster' ),
		'use_featured_image'    => __( 'Use as featured image', 'Cluster' ),
		'insert_into_item'      => __( 'Insert into item', 'Cluster' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'Cluster' ),
		'items_list'            => __( 'Items list', 'Cluster' ),
		'items_list_navigation' => __( 'Items list navigation', 'Cluster' ),
		'filter_items_list'     => __( 'Filter items list', 'Cluster' ),

	);
	$args = array(
		'label'                 => __( 'Cluster', 'Cluster' ),
		'description'           => __( 'Cluster Description', 'Cluster' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'trackbacks', 'revisions', 'custom-fields', 'page-attributes', 'post-formats', ),
		//'taxonomies'            => array( 'category', 'post_tag' ),
		//'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-admin-post',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => false,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
		//'rewrite'				=> false
        "show_in_rest" => true,
        "rest_base" => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
	);
	register_post_type( 'cluster', $args );
}
add_action( 'init', 'cluster', 0 );

/* Register taxonomy Type destination_cat */
add_action( 'init', 'create_our_gallery_cat_taxonomy' );
function create_our_gallery_cat_taxonomy() {
    register_taxonomy(
        'article_cat',
        'article',
        array(
            'label' => 'Article Category',
            'hierarchical' => true,
            'rewrite' => array( 'slug' => 'article_cat' ),
        )
    );
    register_taxonomy(
        'cluster_cat',
        array('article', 'cluster', 'post'),
        array(
            'label' => 'Cluster Category',
            'hierarchical' => true,
            'rewrite' => array( 'slug' => 'cluster_cat' ),
        )
    );
    register_taxonomy(
        'glossary_cat',
        array('article', 'glossary', 'post'),
        array(
            'label' => 'Glossary Category',
            'hierarchical' => true,
            'rewrite' => array( 'slug' => 'glossary_cat' ),
        )
    );
}

add_action( 'transition_post_status', 'send_mails_on_publish', 10, 3 );
{
    // Check if we are transitioning from pending to publish
	function send_mails_on_publish( $new_status, $old_status, $post ){
		if ( $post->post_status == 'publish'  &&  $post->post_type == 'cluster' ) {
				$cattitle = get_the_title($postid);
				$category = array('taxonomy'=>'cluster_cat','cat_name'=> $cattitle);
				wp_insert_category($category);
		}
	}
}


/**********************************************/




/*****************Most view post******************/
function count_post_visits() {
  if( is_single() ) {
     global $post;
     $views = get_post_meta( $post->ID, 'my_post_viewed', true );
     if( $views == '' ) {
        update_post_meta( $post->ID, 'my_post_viewed', '1' );
     } else {
        $views_no = intval( $views );
        update_post_meta( $post->ID, 'my_post_viewed', ++$views_no );
     }
  }
}
add_action( 'wp_head', 'count_post_visits' );
/****************************************************/


//widgets register start
add_action( 'widgets_init', 'footer_widgets_init' );
function footer_widgets_init() {
    register_sidebar( array(
        'name' => __( 'Footer One', 'theme-slug' ),
        'id' => 'footer-1',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widgettitle">',
        'after_title'   => '</h2>',
    ));
    register_sidebar( array(
        'name' => __( 'Footer Two', 'theme-slug' ),
        'id' => 'footer-2',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widgettitle">',
        'after_title'   => '</h2>',
    ));
    register_sidebar( array(
        'name' => __( 'Footer Three', 'theme-slug' ),
        'id' => 'footer-3',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widgettitle">',
        'after_title'   => '</h2>',
    ));
    register_sidebar( array(
        'name' => __( 'Footer Four', 'theme-slug' ),
        'id' => 'footer-4',
        'description' => __( 'Subscribe Division', 'theme-slug' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widgettitle">',
        'after_title'   => '</h2>',
    ));
}

function arphabet_widgets_init() {

    register_sidebar( array(
        'name' => 'Home right sidebar',
        'id' => 'home_right_1',
        'before_widget' => '<div>',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="rounded">',
        'after_title' => '</h2>',
    ) );
}
add_action( 'widgets_init', 'arphabet_widgets_init' );

if( function_exists('acf_add_options_page') ) {
    acf_add_options_page(array(
        'page_title' 	=> 'Theme General Settings',
        'menu_title'	=> 'Theme Settings',
        'menu_slug' 	=> 'theme-general-settings',
        'capability'	=> 'edit_posts',
        'redirect'		=> false
    ));
    acf_add_options_sub_page(array(
		'page_title' 	=> 'Theme Header Settings',
		'menu_title'	=> 'Header',
		'parent_slug'	=> 'theme-general-settings',
	));
	acf_add_options_sub_page(array(
		'page_title' 	=> 'Theme Social Popup',
		'menu_title'	=> 'Social Popup',
		'parent_slug'	=> 'theme-general-settings',
	));
	acf_add_options_sub_page(array(
		'page_title' 	=> 'Theme Footer Settings',
		'menu_title'	=> 'Footer',
		'parent_slug'	=> 'theme-general-settings',
	));
}


function add_class_to_all_links($content){
    /* Filter by Qassim Hassan - https://wp-time.com */
    $glossaryClass = 'class="glossary-link"'; // your link class
    $glossaryURL=site_url()."/glossary/";
    $add_class = str_replace('<a href="'.$glossaryURL, '<a '.$glossaryClass.' href="'.$glossaryURL, $content); // add class
    return $add_class; // display class in links
}
add_filter('the_content', 'add_class_to_all_links', 9999);

/********************desible ****************/
add_action( 'template_redirect', 'wpse_128636_redirect_post' );
function wpse_128636_redirect_post() {
  if ( is_singular( 'mapeia-carousel' ) ) {
    wp_redirect(get_template_part( 404 ));
    exit;
  }
}

