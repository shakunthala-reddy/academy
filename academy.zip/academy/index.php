<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage MAPEIA
 * @since MAPEIA 1.0
 */

get_header();
?>

<section class="blog-section one-col-section">
    <div class="container">
        <?php while(have_posts()): the_post(); ?>
        <?php the_content(); ?>
        <?php endwhile; ?>
    </div>
</section>




<?php get_footer(); ?>