<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage MAPEIA
 * @since MAPEIA 1.0
 */

get_header();

$excludedBlogPosts=[];
$excludedArticlePosts=[];
?>
<div class="main-wrapper-div">
<?php while ( have_posts() ) : the_post(); ?>
    <?php
    $current_post_id = get_the_ID();
    array_push($excludedBlogPosts, $current_post_id);
    ?>
    <script>
        WP_URLS.current_post_id = <?=$current_post_id ?>;
        WP_URLS.excluded_article_posts = <?php echo json_encode($excludedArticlePosts);?>;
        WP_URLS.excluded_blog_posts = <?php echo json_encode($excludedBlogPosts);?>;
        WP_URLS.counter = 1;
        runAjax = true;
    </script>

    <?php
    get_template_part('/template-parts/blog/blog-section');
    ?>

<?php endwhile; ?>

<div class="scroll-result"></div>
<div class="loading text-center">
    <img src="<?= get_template_directory_uri() ?>/images/loading.svg" alt="loading">
</div>

</div>
<?php
get_footer(); ?>

