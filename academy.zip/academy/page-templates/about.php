<?php 
/*
* Template Name: About
*/

get_header();

?>
<div class="main-wrapper-div">
<section class="container-fluid left-right-sidebar-template p-0">
<div class="container">
        <div class="row"> 
            <div class="col-lg-3 left-sidebar-content-wrap">
            <?php echo do_shortcode('[ez-toc]'); ?>
        </div>
       
        <!--content started -->
        <div class="col-lg-6 main-content-wrap">
        <section class="AboutUs">
             <h2 id="about-us"><?php echo get_field("about_us_title"); ?></h2>
             <p><?php echo get_field("about_us_desc"); ?></p>
        </section>

        <section class="OurMission">
             <h2 id="mission-vision"><?php echo get_field("our_mission_title"); ?></h2>
             <p><?php echo get_field("our_mission_desc"); ?></p>
         </section>

         <section class="OurCulture&Values">
            <h2 id="our-values"><?php echo get_field("our_culture_&_values_title"); ?></h2>
            <p><?php echo get_field("our_culture_&_values_desc"); ?></p>
        </section>

        <section class="Our Team">
            <h2 id="our-team"><?php echo get_field("our_team_title"); ?></h2>
            <p><?php echo get_field("our_team_desc"); ?></p>
        
            <!-- <h2 id="team-list">Team List</h2> -->
            <?php 
            if( have_rows('team_details') ):
            while( have_rows('team_details') ) : the_row();
                // Get parent value.
                $team_name = get_sub_field('name');
                $team_desgination = get_sub_field('desgination');
                $team_profile = get_sub_field('team_profile');
                $team_description = get_sub_field('description');
                $team_facebook = get_sub_field('facebook');
                $team_twitter = get_sub_field('twitter');
                $team_gmail = get_sub_field('gmail');
                $team_watsapp = get_sub_field('watsapp');
                $team_instagram = get_sub_field('instagram');
                $team_linkedin = get_sub_field('linkedin');
            ?>
            <button class="collapsiblenew countsec">
                <div class="row">
                    <div class="col-12">
                        <div class="team-profile">
                            <?php if($team_profile){ ?>
                            <figure>
                                <img src="<?php echo $team_profile; ?>" alt="<?php echo $team_name; ?>">
                            </figure>
                            <?php } else { ?>
                            <figure>
                                <img src="<?php echo get_template_directory_uri(); ?>/images/map-academy-default-article-thumb.jpg" alt="<?php echo $team_name; ?>">
                            </figure>
                            <?php } ?>
                        </div>
                        <div class="team-description">
                            <span class="team-name"><?php echo $team_name; ?></span>
                            <span class="list-designation">
                                <?php echo $team_desgination; ?>
                            </span>
                        </div>
                    </div>
                </div>
            </button>
            <div class="listcontent countsec"> 
                <p><?php echo $team_description; ?></p>
                <div class="icon-section">
                    <?php if ($team_facebook) { ?>
                        <span class="facebook-share"><a href="<?php echo $team_facebook; ?>" target="_blank"><i class="icon icon-facebook"></i></a></span>
                    <?php }
                    if ($team_twitter) { ?>
                        <span class="twitter-share"><a href="<?php echo $team_twitter; ?>" target="_blank"><i class="icon icon-twitter"></i></a></span>
                    <?php }
                    if ($team_gmail) { ?>
                        <span class="email-share"><a href="mailto:<?php echo $team_gmail; ?>"><i class="icon icon-mail"></i></a></span>
                    <?php }
                    if ($team_watsapp) { ?>
                        <span class="whatsaap-share"><a href="<?php echo $team_watsapp; ?>" target="_blank"><i class="icon icon-whatsapp"></i></a></span>
                    <?php }
                    if ($team_instagram) { ?>
                        <span class="instagram-share"><a href="<?php echo $team_instagram; ?> " target="_blank"><i class="icon icon-instagram"></i></a></span>
                    <?php } 
                    if ($team_linkedin) { ?>
                        <span class="instagram-linkedin"><a href="<?php echo $team_linkedin; ?>" target="_blank"><i class="icon icon-linkedin"></i></a></span>
                    <?php } ?>
                </div>
            </div> 
            <?php 
            endwhile;?>                   
            <?php endif; ?>
        </section>

      <section class="AcademicReviewPanel">
            <h2 id="academic-review-panel"><?php echo get_field("academic_review_panel_title"); ?></h2>
            <p><?php echo get_field("academic_review_panel_desc"); ?></p>
        </section>

        <section class="OurProjects">
            <h2 id="our-process-approach"><?php echo get_field("our_process_approach_title"); ?></h2>
            <p><?php echo get_field("our_process_approach_desc"); ?></p>
        </section>

        <section class="OurProjects">
            <h2 id="educational-partnerships"><?php echo get_field("education_partner_title"); ?></h2>
            <p><?php echo get_field("education_partner_desc"); ?></p>
        </section>
        <section class="PolicyonSexualHarrassment">
            <h2 id="policy-on-sexual-harrassment"><?php echo get_field("policy_on_sexual_harrasment_title"); ?></h2>
            <p><?php echo get_field("policy_on_sexual_harrassment_desc"); ?></p>
        </section>
        <!--content end -->


        </div>
        <div class="col-lg-3 main-content-wrap">
            <div class="about-img">
                <img src="<?php echo get_template_directory_uri(); ?>/images/bhuta-mask.jpg" alt="Dancer's Headpiece">
                <p class="about-caption">Dancer's Headpiece in the Form of a Panjurli Bhuta (boar spirit deity), 18th century, copper alloy, Kerala. Courtesy the Los Angeles County Museum of Art.</p>
            </div>              
        </div>
    </div>
</section>

</div>
<?php get_footer(); ?>

<script>
    $('.left-sidebar-content-wrap li > a').click(function() {
        $('.left-sidebar-content-wrap li > a').removeClass();
        $(this).addClass('active');
    })
</script>

<script>
var coll = document.getElementsByClassName("collapsiblenew");
var i;
//alert(coll.length);
for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("activenew");
    var content = this.nextElementSibling;
    if (content.style.maxHeight){
      content.style.maxHeight = null;
    } else {
      content.style.maxHeight = content.scrollHeight + "px";
    } 
  });
}
</script>


<script>
// $(document).ready(function(){
// $(".collapsiblenew").first().addClass("activenew");
//      $('button.countsec:gt(2)').hide();
//     $('div.countsec:gt(2)').hide();
// $(".collapsiblenew-button").click(function(){
//    $('button.countsec:gt(2)').show();
//     $('div.countsec:gt(2)').show();
//     $(".collapsiblenew-button").hide();
// });
// });
</script>
<script>
    jQuery(function() {
        jQuery('a[href*=#]:not([href=#])').click(function() {
            if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
                var target = jQuery(this.hash);
                target = target.length ? target : jQuery('[name=' + this.hash.slice(1) +']');
                if (target.length) {
                    jQuery('html,body').animate({
                    scrollTop: target.offset().top -130
                    }, 0);
                    return false;
                }
            }
        });
    });
</script>
