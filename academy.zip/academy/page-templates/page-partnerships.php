<?php 
/*
* Template Name: Partnerships
*/

get_header();

?>
<div class="main-wrapper-div">
<section class="container-fluid left-right-sidebar-template p-0">
    <div class="container">
        <div class="row"> 
            <div class="col-lg-3 left-sidebar-content-wrap">
            <?php echo do_shortcode('[ez-toc]'); ?>
        </div>
       
        <!--content started -->
        <div class="col-lg-9 main-content-wrap">
            <!--Partnership-->
            <section class="partnerships">
                <div class="container-full">
                    <div class="row">
                        <div class="col-lg-8">
                            <h2 id="partnerships"><?php the_field('partnerships_title'); ?></h2>
                            <?php if( get_field('partnerships_image') ): ?>
                            <div class="partner-img-mobile">
                                <img src="<?php the_field('partnerships_image'); ?>" alt="Dancer's Headpiece">
                            </div>
                            <?php endif; ?>
                            <?php the_field('partnerships_description'); ?>
                        </div>
                        <div class="col-md-4">
                            <?php if( get_field('partnerships_image') ): ?>
                            <div class="partner-img">
                                <img src="<?php the_field('partnerships_image'); ?>" alt="Dancer's Headpiece">
                            </div> 
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </section>
            <!--end-->
            <!--List of Partner-->
            <?php
            if( have_rows('adding_all_partner_here') ):
            while( have_rows('adding_all_partner_here') ) : the_row();
                $title_of_the_partner = get_sub_field('title_of_the_partner');
                $slug_of_the_partner = get_sub_field('slug_of_the_partner');
                $short_description_of_the_partner = get_sub_field('short_description_of_the_partner');
                $image_of_the_partner = get_sub_field('image_of_the_partner');
            ?>
            <section class="partnerships">
                <div class="container-full">
                    <div class="row">
                        <div class="col-lg-8">
                            <h2 id="<?php echo $slug_of_the_partner; ?>"><?php echo $title_of_the_partner; ?></h2>
                            <div class="partner-img-mobile">
                                <img src="<?php echo $image_of_the_partner; ?>" alt="Dancer's Headpiece">
                            </div>
                            <?php echo $short_description_of_the_partner; ?>
                        </div>
                        <div class="col-md-4">
                            <div class="partner-img">
                                <img src="<?php echo $image_of_the_partner; ?>" alt="Dancer's Headpiece">
                            </div> 
                        </div>
                    </div>
                </div>
            </section>
            <?php endwhile; endif; ?>
            <!--end-->
            <!-- <section class="tcs-on">
                <div class="container-full">
                    <div class="row">
                        <div class="col-lg-8">
                            <h2 id="tcs-ion"><?php the_field('tcs_ion_title'); ?></h2>
                            <?php if( get_field('tcs_ion_image') ): ?>
                            <div class="partner-img-mobile">
                                <img src="<?php the_field('tcs_ion_image'); ?>" alt="Dancer's Headpiece">
                            </div> 
                            <?php endif; ?> 
                            <?php the_field('tcs_ion_description', false, false); ?>
                        </div>
                        <div class="col-lg-4">
                            <?php if( get_field('tcs_ion_image') ): ?>
                            <div class="partner-img">
                                <img src="<?php the_field('tcs_ion_image'); ?>" alt="Dancer's Headpiece">
                            </div> 
                            <?php endif; ?>              
                        </div>
                    </div>
                </div>
            </section>

            <section class="microsoft">
                <div class="container-full">
                    <div class="row">
                        <div class="col-lg-8">
                            <h2 id="microsoft"><?php the_field('microsoft_title'); ?></h2>
                            <?php if( get_field('microsoft_image') ): ?>
                            <div class="partner-img-mobile">
                                <img src="<?php the_field('microsoft_image'); ?>" alt="Dancer's Headpiece">
                            </div>
                            <?php endif; ?>
                            <?php the_field('microsoft_description', false, false); ?>
                        </div>
                        <div class="col-lg-4">
                            <?php if( get_field('microsoft_image') ): ?>
                            <div class="partner-img">
                                <img src="<?php the_field('microsoft_image'); ?>" alt="Dancer's Headpiece">
                            </div> 
                            <?php endif; ?>             
                        </div>
                    </div>
                </div>
            </section>

            <section class="srishti-school-of-art-design">
                <div class="container-full">
                    <div class="row">
                        <div class="col-lg-8">
                            <h2 id="srishti-school-of-art-design"><?php the_field('srishti_school_of_art_&_design_title'); ?></h2>
                            <?php if( get_field('srishti_school_of_art_&_design_image') ): ?>
                            <div class="partner-img-mobile">
                                <img src="<?php the_field('srishti_school_of_art_&_design_image'); ?>" alt="Dancer's Headpiece">
                            </div>
                            <?php endif; ?>
                            <?php the_field('srishti_school_of_art_&_design_description', false, false); ?>
                        </div>
                        <div class="col-lg-4">
                            <?php if( get_field('srishti_school_of_art_&_design_image') ): ?>
                            <div class="partner-img">
                                <img src="<?php the_field('srishti_school_of_art_&_design_image'); ?>" alt="Dancer's Headpiece">
                            </div> 
                            <?php endif; ?>             
                        </div>
                    </div>
                </div>
            </section>

            <section class="art-photography-foundation">
                <div class="container-full">
                    <div class="row">
                        <div class="col-lg-8">
                            <h2 id="art-photography-foundation"><?php the_field('art_&_photography_foundation_title'); ?></h2>
                            <?php if( get_field('art_&_photography_foundation_image') ): ?>
                            <div class="partner-img-mobile">
                                <img src="<?php the_field('art_&_photography_foundation_image'); ?>" alt="Dancer's Headpiece">
                            </div>
                            <?php endif; ?>
                            <?php the_field('art_&_photography_foundation_description', false, false); ?>
                        </div>
                        <div class="col-lg-4">
                            <?php if( get_field('art_&_photography_foundation_image') ): ?>
                            <div class="partner-img">
                                <img src="<?php the_field('art_&_photography_foundation_image'); ?>" alt="Dancer's Headpiece">
                            </div>
                            <?php endif; ?>              
                        </div>
                    </div>
                </div>
            </section> -->
            <!--content end -->
        </div>
    </div>
</section>

</div>
<?php get_footer(); ?>

<script>
    $('.left-sidebar-content-wrap li > a').click(function() {
        $('.left-sidebar-content-wrap li > a').removeClass();
        $(this).addClass('active');
    })
</script>

<script>
var coll = document.getElementsByClassName("collapsiblenew");
var i;
//alert(coll.length);
for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("activenew");
    var content = this.nextElementSibling;
    if (content.style.maxHeight){
      content.style.maxHeight = null;
    } else {
      content.style.maxHeight = content.scrollHeight + "px";
    } 
  });
}
</script>

<script>
    jQuery(function() {
        jQuery('a[href*=#]:not([href=#])').click(function() {
            if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
                var target = jQuery(this.hash);
                target = target.length ? target : jQuery('[name=' + this.hash.slice(1) +']');
                if (target.length) {
                    jQuery('html,body').animate({
                    scrollTop: target.offset().top -130
                    }, 0);
                    return false;
                }
            }
        });
    });
</script>
