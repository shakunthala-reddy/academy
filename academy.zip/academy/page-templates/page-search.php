<?php
/*
    Template Name: Search page template
*/

get_header();

// getting query parameters to retain checkbox status
$query = explode('&', $_SERVER['QUERY_STRING']);
$params = array();
$tablets = array();
if (!empty($query)) {
    foreach ($query as $param) {
        if (!empty($param)) {

            // prevent notice on explode() if $param has no '='
            if (strpos($param, '=') === false) $param += '=';
            list($name, $value) = explode('=', $param, 2);
            $params[urldecode($name)][] = urldecode($value);
            // storing query parameters to array to set feedback pills
            if ($name != 'result') {
                array_push($tablets, $value);
            }
            foreach ($tablets as $key => $value) {
                if (empty($value)) {
                    unset($tablets[$key]);
                }
            }
        }
    }

}


?>

<!-- mainly 1-->

<!--To Do : move css to external file | Apply this css only on search page -->
<style>
    header {
        margin-bottom: 0;
        border: none;
    }

    body {
        padding-top: 56px;
    }

    header .navbar {
        border: none;
    }
</style>

<section class=" d-md-none mobile-search-filter mt-1">
    <div class="container no-padding-mobile">
        <div class="row">
            <div class="col-6 mobi-filter-dropdown ">

                <div class="btn btn-light filter-button">
                <span class="">Sort by <img
                            src="<?= get_template_directory_uri() ?>/images/sort.png"
                            class="ml-1"
                            alt="Sort by"></span>
                </div>
            </div>
            <div class="col-6 ">
                <div class="btn btn-light filter-button toggle-filter">
                <span class="">Filter <img
                            src="<?= get_template_directory_uri() ?>/images/filter.png"
                            class="ml-1 filter-icon"
                            alt="Filter"><span class="filter-counter ml-1"><?= count($tablets) ?></span></span>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="row mobi-filter-dropdown-elements">
    <div class="container">
        <div class="list-group mt-3">
            <button type="button" value="r" class="list-group-item list-group-item-action ">Relevance</button>
            <button type="button" value="a" class="list-group-item list-group-item-action">A-Z</button>
            <button type="button" value="z" class="list-group-item list-group-item-action">Z-A</button>
<!--            <button type="button" value="t" class="list-group-item list-group-item-action">Time</button>-->
        </div>
    </div>
</div>


<div class="mobi-filter-wrapper d-md-none">
    <div class="mobi-filter  ">
        <div class="append-block "></div>
        <div class="filter-buttons">

            <div class="reset-button ">
                Reset
            </div>
            <div class="apply-button ">
                Apply
            </div>

        </div>
    </div>
</div>

<section>
    <div class="container search-filter no-padding-mobile">

        <div class="row">
            <div class="col-md-3 filters d-none d-md-block ">
                <div class="heading-box d-none d-md-block pb-0">
                    <span class="h3">Content Type</span>
                </div>
                <div class="scroll1 filter-elements">

                    <div class="filter-margin " id="post-types">
                        <div class="form-check p-custom" style="display: block !important;">
                            <input class="form-check-input formInput" type="checkbox" id="article"
                                   name="post-types" value="article" data-text="Article"
                                <?php if (in_array('article', $params["post-types"])) {
                                    echo 'checked';
                                } ?>
                            >
                            <label class="form-check-label" for="article">
                                Articles
                            </label>
                        </div>

                        <div class="form-check p-custom">
                            <input class="form-check-input formInput" type="checkbox" id="glossary"
                                   name="post-types" value="glossary" data-text="Glossary"
                                <?php if (in_array('glossary', $params["post-types"])) {
                                    echo 'checked';
                                } ?>
                            >
                            <label class="form-check-label" for="glossary">
                                Glossaries
                            </label>
                        </div>

                        <!--                                            <div class="form-check p-custom">-->
                        <!--                                                <input class="form-check-input formInput" type="checkbox" id="article"-->
                        <!--                                                       name="post-types" value="article" data-text="Articles & Glossaries"-->
                        <!--                                                    --><?php //if (in_array('article', $params["post-types"])) {
                        //                                                        echo 'checked';
                        //                                                    } ?>
                        <!--                                                >-->
                        <!--                                                <label class="form-check-label" for="article">-->
                        <!--                                                    Articles & Glossaries-->
                        <!--                                                </label>-->
                        <!--                                            </div>-->


                        <div class="form-check p-custom">
                            <input class="form-check-input formInput" type="checkbox" id="post"
                                   name="post-types" value="post" data-text="Blog"
                                <?php if (in_array('post', $params["post-types"])) {
                                    echo 'checked';
                                } ?>
                            >
                            <label class="form-check-label" for="post">
                                Blog
                            </label>
                        </div>

                        <div class="form-check p-custom">
                            <input class="form-check-input formInput" type="checkbox" id="cluster"
                                   name="post-types" value="cluster" data-text="Cluster"
                                <?php if (in_array('cluster', $params["post-types"])) {
                                    echo 'checked';
                                } ?>
                            >
                            <label class="form-check-label" for="cluster">
                                Clusters
                            </label>
                        </div>


                    </div>

                    <div class="filter-margin" id="departments">
                        <span class="h4 filter-dropdown">Department</span>
                        <?php
                        $tax_terms = get_terms(
                            'department',
                            array('hide_empty' => true)
                        ); ?>
                        <?php foreach ($tax_terms as $tax_term) { ?>
                            <div class="form-check p-custom">
                                <input class="form-check-input formInput" type="checkbox"
                                       id="<?= $tax_term->slug ?>"
                                       name="department"
                                       value="<?= $tax_term->slug ?>"
                                       data-text="<?= $tax_term->name ?>"
                                    <?php
                                    if (!empty($params["department"])) {
                                        if (!empty(in_array($tax_term->slug, $params["department"]))) {
                                            echo 'checked';
                                        }
                                    }
                                    ?>
                                >
                                <label class="form-check-label" for="<?= $tax_term->slug ?>">
                                    <?= $tax_term->name ?>
                                </label>
                            </div>

                        <?php } ?>
                    </div>


                    <div class="filter-margin" id="categories">
                        <span class="h4 filter-dropdown">Category</span>
                        <?php
                        $tax_terms = get_terms(
                            'custom_category',
                            array('hide_empty' => true)
                        ); ?>
                        <?php foreach ($tax_terms as $tax_term) { ?>

                            <div class="form-check p-custom">
                                <input class="form-check-input formInput" type="checkbox"
                                       id="<?= $tax_term->slug ?>"
                                       name="categories"
                                       value="<?= $tax_term->slug ?>"
                                       data-text="<?= $tax_term->name ?>"
                                    <?php
                                    if (!empty($params["categories"])) {

                                        if (in_array($tax_term->slug, $params["categories"])) {
                                            echo 'checked';
                                        }
                                    } ?>
                                >
                                <label class="form-check-label" for="<?= $tax_term->slug ?>">
                                    <?= $tax_term->name ?>
                                </label>
                            </div>

                        <?php } ?>
                    </div>

                    <div class="filter-margin" id="period">
                        <span class="h4 filter-dropdown">Period</span>
                        <?php
                        $tax_terms = get_terms(
                            'period',
                            array('hide_empty' => true)
                        ); ?>
                        <?php foreach ($tax_terms as $tax_term) { ?>
                            <div class="form-check p-custom">
                                <input class="form-check-input formInput" type="checkbox"
                                       id="<?= $tax_term->slug ?>"
                                       name="period"
                                       value="<?= $tax_term->slug ?>"
                                       data-text="<?= $tax_term->name ?>"
                                    <?php
                                    if (!empty($params["period"])) {
                                        if (in_array($tax_term->slug, $params["period"])) {
                                            echo 'checked';
                                        }
                                    } ?>
                                >
                                <label class="form-check-label" for="<?= $tax_term->slug ?>">
                                    <?= $tax_term->name ?>
                                </label>
                            </div>


                        <?php } ?>
                    </div>

                    <div class="filter-margin" id="region">
                        <span class="h4 filter-dropdown">Region</span>
                        <?php
                        $tax_terms = get_terms(
                            'region',
                            array('hide_empty' => true)
                        ); ?>
                        <?php foreach ($tax_terms as $tax_term) { ?>

                            <div class="form-check p-custom">
                                <input class="form-check-input formInput" type="checkbox"
                                       id="<?= $tax_term->slug ?>"
                                       name="region"
                                       value="<?= $tax_term->slug ?>"
                                       data-text="<?= $tax_term->name ?>"
                                    <?php
                                    if (!empty($params["region"])) {
                                        if (in_array($tax_term->slug, $params["region"])) {
                                            echo 'checked';
                                        }
                                    } ?>
                                >
                                <label class="form-check-label" for="<?= $tax_term->slug ?>">
                                    <?= $tax_term->name ?>
                                </label>
                            </div>


                        <?php } ?>
                    </div>

                    <div class="filter-margin" id="occupation">
                        <span class="h4 filter-dropdown">Occupation</span>
                        <?php
                        $tax_terms = get_terms(
                            'occupation',
                            array('hide_empty' => true)
                        ); ?>
                        <?php foreach ($tax_terms as $tax_term) { ?>


                            <div class="form-check p-custom">
                                <input class="form-check-input formInput" type="checkbox"
                                       id="<?= $tax_term->slug ?>"
                                       name="occupation"
                                       value="<?= $tax_term->slug ?>"
                                       data-text="<?= $tax_term->name ?>"
                                    <?php
                                    if (!empty($params["occupation"])) {
                                        if (in_array($tax_term->slug, $params["occupation"])) {
                                            echo 'checked';
                                        }
                                    } ?>
                                >
                                <label class="form-check-label" for="<?= $tax_term->slug ?>">
                                    <?= $tax_term->name ?>
                                </label>
                            </div>


                        <?php } ?>
                    </div>
                </div>

            </div>
            <div class="col-md-6 no-padding-mobile">
                <div class="heading-box d-none d-md-block p-0">
                    <!--                    <span class="h3 ">Search Results</span>-->
                </div>
                <div class="scroll result">

                    <div class="result-add  col">

                    </div>
                    <div class="loading text-center">
                        <img src="<?= get_template_directory_uri() ?>/images/loading.svg" alt="loading">
                    </div>
                </div>


            </div>
            <div class="col-md-3 d-none d-md-block">
                <div class="heading-box drop-down-padding">
<!--                    <span class="h3 ">Sort <span class="result-count"></span> </span>-->
                    <span class="h3 ">Sort  </span>
                </div>

                <div class="row">
                    <div class="col">
                        <div class="form-group ">
                            <select class="form-control form-control-lg filter-sorting" id="sel1">
                                <option value="r">Relevance</option>
                                <option value="a">A-Z</option>
                                <option value="z">Z-A</option>
<!--                                <option value="t">Time</option>-->
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row py-3">

                    <div class="col">
                        <div class="d-flex flex-row flex-wrap justify-content-start filter-feedback">
                            <?php
                            $clearFlag = 0;
                            if (!empty($_GET['result'])) {
                                $clearFlag = 1;
                                ?>
                                <span class="sort-title  mr-3 search-text"><span class="close-pill">
                                                <i class="icon icon-cross"></i>
                                                </span>
                                                <span>"<?= $_GET['result'] ?>"</span>
                                        </span>
                            <?php }

                            if (!empty($tablets)):
                                foreach ($tablets as $tablet):
                                    $clearFlag = 1;
                                    if ($tablet == 'post') {
                                        $tabletName = "blog";
                                    } else {
                                        $tabletName = $tablet;
                                    }
                                    ?>

                                    <span class="sort-title  mr-3 ff-item" data-linker="<?= $tablet ?>">
                                        <span class="close-pill">
                                        <i class="icon icon-cross"></i>
                                        </span>
                                        <span><?= $tabletName ?></span>
                                    </span>

                                <?php endforeach;
                            endif;
                            ?>
                        </div>
                        <?php if ($clearFlag == 1): ?>
                            <span class="sort-title article-wrap-close mr-3 clear-all "><a
                                        href="<?= site_url() ?>/encyclopedia-search/"
                                        class="clear-allbtn"><span class="close-pill">  <i
                                                class="icon icon-cross"></i></span> <span>Clear all</a></span>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>

    </div>
</section>


<?php get_footer(); ?>
<script>
    var ppp = 20;
    var page = 0; // What page we are on.
    var runAjax = true;
    var sorter = 'a';
    var filterCounter = 0;
    var scrolled = false;
    locksort = 1;
    <?php
    if (!empty($pills)) {
        if (count($pills)) {
            echo "filterCounter=" . count($pills) . ";";
        }
    }
    ?>
    sortChange();
    ajax_call();

    var currentscrollHeight = 0;

    jQuery(function ($) {
        $(window).on("scroll", function () {
            const scrollHeight = $(document).height();
            const scrollPos = Math.floor($(window).height() + $(window).scrollTop());
            const isBottom = scrollHeight - 500 < scrollPos;
            if (isBottom && currentscrollHeight < scrollHeight) {
                ajax_call();
                currentscrollHeight = scrollHeight;
            }
        });
    });

    function sortChange() {
        if (locksort == 1) {
            if ($('.search-text').length != 0) {
                console.log("search exist" + $('.search-text').length);
                $(".filter-sorting").val("r");
                sorter = 'r';
                console.log(sorter);
            }
        }
    }

    $(document).ready(function () {

//        Infinite scroll Starts

//        $('.result').bind('scroll', function () {
//            if ($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight) {
//                ajax_call();
//            }
//        });


        $('.result').bind('scroll', function () {
            if ($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight) {
                ajax_call();
            }
        });
//        Infinite scroll Ends

        // When Filter is checked
        $(document).on("change", ".formInput", function () {
            var text = $(this).data("text");
            var value = $(this).val();
            var checked = $(this).is(":checked");

            // if the filter is checked then give feed back pills under the sorting dropdown. unchecked hide it
            if (checked) {
                $(".filter-feedback").append(
                    '<span  class="sort-title  mr-3 " data-linker="' + value + '"> <span class="close-pill">  <i class="icon icon-cross"></i></span> <span >' + text + '</span> </span>'
                )
            }
            else {
                $('[data-linker="' + value + '"]').hide();
            }
            reset_call();
        });

//        Get result on sorting selection (Relevance, A-Z , Z-A , Time)
        $(".filter-sorting").change(function () {
            sorter = $(".filter-sorting").val();
            locksort=0;
            reset_call();
        });


        $(".mobi-filter-dropdown-elements .list-group-item").click(function () {
            sorter = $(this).val();
            $(".mobi-filter-dropdown-elements").hide();
            console.log(sorter);
            reset_call();
        });


    });


    // When filter feedback pills are closed -> uncheck filters

    $(document).on("click", ".filter-feedback .close-pill", function () {


        var dataLinker = $(this).parent().data("linker");
        $(this).parent().remove();
        $("#" + dataLinker).prop('checked', false);
        if ($(this).parent().hasClass("search-text")) {
            $("#adv_search").val("");
        }
        reset_call();


    });


    function reset_call() {

        $(".result-add").html('');
        page = 0;
        currentscrollHeight = 0;
        runAjax = true;
        ajax_call();

    }

    function ajax_call() {
        if (!scrolled) {
            scrolled = true;
            if (runAjax) {
                sortChange();
                $('.loading').show();

                var post_types = $("#post-types :input").serialize();
                var categories = $("#categories :input").serialize();
                var departments = $("#departments :input").serialize();
                var period = $("#period :input").serialize();
                var region = $("#region :input").serialize();
                var occupation = $("#occupation :input").serialize();
                var search_term = $("#adv_search").val();
                console.log("search ter" + search_term);

                var offset = page * ppp;


//      Start Update the URL with selected filter values
                var siteurl = "<?php echo site_url('/wp-admin/admin-ajax.php'); ?>";
                var url = "<?php echo site_url();?>/encyclopedia-search/";
                if (search_term || post_types || categories || departments || period || region || occupation) {
                    url = url + "?";
                    if (search_term) {
                        url = url + "result=" + search_term;
                    }
                    if (post_types) {
                        url = url + "&" + post_types;
                    }
                    if (departments) {
                        url = url + "&" + departments;
                    }
                    if (categories) {
                        url = url + "&" + categories;
                    }
                    if (period) {
                        url = url + "&" + period;
                    }
                    if (region) {
                        url = url + "&" + region;
                    }
                    if (occupation) {
                        url = url + "&" + occupation;
                    }
                }
                window.history.pushState('', '', url);

//        End of : URL Udating

                if (($(".filter-feedback").children().length > 0) && ($(".clear-all").children().length == 0)) {
                    $(".filter-feedback").append(' <span class="sort-title  mr-3 clear-all "><a href="<?= site_url() ?>/encyclopedia-search/"class="clear-allbtn"><span class="close-pill">  <i class="icon icon-cross"></i></span> <span >Clear all</a></span>');
                }

                $(".clear-all").appendTo(".filter-feedback");

                console.log("ppp : " + ppp)
                console.log("offset : " + offset)

                jQuery.ajax({
                    type: 'POST',
                    url: siteurl,
                    data: {
                        action: 'get_adv_searchpagetag',
                        search_term: search_term,
                        post_types: post_types,
                        categories: categories,
                        departments: departments,
                        period: period,
                        region: region,
                        occupation: occupation,
                        sort: sorter,
                        offset: offset,
                        ppp: ppp

                    },
                    success: function (data, status) {
                        $('.loading').hide();
                        $(".result-add").append(data.content);
                        $(".result-count").html("(" + data.count + " results)");
                        page++;
                        if (!runAjax) {
                            $(".result-subbox:last .icon-box").css({"border-bottom": "none"});
                        }
                        scrolled = false;

                    }
                });
            }
        }
    }

    // Filter Dropdown (Hide and show filter options)

    $(document).ready(function () {
        $(".form-check").hide();
        $("#departments .form-check").show();
        $("#post-types .form-check").show();
        $(document).on("click", ".filter-dropdown", function () {
            $(this).siblings('.form-check').toggle();
        });
    });

    // custom scrolling


    // Mobile Filter


    $(document).ready(function () {
        if ($(window).width() < 768) {
            var html = $(".filter-elements").html();
            $(".append-block").html(html);
            fillCounter();
        }
        $(".mobi-filter-wrapper").hide();
    });

    $(window).bind('orientationchange', function (event) {
        location.reload(true);
    });

    $(".toggle-filter").click(function () {
        $(".mobi-filter-wrapper").toggle();
    });

    $(".reset-button").click(function () {
        window.location.href = "<?=site_url()?>/encyclopedia-search";
    });

    function fillCounter() {
        var totalChecked = 0;
        $(".mobi-filter input[type=checkbox]:checked").each(function () {
            totalChecked++;
        });
        console.log(totalChecked);
        if (totalChecked > 0) {

            $(".filter-counter").show();
            $(".filter-icon").hide();
            $(".filter-counter").html(totalChecked);
        }
        else {

            $(".filter-counter").hide();
            $(".filter-icon").show();
        }

    }

    $(".apply-button").click(function () {
        $(".mobi-filter-wrapper").hide();
        fillCounter();
    });

    $(".mobi-filter-wrapper").click(function (event) {
        if ($(event.target).closest('.mobi-filter').length === 0) {
            $(".mobi-filter-wrapper").hide();
            fillCounter();
        }
    });


    $(".mobi-filter-dropdown").click(function () {
        $(".mobi-filter-dropdown-elements").toggle();
    });


</script>

