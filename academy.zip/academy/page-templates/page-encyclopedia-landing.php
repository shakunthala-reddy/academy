<?php
/*
    Template Name: Encyclopedia landing page
*/
get_header();
?>
<div class="main-wrapper-div">
    <!--Welcome to the Encyclopedia-->
    <div class="eia-landing-page" id="map-banner">
        <?php $image = get_field('banner_img');
        $url = $image['url'];
        $alt = $image['alt']; ?>
        <section class="encl-banner-section banner-bg-image" style="background-image: url(<?php echo esc_url($url); ?>);">
            <div class="container-full">
                <div class="bottom-top-encl">
                    <h2 class="ld-tab-content short-course-details h2titleheading30px"> <?php echo get_field("banner_title"); ?></h2>
                    <p class="ptitleheading25px"><?php echo get_field("banner_desc"); ?></p>
                    <?php if (get_field('banner_button_text')): ?>
                        <p class="btn-banner-section"><a href="<?php the_field('banner_button_link'); ?>"
                                                         class="banner-btn-link"> <?php the_field('banner_button_text'); ?>  </a>
                        </p>
                    <?php endif; ?>
                </div>
                <!-- <div class="banner-img">
                    <img  src="<?php echo get_field("banner_img"); ?>" class="img-fluid main-banner-img">
                </div> -->

                <picture class="banner-img d-block d-md-none">
                    <!-- Desktop banner image -->

                    <source srcset="<?php echo esc_url($url); ?>" media="(min-width: 768px)"
                            class="img-fluid main-banner-img" alt="<?php echo esc_attr($alt); ?>">
                    <!-- Mobile banner image -->
                    <?php $image = get_field('banner_img_for_mobile_view');
                    $urlmob = $image['url'];
                    $altmob = $image['alt']; ?>
                    <img src="<?php echo esc_url($urlmob); ?>" class="img-fluid main-banner-img"
                         alt="<?php echo esc_attr($altmob); ?>">
                </picture>
            </div>
        </section>
        <span id="feature-article"></span>
    </div>

    <!--start article section-->
    <section class="white-bg sec1 bgblog-section one-col-section mt-4">
        <div class="container">
            <div class="short-course-details-wrap">
                <hr class="hr-border top1">
                <p class="h2titlecaps"><?php echo get_field("recently_published_title"); ?></p>
                <p class="subheading"><?php echo get_field("recently_published_desc"); ?></p>

                <img src="https://mapeia.langoorqa.net/wp-content/uploads/2022/04/article-icon.svg"
                     class="icon-title mobile-view" width="40px"
                     alt="<?php echo get_field("recently_published_title"); ?>">
                <hr class="hr-border bottom">
            </div>
            <!-- Desktop Version -->
            <div class="d-none d-lg-block">
                <div class="row">
                    <?php
                    if (have_rows('list_of_feature_article')):
                        while (have_rows('list_of_feature_article')) : the_row();
                            $feature_article_title = get_sub_field('feature_article_title');
                            $image = get_sub_field('feature_article_image');
                            //print_r($feature_article_image);
                            $artimgurl = $image['url'];
                            $artimgalt = $image['alt'];
                            $post = $feature_article_title;
                            setup_postdata($post);
                            ?>
                            <div class="col-lg-3 col-md-3 col-sm-12">
                                <div class="course-desc-footer p-0">
                                    <a href="<?php the_permalink(); ?>">
                                        <img src="<?php echo esc_url($artimgurl); ?>" class="art-img img-fluid w-100"
                                             alt="<?php echo esc_attr($artimgalt); ?>">
                                    </a>
                                    <div class="btn-left">
                                        <span class="mb-0 encl-article-title text-black"><a
                                                    href="<?php the_permalink(); ?>"><?php the_title(); ?> </a></span>
                                        <span class="icon-right">
                                            <a href="<?php the_permalink(); ?>"><span
                                                        class="icon icon-arrow-right"> </span></a>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <?php wp_reset_postdata(); endwhile; endif; ?>
                </div>

            </div>

            <!-- Mobile Version -->
            <ul class="d-block d-lg-none p-0">
                <?php
                if (have_rows('list_of_feature_article')):
                    while (have_rows('list_of_feature_article')) : the_row();
                        $feature_article_title = get_sub_field('feature_article_title');

                        $post = $feature_article_title;
                        setup_postdata($post);
                        ?>
                        <?php
                        if (get_the_post_thumbnail_url($post->ID)) {
                            $thumb_url = get_the_post_thumbnail_url($post->ID, 'thumbnail');
                            $thumbalttext = get_sub_field('feature_article_image');
                            $artalttext = $thumbalttext ['alt'];
                        } else {

                            $thumb_url = get_field('default_thumbnail', 'option');

                        }
                        ?>
                        <li class="media list-view">
                            <a href="<?php the_permalink(); ?>">
                                <img src="<?php echo $thumb_url; ?>" class="art-img" alt="<?php echo $artalttext; ?>">
                            </a>
                            <div class="media-body">
                                <h5 class="mt-0"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                <p class="pb-2"><?php
                                    $content = get_post_field('post_content');
                                    $pattern = "/(\[)(.*?)(\])/";
                                    $content = preg_replace($pattern, '', $content);
                                    $content = wp_trim_words($content, 11);

                                    echo $content;
                                    ?></p>

                                <hr class="hr-border mt-4">
                            </div>
                        </li>
                        <?php wp_reset_postdata(); endwhile; endif; ?>

            </ul>
            <div class="row">
                <div class="col text-center mt-1  mt-md-3 ">
                    <a class="subheading read-more-link" href="<?= site_url() ?>/encyclopedia-search/">More Articles</a>
                </div>
            </div>
        </div>
    </section>
</div>


<!--end article section-->

<!--Start cluster-->
<!-- <section class="banner_sec venue_banner">
    <div class="carousel slide">
        <?php
$args = array('post_type' => 'cluster',
    'post_status' => 'publish',
    'orderby' => 'post_date',
    'order' => 'DESC',
    'posts_per_page' => 1
);
$loop = new WP_Query($args);
if ($loop->have_posts()) :
    while ($loop->have_posts()) : $loop->the_post();
        ?>
                <div class="carousel-inner">
                    <div class="item">

                        <img class="img-responsive" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>">
                        <div class="carousel-caption">
                            <div class="row">
                                <div class="col-lg-2 col-md-2 col-sm-12"></div>
                                <div class="col-lg-8 col-md-8 col-sm-12">
                                    <div class="content-left">
                                        <h2><span class="txt1">Cluster</span></h2>
                                        <h2 class="h2titleheading-white"><?php the_title(); ?></h2>
                                        <a href="<?php the_permalink(); ?>" ><div class="btn read-more-cluster p-0" > Learn More  <i class="icon icon-arrow-right"></i></div></a>
                                    </div>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-12"></div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; endif;
wp_reset_query(); ?>
    </div>
    <p class="author-para p-2"><?php echo get_field("look_a_little_closer_auth"); ?></p>
</section> -->

<section class="white-bg sec1 bgblog-section one-col-section">
    <!-- <div class="container">
        <div class="short-course-details-wrap">
            <hr class="hr-border top1">
            <p class="h2titlecaps">ONLINE COURSES</p>
            <p class="subheading">Curated articles around a specific theme</p>
            <hr  class="hr-border bottom">
        </div>
    </div> -->
    <div class="container-full">
        <div class="row">
            <div class="banner-course ">
                <div class="bottom-top-encl2">
                    <?php if (get_field('short_courses_heading')): ?>
                        <div class="short-lable"><span
                                    class="short-course-lable"><?php echo the_field('short_courses_heading'); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if (get_field('short_courses_subheading')): ?>
                        <p class="short-courses-heading"><?php echo the_field('short_courses_subheading'); ?></p>
                    <?php endif; ?>
                    <?php if (get_field('short_courses_button_label')): ?>
                        <div><a href="<?php echo the_field('short_courses_button_link'); ?>"
                                class=" register-btn-link"
                                target="_blank"> <?php echo the_field('short_courses_button_label'); ?> <i
                                        class="icon icon-arrow-right"></i></a></div>
                    <?php endif; ?>
                </div>
                <?php if (get_field('short_courses_background_image')): ?>
                    <!-- <div class="banner-img2">
                    <img  src="<?php echo the_field('short_courses_background_image'); ?>" class="img-fluid main-banner-img">
                </div> -->
                    <?php $image = get_field('short_courses_background_image');
                    $shortcourseimageurl = $image['url'];
                    $shortcourseimagealt = $image['alt']; ?>
                    <div class="banner-bg-image d-none d-md-block" style="background-image: url(<?php echo esc_url($shortcourseimageurl); ?>);"></div>
                    <picture class="banner-img2 d-block d-md-none">
                        <!-- Desktop banner image -->

                        <source srcset="<?php echo esc_url($shortcourseimageurl); ?>"
                                media="(min-width: 768px)" class="img-fluid main-banner-img"
                                alt="<?php echo esc_attr($shortcourseimagealt); ?>">
                        <!-- Mobile banner image -->
                        <?php $shortcoursemobileview = get_field('short_courses_background_image_for_mobile_view');
                        $shortcoursemobileviewurl = $shortcoursemobileview['url'];
                        $shortcoursemobileviewalt = $shortcoursemobileview['alt']; ?>
                        <img src="<?php echo esc_url($shortcoursemobileviewurl); ?>"
                             class="img-fluid main-banner-img" alt="<?php echo esc_attr($shortcoursemobileviewalt); ?>">
                    </picture>
                <?php endif; ?>
                <p class="author-para"><?php the_field('short_courses_image_caption', false, false); ?></p>
            </div>
        </div>
    </div>
</section>


<!--End Cluster-->

<!--Start Cluster desktop-version start-->
<section class="graybg sec1 sec_23" id="cluster-listing">
    <div class="container">
        <div class="short-course-details-wrap">
            <hr class="hr-border top1">
            <p class="h2titlecaps"><a href="<?php the_permalink(2); ?>"><?php echo get_field("clusters_title"); ?></a>
            </p>
            <p class="subheading"><?php echo get_field("clusters_desc"); ?></p>
            <img src="https://mapeia.langoorqa.net/wp-content/uploads/2022/04/cluster-icon.svg"
                 class="icon-title mobile-view" width="60px" alt="<?php echo get_field("clusters_title"); ?>">
            <hr class="hr-border bottom">
        </div>

        <!-- Desktop Version -->
        <div class="d-none d-lg-block">
            <div class="row">
                <?php
                if (have_rows('list_of_cluster')):
                    while (have_rows('list_of_cluster')) : the_row();
                        $choose_your_cluster = get_sub_field('choose_your_cluster');
                        $post = $choose_your_cluster;
                        setup_postdata($post);
                        $image_id = get_post_thumbnail_id($post->ID);
                        $image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', TRUE);
                        ?>
                        <div class="col-lg-6 col-6 mb-0">
                            <div class="cluster-cart-wrapper">
                                <a href="<?php the_permalink(); ?>"><img
                                            src="<?php echo get_the_post_thumbnail_url($post->ID); ?>"
                                            class="img-fluid w-100" alt="<?php echo $image_alt; ?>"></a>
                                <div class="cluster-part">
                                    <p class="label-title cluster-card"><a href="<?php the_permalink(2); ?>">CLUSTER</a>
                                    </p>
                                    <p class="cluster-title"><a
                                                href="<?php the_permalink(); ?>"><?php the_title(); ?></a></p>
                                    <p class="cluster-description"><?php echo mb_strimwidth(get_the_content(), 0, 120, '...'); ?></p>

                                    <div class="cluster-article-circle-image">
                                        <?php
                                        $post_id;
                                        $list = get_the_terms($post_id, 'cluster_cat');
                                        foreach ($list as $tax) {
                                            ?>
                                            <?php
                                            $args = array('post_type' => 'article',
                                                'post_status' => 'publish',
                                                'orderby' => 'post_date',
                                                'order' => 'DESC',
                                                'posts_per_page' => 10,
                                                'tax_query' => array(
                                                    array(
                                                        'taxonomy' => 'cluster_cat',
                                                        'field' => 'slug',
                                                        'terms' => $tax->name,
                                                    ),
                                                ),
                                            );
                                            $loop = new WP_Query($args);
                                            if ($loop->have_posts()) :
                                                $count = $loop->post_count;
                                                ?>
                                                <?php if ($count > 1) { ?>
                                                <p class="include-article-lable">Includes <?php echo $count; ?>
                                                    articles</p>
                                            <?php } else { ?>
                                                <p class="include-article-lable">Includes <?php echo $count; ?>
                                                    article</p>
                                            <?php } ?>

                                                <?php while ($loop->have_posts()) : $loop->the_post(); ?>
                                                <a class="animated-circle" href="<?php the_permalink(); ?>">

                                                    <?php $artimage_id = get_post_thumbnail_id($post->ID);
                                                    $artimage_alt = get_post_meta($artimage_id, '_wp_attachment_image_alt', TRUE);
                                                    ?>
                                                    <?php if (get_the_post_thumbnail_url()) { ?>
                                                        <img src="<?php echo get_the_post_thumbnail_url(); ?>"
                                                             class="art-circle" alt="<?php echo $artimage_alt; ?>">
                                                    <?php } else { ?>
                                                        <img src="<?php echo get_template_directory_uri(); ?>/images/map-academy-default-article-thumb.jpg"
                                                             class="art-circle" alt="<?php echo $artimage_alt; ?>">
                                                    <?php } ?>
                                                    <span class="animated-title"><?php the_title(); ?></span>
                                                </a>
                                            <?php endwhile; endif;
                                            wp_reset_query(); ?>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php wp_reset_postdata(); endwhile; endif; ?>
            </div>
        </div>

        <!-- Mobile Version -->
        <ul class="d-block d-lg-none p-0">
            <?php
            if (have_rows('list_of_cluster')):
                while (have_rows('list_of_cluster')) : the_row();
                    $choose_your_cluster = get_sub_field('choose_your_cluster');
                    $post = $choose_your_cluster;
                    setup_postdata($post);
                    $artimage_mid = get_post_thumbnail_id($post->ID);
                    $artimage_malt = get_post_meta($artimage_mid, '_wp_attachment_image_alt', TRUE);

                    ?>
                    <li class="media list-view">
                        <a href="<?php echo get_the_permalink(); ?>">
                            <?php
                            if (get_field('thumbnail_image')) {
                                $thumb_url = get_field('thumbnail_image');
                            } else {
                                if (get_the_post_thumbnail_url()) {
                                    $thumb_url = get_the_post_thumbnail_url($post->ID, 'thumbnail');
                                } else {
                                    $thumb_url = get_template_directory_uri() . '/images/map-academy-default-article-thumb.jpg';
                                }
                            }
                            ?>
                            <img src="<?php echo $thumb_url ?>" class="art-img" alt="<?php echo $artimage_malt; ?>">
                        </a>
                        <div class="media-body">
                            <h5 class="m-0" style="min-height: 57px;"><a
                                        href="<?php echo get_the_permalink(); ?>"><?php the_title(); ?></a></h5>
                            <div class="d-flex align-items-center justify-content-start mb-3">
                                <div class="cluster-article-circle-image mb-0">
                                    <?php
                                    $post_id;
                                    $list = get_the_terms($post_id, 'cluster_cat');
                                    foreach ($list as $tax) {
                                        ?>
                                        <?php
                                        $args = array('post_type' => 'article',
                                            'post_status' => 'publish',
                                            'orderby' => 'post_date',
                                            'order' => 'DESC',
                                            'posts_per_page' => 10,
                                            'tax_query' => array(
                                                array(
                                                    'taxonomy' => 'cluster_cat',
                                                    'field' => 'slug',
                                                    'terms' => $tax->name,
                                                ),
                                            ),
                                        );
                                        $loop = new WP_Query($args);
                                        if ($loop->have_posts()) :
                                            $count = $loop->post_count;
                                            ?>


                                            <?php while ($loop->have_posts()) : $loop->the_post(); ?>
                                            <?php $artimage_mid = get_post_thumbnail_id($post->ID);
                                            $artimage_malt = get_post_meta($artimage_mid, '_wp_attachment_image_alt', TRUE); ?>


                                            <a class="animated-circle" href="<?= get_the_permalink() ?>">
                                                <?php if (get_the_post_thumbnail_url()) { ?>
                                                    <img src="<?php echo get_the_post_thumbnail_url($post->ID, 'thumbnail'); ?>"
                                                         class="art-circle" alt="<?php echo $artimage_malt; ?>">
                                                <?php } else { ?>
                                                    <img src="<?php echo get_template_directory_uri(); ?>/images/map-academy-default-article-thumb.jpg"
                                                         class="art-circle" alt="<?php echo $artimage_malt; ?>">
                                                <?php } ?>
                                                <span class="animated-title"><?php the_title(); ?></span>
                                            </a>

                                        <?php endwhile; endif;
                                        wp_reset_query(); ?>
                                    <?php } ?>
                                </div>
                                <?php if ($count > 1) { ?>
                                    <p class="include-article-lable"><?php echo $count; ?> articles</p>
                                <?php } else { ?>
                                    <p class="include-article-lable"><?php echo $count; ?> article</p>
                                <?php } ?>
                            </div>

                            <hr class="hr-border">
                        </div>
                    </li>
                    <?php wp_reset_postdata(); endwhile; endif; ?>

        </ul>
    </div>
</section>
<!-- End short Cluster desktop-version end -->

<!--Start Interwoven Section-->

    <section class="encl-banner-section interwoven ">
        <div class="container-full">
            <div class="bottom-top-encl">
                <div class="row">
                    <div class="col-md-8 offset-md-2 p-0">
                        <div class="row " style="text-align: center">
                            <div class="col text-center p-0">
                                <?php
                                $image = get_field('interwoven_logo');
                                if (!empty($image)): ?>
                                    <div class="row ">
                                        <div class="col text-center p-0">
                                    <img class="interwoven-logo" src="<?php echo esc_url($image['url']); ?>"
                                         alt="<?php echo esc_attr($image['alt']); ?>"/>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col text-center p-0">
                                    <p class="int-description ptitleheading25px"><?php the_field('int-description'); ?></p>
                                        </div>
                                    </div>

                                <?php endif; ?>
                                <div class="int-links">
                                    <?php
                                    $link = get_field('cta_button_1');
                                    if ($link):
                                        $link_url = $link['url'];
                                        $link_title = $link['title'];
                                        $link_target = $link['target'] ? $link['target'] : '_self';
                                        ?>
                                        <a class="banner-btn-link mr-2" href="<?php echo esc_url($link_url); ?>"
                                           target="<?php echo esc_attr($link_target); ?>"><?php echo esc_html($link_title); ?></a>
                                    <?php endif; ?>

                                    <?php
                                    $link = get_field('cta_button_2');
                                    if ($link):
                                        $link_url = $link['url'];
                                        $link_title = $link['title'];
                                        $link_target = $link['target'] ? $link['target'] : '_self';
                                        ?>
                                        <a class="banner-btn-link ml-2" href="<?php echo esc_url($link_url); ?>"
                                           target="<?php echo esc_attr($link_target); ?>"><?php echo esc_html($link_title); ?></a>
                                    <?php endif; ?>

                                </div>

                                <div class="int-partner-logo" >
                                    <?php
                                    $rows = get_field('partner_logo');
                                    if ($rows) {
                                        foreach ($rows as $index => $row) {
                                            $image = $row['image'];
                                            if (!empty($image)): ?>
                                                <img class="mx-2 img<?=$index?>" src="<?php echo esc_url($image['url']); ?>"
                                                     alt="<?php echo esc_attr($image['alt']); ?>"/>
                                            <?php endif;
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php $image = get_field('int_background_image');
            $url = $image['url'];
            $alt = $image['alt']; ?>
<div class="banner-bg-image d-none d-md-block" style="background-image: url(<?php echo esc_url($url); ?>);"></div>

            <picture class="banner-img d-block d-md-none">
                <!-- Desktop banner image -->
                <?php $image = get_field('int_background_image');
                $url = $image['url'];
                $alt = $image['alt']; ?>
                <source srcset="<?php echo esc_url($url); ?>" media="(min-width: 768px)"
                        class="img-fluid main-banner-img" alt="<?php echo esc_attr($alt); ?>">
                <!-- Mobile banner image -->
                <?php $image = get_field('int_mobile_background_image');
                $urlmob = $image['url'];
                $altmob = $image['alt']; ?>
                <img src="<?php echo esc_url($urlmob); ?>" class="img-fluid main-banner-img"
                     alt="<?php echo esc_attr($altmob); ?>">
            </picture>
            <p class="author-para"><?=get_field('interwoven_banner_image_caption')?></p>
        </div>
    </section>
    <span id="feature-article"></span>
<!--End Interwoven Section-->

<!-- start LOOK A LITTLE CLOSER section-->
<section class="graybg sec1 sec-look sec_2 sec_23 d-none d-lg-block" id="look-a-little">
    <div class="container">
        <div class="short-course-details-wrap">
            <hr class="hr-border top1">
            <p class="h2titlecaps"><?php echo get_field("look_a_little_closer_title"); ?></p>
            <p class="subheading"><?php echo get_field("look_a_little_closer_desc"); ?></p>
            <hr class="hr-border bottom">
        </div>
        <main class="image-hotspots">
            <!-- Hot Spot Indicators -->
            <div class="image-indicators">
                <!-- start loop for pointers -->
                <?php $i = 0;
                $j = 1;
                if (get_field('look')):
                    while (has_sub_field('look')):
                        $i++;
                        $j++; ?>
                        <style>
                            :root {
                                /* pointer positions css variable*/
                                --point-<?php echo $i;?>-top: <?php echo the_sub_field("xposition");?>%;
                                --point-<?php echo $i;?>-left: <?php echo the_sub_field("yposition");?>%;
                                /* pointer zoom variable*/
                                --point-<?php echo $i;?>-scale: <?php echo the_sub_field("zoom_ratio");?>;
                            }
                            #label-<?php echo $j;?> {
                                top: var(--point-<?php echo $j;?>-top);
                                left: var(--point-<?php echo $j;?>-left);
                            }
                            #point-<?php echo $j;?> {
                                left: var(--point-<?php echo $j;?>-left);
                                top: var(--point-<?php echo $j;?>-top);
                            }
                            #point-<?php echo $j;?>:checked ~ img {
                                transform-origin: calc(var(--point-<?php echo $j;?>-left)) calc(var(--point-<?php echo $j;?>-top));
                                transform: scale(var(--point-<?php echo $j;?>-scale));
                            }
                            #point-<?php echo $j;?>:hover ~ img {
                                transform-origin: calc(var(--point-<?php echo $j;?>-left)) calc(var(--point-<?php echo $j;?>-top));
                            }
                            /* pointer popup desc*/
                            #point-<?php echo $j;?>:checked ~ .description div:nth-child(<?php echo $j;?>) {
                                display: block;
                                opacity: 0.9;
                                transition-property: opacity;
                                transition-duration: 300ms;
                                transition: opacity 0.3s ease-out 0.5s;
                            }
                        </style>
                        <input type="checkbox" class="point" id="point-<?php echo $i; ?>" name="point" value="1">
                        <!-- Hot Spot Indicator labels -->
                        <label for="point-<?php echo $i; ?>" id="label-<?php echo $i; ?>"
                               style='--point-<?php echo $i; ?>-top: <?php echo the_sub_field("xposition"); ?>%; --point-<?php echo $i; ?>-left: <?php echo the_sub_field("yposition"); ?>%;'>
                            <span></span>
                        </label>
                    <?php endwhile; ?>
                <?php endif; ?>
                <!-- end loop for pointers -->
                <!-- Hot Spot Image -->
                <?php $image = get_field("look_a_little_closer_banner");
                $hostspotimgurl = $image['url'];
                $hostspotimgalt = $image['alt']; ?>
                <img src="<?php echo esc_url($hostspotimgurl); ?>" alt="<?php echo esc_attr($hostspotimgalt); ?>">
                <!-- Hot Spot Descriptions -->
                <div class="description">
                    <?php
                    if (get_field('look')):
                        while (has_sub_field('look')):
                            ?>
                            <div class="desc-popup">
                                <div class="d-flex justify-content-end align-items-center">
                                    <button type="button" class="close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <p class="pb-3">
                                    <?php echo the_sub_field('popup_content'); ?></p>
                            </div>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </div>
        </main>
        <div class="">
            <p class="author-para"><?php echo get_field("look_a_little_closer_auth"); ?></p>
        </div>
    </div>
</section>
<!-- start LOOK A LITTLE CLOSER section-->

<!--Start Blog desktop-version -->
<section class="graybg sec1 sec_2 sec_23 bottom-padding" id="blog-listing">
    <div class="container">
        <div class="short-course-details-wrap">
            <hr class="hr-border top1">
            <p class="h2titlecaps"><a href="<?php the_permalink(15); ?>"><?php echo get_field("blog_title"); ?></a></p>
            <p class="subheading"><?php echo get_field("blog_desc"); ?></p>

            <img src="https://mapeia.langoorqa.net/wp-content/uploads/2022/04/blog-icon.svg"
                 class="icon-title mobile-view" width="30px" alt="<?php echo get_field("blog_title"); ?>">
            <hr class="hr-border bottom">
        </div>
        <!-- Desktop Version -->
        <div class="d-none d-lg-block">
            <div class="row">
                <?php
                $args = array('post_type' => 'post',
                    'post_status' => 'publish',
                    'orderby' => 'post_date',
                    'order' => 'DESC',
                    'posts_per_page' => 8
                );
                $loop = new WP_Query($args);
                if ($loop->have_posts()) :
                    while ($loop->have_posts()) : $loop->the_post();
                        $blogimage_id = get_post_thumbnail_id($post->ID);
                        $blogimage_alt = get_post_meta($blogimage_id, '_wp_attachment_image_alt', TRUE);

                        ?>
                        <div class="col-lg-3 col-md-3 col-sm-12 py-3 px-3">
                            <div class="well wellcourses-blog">
                                <div class="courses-image">
                                    <?php
                                    if (get_the_post_thumbnail_url($post->ID)) {
                                        $thumb_url = get_the_post_thumbnail_url($post->ID, 'large');
                                    } else {
                                        $thumb_url = get_field('default_thumbnail', 'option');
                                    }
                                    ?>
                                    <a href="<?php the_permalink(); ?>"><img src="<?php echo $thumb_url; ?>"
                                                                             alt="<?php echo $blogimage_alt; ?>"/></a>
                                </div>
                                <div class="btm-part border-0">
                                    <?php
                                    $optional_title = get_field('optional_title');
                                    if ($optional_title == 'Yes') { ?>
                                        <a href="<?php the_permalink(); ?>"
                                           class="ellipses-title"><?php the_field('optional_blog_title'); ?></a>
                                    <?php } else { ?>
                                        <a href="<?php the_permalink(); ?>"
                                           class="ellipses-title"><?php the_title(); ?></a>
                                    <?php } ?>
                                    <!-- start default and custom author fetching -->
                                    <?php
                                    $author_check = get_field('default_author');
                                    if ($author_check == 'Yes') {
                                        global $post;
                                        $author_id = $post->post_author;
                                        ?>
                                        <div class="blog-author-profile">
                                            <img src="<?php the_field('default_author_profile', 'user_' . $author_id); ?>"
                                                 class="postauth-thumb" alt="<?php the_field('author_name'); ?>"><span
                                                    class="auth-title"><?php the_field('default_author_name', 'user_' . $author_id); ?></span>
                                        </div>
                                    <?php } else { ?>
                                        <div class="blog-author-profile">
                                            <img src="<?php the_field('author_profile'); ?>"
                                                 class="postauth-thumb" alt="<?php the_field('author_name'); ?>"><span
                                                    class="auth-title"><?php the_field('author_name'); ?></span>
                                        </div>
                                    <?php } ?>
                                    <!-- end default and custom author fetching -->
                                </div>
                            </div>
                        </div>
                    <?php endwhile; endif;
                wp_reset_query(); ?>
            </div>
        </div>

        <!-- Mobile Version -->
        <ul class="d-block d-lg-none p-0">
            <?php
            $args = array('post_type' => 'post',
                'post_status' => 'publish',
                'orderby' => 'post_date',
                'order' => 'DESC',
                'posts_per_page' => 8
            );
            $loop = new WP_Query($args);
            if ($loop->have_posts()) :
                while ($loop->have_posts()) : $loop->the_post();
                    $blogimage_mid = get_post_thumbnail_id($post->ID);
                    $blogimage_malt = get_post_meta($blogimage_mid, '_wp_attachment_image_alt', TRUE);

                    ?>
                    <?php
                    if (get_the_post_thumbnail_url($post->ID)) {
                        $thumb_url = get_the_post_thumbnail_url($post->ID, 'thumbnail');
                    } else {
                        $thumb_url = get_field('default_thumbnail', 'option');
                    }
                    ?>
                    <li class="media list-view">

                        <a href="<?php the_permalink(); ?>"><img src="<?php echo $thumb_url; ?>" class="art-img"
                                                                 alt="<?php echo $blogimage_malt; ?>"/></a>
                        <div class="media-body">
                            <h5 class="mt-0 mb-1 ellipses-title"><a
                                        href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                            <p class="publish">published: <?php echo get_the_date('d/m/Y'); ?></p>

                            <?php
                            if ($author_check == 'Yes') {
                                global $post;
                                $author_id = $post->post_author;
                                ?>
                                <div class="blog-author-profile">
                                    <img src="<?php the_field('default_author_profile', 'user_' . $author_id); ?>"
                                         class="postauth-thumb"><span
                                            class="auth-title"><?php the_field('default_author_name', 'user_' . $author_id); ?></span>
                                </div>
                            <?php } else { ?>
                                <div class="blog-author-profile">
                                    <img src="<?php the_field('author_profile'); ?>" class="postauth-thumb"><span
                                            class="auth-title"><?php the_field('author_name'); ?></span>
                                </div>
                            <?php } ?>

                            <hr class="hr-border">
                        </div>
                    </li>
                <?php endwhile; endif;
            wp_reset_query(); ?>
        </ul>

    </div>
</section>
<!-- End short Blog desktop-version -->

<!-- start The MAP Academy’s Encyclopedia -->
<section class="encyclopedia-wrap" id="map-academy">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 encyclopedia-sec-wrap">
                <div class="container encyclopedia-sec">
                    <div class="margin-enc-p-content">
                        <p class="enc-p-content col-lg-11 pl-0 px-none"><?php echo get_field("map_academy_title"); ?></p>
                        <p class="enc-p-subcontent col-lg-11 pl-0 px-none"><?php echo get_field("map_academy_desc"); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12">
                <div class="margin-enc-p-content">
                    <?php if (get_field('map_academy_details')): ?>
                        <?php while (has_sub_field('map_academy_details')): ?>
                            <div class="row pb-4">
                                <div class="col-lg-3 col-md-3 text-center pb-1 col-12">
                                    <?php $image = get_sub_field('logo');
                                    $logoimgurl = $image['url'];
                                    $logoimgtxt = $image['alt']; ?>
                                    <img class="img-responsive" src="<?php echo esc_url($logoimgurl); ?>"
                                         alt="<?php echo esc_attr($logoimgtxt); ?>">
                                </div>
                                <div class="col-lg-6 col-md-6 pl-0 col-12 px-none">
                                    <p class="enc-pgp-content"><?php echo the_sub_field('title'); ?></p>
                                    <p class="enc-pgp-subcontent "><?php echo the_sub_field('desc'); ?></p>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <span id="courses-listing"></span>
</section>
<!-- end The MAP Academy’s Encyclopedia -->

<!--Start Courses desktop -->
<section class="graybg sec1 sec_1 bottom-padding  pt-5 ">
    <div class="container">
        <div class="short-course-details-wrap">
            <hr class="hr-border top1">
            <p class="h2titlecaps"><?php echo get_field("courses_listing_title"); ?></p>
            <p class="subheading"><?php echo get_field("courses_listing_description"); ?></p>

            <img src="https://mapeia.langoorqa.net/wp-content/uploads/2022/04/online-course.svg"
                 class="icon-title mobile-view" width="24px" alt="<?php echo get_field("courses_listing_title"); ?>">
            <hr class="hr-border bottom">
        </div>
        <?php
        $apiUrl = 'https://mapacademy.io/academy/wp-json/wp/v2/frontpage-courses/';
//        $apiUrl = 'https://mapacademy.langoorqa.net/wp-json/wp/v2/frontpage-courses/';
        $response = wp_remote_get($apiUrl);
        $responseBody = wp_remote_retrieve_body($response);
        $result = json_decode($responseBody);

//        print_r($result);

        /*$url = 'http://localhost/mapacademy-qadev/wp-json/wp/v2/frontpage-courses'; // path to your JSON file
        echo $data = file_get_contents($url); // put the contents of the file into a variable
        echo $coruses_var = json_decode($data); // decode the JSON feed*/
        ?>

        <!-- Desktop Version -->
        <div class="d-none d-lg-block">
            <div class="row">
                <?php
                $i = 0;

                foreach ($result as $character) {

                //echo count($character);
                for ($j = 0;
                $j < count($character);
                $j++)
                {
                $coursestitle = $character[$j]->title;

                $coursesexct = $character[$j]->excerpt;
                $coursesdate = $character[$j]->createddate;
                $coursespost_date = date('Y', strtotime($coursesdate));
                $courses_status = $character[$j]->pubstatus;
                $course_availability=$character[$j]->coursestatus;
                $featuredimage = $character[$j]->featuredimage;
                $categoryname = array_reverse($character[$j]->categoryname);
                $paramalink = $character[$j]->paramalink;
                //print_r ($categoryname);
                //var_dump($character);
                if (strlen($coursestitle) >= 75) {
                    $coursestitlenew = substr($coursestitle, 0, 75) . "... " . substr($coursestitle);
                } else {
                    $coursestitlenew = $coursestitle;
                }
                if (strlen($coursesexct) >= 80) {
                    $coursesexctnew = substr($coursesexct, 0, 80) . " ... " . substr($coursesexct);
                } else {
                    $coursesexctnew = $coursesexct;
                }
                ?>
                <div class="col-lg-3 col-md-3 col-sm-12 py-3 px-3">
                    <div class="well wellcourses">
                        <div class="courses-image">
                            <a style="text-decoration: none;" href="<?php echo $paramalink; ?>"> <img
                                        src="<?php echo $featuredimage; ?>" alt="<?php echo $coursestitle; ?>"/></a>
                        </div>
                        <div class="courses-desc-cotent-wrap">
                            <p class="courses-card-heading"><a style="text-decoration: none;"
                                                               href="<?php echo $paramalink; ?>"><?php echo $coursestitlenew; ?></a>
                            </p>
                            <!-- <p class="course-desc-content"><?php //echo  $coursesexctnew;
                            ?></p>-->
                            <div>
                                <?php foreach ($categoryname as $getcat)
                                {
                                $getcatname = $getcat->cat_name;
                                ?>
                                <div class="course-desc-footer">
                                    <span class="core-font-14px space-bot"><?php echo strtolower($getcatname); ?></span>
                                    <?php if ($getcatname == 'Core Course')
                                    {
                                    ?>
                                    <a class="btn btn-primary disabled" role="button" target=”_blank”
                                       href="<?php echo $paramalink; ?>">Learn More</a>
                                    <div class="tiny-text">Launching 2023</div>
                                </div>
                                <?php
                                }
                                else
                                {
                                ?>
                                <a class="btn btn-primary min-90" role="button" target=”_blank”
                                   href="<?php echo $paramalink; ?>" rel="bookmark">

                                    <?php
                                    if($course_availability=="Live"){
                                        echo "Enrol";
                                    }
                                    else{
                                        echo "Learn More";
                                    }
                                    ?>
                                </a>

                                    <div class="tiny-text  pl-0">
                                        <?php
                                        if($course_availability=="Live"){
                                            echo "Live";
                                        }
                                        else{
                                            echo "Coming Soon";
                                        }
                                        ?>
                                    </div>

                            </div>
                            <?php
                            }
                            ?>
                            <?php
                            //echo $getcatname;
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            $i++;
            }
            }
            ?>
        </div>
    </div>
    <!-- Mobile Version -->
    <ul class="d-block d-lg-none p-0 my-5 ">
        <?php
        $i = 0;
        foreach ($result as $character) {
            //echo count($character);
            for ($j = 0; $j < count($character); $j++) {
                $coursestitle = $character[$j]->title;

                $coursesexct = $character[$j]->excerpt;
                $coursesdate = $character[$j]->createddate;
                $coursespost_date = date('Y', strtotime($coursesdate));
                $courses_status = $character[$j]->pubstatus;
                $featuredimage = $character[$j]->thumnail;
                $categoryname = array_reverse($character[$j]->categoryname);
                $paramalink = $character[$j]->paramalink;
                $course_availability=$character[$j]->coursestatus;
                //print_r ($categoryname);
                //var_dump($character);
                if (strlen($coursestitle) >= 75) {
                    $coursestitlenew = substr($coursestitle, 0, 75) . "... " . substr($coursestitle);
                } else {
                    $coursestitlenew = $coursestitle;
                }
                if (strlen($coursesexct) >= 80) {
                    $coursesexctnew = substr($coursesexct, 0, 80) . " ... " . substr($coursesexct);
                } else {
                    $coursesexctnew = $coursesexct;
                }
                ?>
                <li class="media list-view">
                    <a style="text-decoration: none;" href="<?php echo $paramalink; ?>"><img
                                src="<?php echo $featuredimage; ?>"
                                class="art-img"
                                alt="<?php echo $coursestitle; ?>"/></a>

                    <div class="media-body">
                        <h5 class="mt-0 ellipses-title">
                            <?php echo $coursestitlenew; ?>
                        </h5>

                        <div class="row no-gutters mb-2">

                            <?php foreach ($categoryname as $getcat) {
                                $getcatname = $getcat->cat_name;
                                ?>
                                <div class="col-6">
                                    <div class="course-desc-footer d-flex flex-column pr-3">
                                        <span class="core-font-14px pl-0"><?php echo strtolower($getcatname); ?></span>
                                        <?php if ($getcatname == 'Core Course') {
                                            $disabled = "disabled";
                                            $status = "Launching 2023";
                                        } else {

                                            if($course_availability=="Live"){
                                                $status = "Live";
                                            }
                                            else{
                                                $status = "Coming Soon";
                                            }

                                            $disabled = "";

                                        }


                                        ?>
                                        <div class="tiny-text pl-0 mb-2"><?= $status ?></div>
                                        <a class="btn btn-primary w-100 <?= $disabled ?>" role="button"
                                           target="”_blank”"
                                           href="<?php echo $paramalink; ?>" rel="bookmark">
                                            <?php if ($getcatname == 'Core Course') {
                                                echo "Learn More";
                                            } else {

                                                if($course_availability=="Live"){
                                                    echo "Enrol";
                                                }
                                                else{
                                                    echo "Learn More";
                                                }


                                            }


                                            ?>
                                        </a>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>


                        </div>

                        <hr class="hr-border">
                    </div>
                </li>

                <?php
                $i++;
            }
        }
        ?>
    </ul>
    </div>

</section>


<!--Start Subscribe-->
<div class="d-none d-lg-block">
    <section class="subscribe-sec">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-5 col-sm-12">
                    <div class="desc-wrapdesc-wrap p-5">
                        <div class="desc-margin-wrap">
                            <h2 class="ld-tab-content short-course-details h2titleheading30px ">Newsletter</h2>
                            <p class="desc-wrapdesc-content">Be the first to hear about all the latest MAP Academy
                                articles, online courses and news.</p>
                            <p style="text-align:center;">
                                <button type="button" class="btn btn-primary" data-toggle="modal"
                                        data-target="#subscribeModal">Subscribe
                            </p>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-9 col-sm-12">
                </div>
            </div>
        </div>
    </section>
</div>

<!--Start Partner desktop -->
<?php if (get_field('map_partner_title')): ?>
    <section class="whitebg sec1 sec_1 bottom-padding  pt-5 d-none d-lg-block">
        <div class="container">
            <div class="short-course-details-wrap">
                <hr class="hr-border top1">
                <p class="h2titlecaps"><?php echo get_field("map_partner_title"); ?></p>
                <p class="subheading"><?php echo get_field("map_partner_desc"); ?></p>
                <img src="https://mapeia.langoorqa.net/wp-content/uploads/2022/04/online-course.svg"
                     class="icon-title mobile-view" width="24px" alt="<?php echo get_field("map_partner_title"); ?>">
                <hr class="hr-border bottom">
            </div>
            <div class="partner-logo-section">
                <div class="row">
                    <?php
                    if (have_rows('map_partner_list')):
                        while (have_rows('map_partner_list')): the_row();
                            $image = get_sub_field('partner_logo');
                            $partner_logourl = $image['url'];
                            $partner_logoalt = $image['alt'];
                            $partner_link = get_sub_field('partner_logo_link');
                            ?>
                            <div class="col-md-3">
                                <div class="logo-partner">
                                    <a href="<?php echo $partner_link; ?>" target="_blank"><img
                                                src="<?php echo esc_url($partner_logourl); ?>"
                                                alt="<?php echo esc_attr($partner_logoalt); ?>"></a>
                                </div>
                            </div>
                        <?php endwhile; endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>

<!-- End short coures desktop -->


<?php get_footer(); ?>

<style>
    /* body{
       background: #f2f4fb;
     }*/
</style>

<script>
    $('.owl-carousel').owlCarousel({
        loop: true,
        margin: 10, /* important line */
        autoplay: true,
        nav: false,
        dots: false,
        responsive: {
            0: {
                items: 1.5
            },

            1000: {
                items: 3.5
            }
        }
    });
</script>
<script>
    $(document).ready(function () {
        // hide this selected element
        $('.close').on('click', function () {
            $(this).closest('.desc-popup').hide()
        });
        $('.point').on('click', function () {
            $('.desc-popup').removeAttr("style");
        });
    });
</script>
