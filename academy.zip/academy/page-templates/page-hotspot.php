<?php
/*
* Template Name: Image Hotspot
*/

get_header();
/* fetch hotspots */
$home_pageid  = get_the_ID();

?>

<main class="image-hotspots container">
    <!-- Hot Spot Indicators -->
    <div class="image-indicators">
        <input type="checkbox" class="point" id="point-1" name="point" value="1">
        <input type="checkbox" class="point" id="point-2" name="point" value="2">
        <input type="checkbox" class="point" id="point-3" name="point" value="3">
        <input type="checkbox" class="point" id="point-4" name="point" value="4">

        <!-- Hot Spot Indicator labels -->
        <label for="point-1" id="label-1">
            <span></span>
        </label>
        <label for="point-2" id="label-2">
            <span></span>
        </label>
        <label for="point-3" id="label-3">
            <span></span>
        </label>
        <label for="point-4" id="label-4">
            <span></span>
        </label>

        <!-- Hot Spot Image -->
        <img src="https://mapeia.langoorqa.net/wp-content/uploads/2022/03/DP153186-scaled.jpeg" alt="Hot Spot Image">

        <!-- Hot Spot Descriptions -->
        <div class="description">
            <div class="desc-popup">
                <div class="d-flex justify-content-end align-items-center">
                    <button type="button" class="close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <p class="pb-2 px-1">
                    The Mewar school of painting that flourished between the seventeenth and eighteenth centuries, was patronised by the Sisodia dynasty in the Rajput state of Mewar. The prolific court workshops of this state produced paintings that covered several genres and. Read our article, <a href="#" class="tooltip-test" title="Tooltip">What do stepwells tell us about our relationship to the environment, and each other?</a> to find out more.
                </p>
            </div>
            <div class="desc-popup">
                <div class="d-flex justify-content-end align-items-center">
                    <button type="button" class="close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <p class="pb-2 px-1">
                    The Mewar school of painting that flourished between the seventeenth and eighteenth centuries, was patronised by the Sisodia dynasty in the Rajput state of Mewar. The prolific court workshops of this state produced paintings that covered several genres and. Read our article, <a href="#" class="tooltip-test" title="Tooltip">What do stepwells tell us about our relationship to the environment, and each other?</a> to find out more.
                </p>
            </div>
            <div class="desc-popup">
                <div class="d-flex justify-content-end align-items-center">
                    <button type="button" class="close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <p class="pb-2 px-1">
                    The Mewar school of painting that flourished between the seventeenth and eighteenth centuries, was patronised by the Sisodia dynasty in the Rajput state of Mewar. The prolific court workshops of this state produced paintings that covered several genres and. Read our article, <a href="#" class="tooltip-test" title="Tooltip">What do stepwells tell us about our relationship to the environment, and each other?</a> to find out more.
                </p>
            </div>
            <div class="desc-popup">
                <div class="d-flex justify-content-end align-items-center">
                    <button type="button" class="close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <p class="pb-2 px-1">
                    The Mewar school of painting that flourished between the seventeenth and eighteenth centuries, was patronised by the Sisodia dynasty in the Rajput state of Mewar. The prolific court workshops of this state produced paintings that covered several genres and. Read our article, <a href="#" class="tooltip-test" title="Tooltip">What do stepwells tell us about our relationship to the environment, and each other?</a> to find out more.
                </p>
            </div>
        </div>
    </div>
</main>

<script>
    $(document).ready(function() {
        // hide this selected element
        $('.close').on('click', function() {
            $(this).closest('.desc-popup').hide()
        });
    });
</script>

<?php //get_footer(); 
?>