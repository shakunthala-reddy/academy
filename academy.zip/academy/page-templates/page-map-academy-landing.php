<?php 
/*
    Template Name: MAP Academy landing page
*/
get_header();
 /* fetch home page */ 
 $home_pageid  = get_the_ID();	
?>

<section class="maplanding_sec">
 <div class="container">
   <div class="head-content-mapacademy">
    <h2 class="ld-tab-content short-course-details h2titleheading30px"><?php echo the_field( "page_title");?></h2>
    <h2 class="maplanding_content-header-main"><?php echo the_field( "page_desc");?></h2>
	</div>
 </div>
	<div class="container">
           <?php 
            if(get_field('map_academy_details')): 
             while(has_sub_field('map_academy_details' )): 
               ?>
			<div class="row maplanding_loop">
				<div class="col-lg-6 maplanding_img">
				 <img src="<?php echo the_sub_field( "banner_image");?>" alt="<?php echo the_sub_field( "banner_title");?>" class="<?php echo the_sub_field( "banner_class");?>">
                 <!-- <p class="author-para-mapland p-2"><?php echo the_sub_field( "banner_image_title");?></p>					 -->
				</div>
			<div class="col-lg-6 maplanding_content">
				<div class="content-mapeialanding">
					<h2 class="maplanding_content-header"><?php echo the_sub_field( "banner_title");?></h2>
					<div class="maplanding_description">
					<h2 class="ld-tab-content short-course-details h2titleheading30px text-left"><?php echo the_sub_field( "banner_description");?></h2>
					</div>
					<div class="align-items-left justify-content-end px-0" ><a href="<?php echo the_sub_field( "banner_url");?>" ><button class="btn btn-primary" >Learn More
					<i class="icon icon-arrow-right"></i></button></a></div>				
				  </div>
				</div>
            </div>
                <?php endwhile;?>                   
  <?php endif; ?>	
	</div>
</section>

<?php get_footer(); ?>
