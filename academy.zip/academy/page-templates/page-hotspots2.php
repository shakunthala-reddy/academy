<?php 
/*
    Template Name: hotspots 2
*/
get_header();
 /* fetch hotspots */ 
 $home_pageid  = get_the_ID();	
 
?>

<main class="hotspots_sec two">
 
	<section class="hotspots-img-section one-col-section">
        <div class="container-fluid">
            <div class="row">
                <article class="col-lg-12 p-0 inrow-1 col-wrapper d-flex flex-row flex-wrap justify-content-between">
                    <div class="col-lg-12 p-0 column1 hotspots-img">
                        <div class="col-lg-12 p-0">
							<?php if ( get_field('image')) : ?>
								<a href="<?php the_permalink(); ?>" alt="<?php the_title_attribute(); ?>">
									<?php the_post_thumbnail(); ?>
								</a>
							<?php endif; ?>

						</div>
                    </div>
                </article>

            </div>
        </div>
    </section>
	
	<section class="hotspots-pointers pointer1">
        <div class="container-fluid pointerborder pointer1border">
            <div class="row">
                <article class="col-lg-12 p-0 inrow-1 col-wrapper d-flex flex-row flex-wrap justify-content-between">
                    <div class="col-lg-12 p-0 column1 hotspots-img-pointers">
                        <div class="col-lg-12 p-0">
						
						</div>
                    </div>
                </article>
            </div>
        </div>
    </section>
    
	<section class="hotspots-pointers pointer2">
        <div class="container-fluid pointerborder pointer2border">
            <div class="row">
                <article class="col-lg-12 p-0 inrow-1 col-wrapper d-flex flex-row flex-wrap justify-content-between">
                    <div class="col-lg-12 p-0 column1 hotspots-img-pointers">
                        <div class="col-lg-12 p-0">
						
						</div>
                    </div>
                </article>
            </div>
        </div>
    </section>

	<section class="hotspots-pointers pointer3">
        <div class="container-fluid pointerborder pointer3border">
            <div class="row">
                <article class="col-lg-12 p-0 inrow-1 col-wrapper d-flex flex-row flex-wrap justify-content-between">
                    <div class="col-lg-12 p-0 column1 hotspots-img-pointers">
                        <div class="col-lg-12 p-0">
						
						</div>
                    </div>
                </article>
            </div>
        </div>
    </section>

    <section class="hotspots-pointers pointer4">
        <div class="container-fluid pointerborder pointer4border">
            <div class="row">
                <article class="col-lg-12 p-0 inrow-1 col-wrapper d-flex flex-row flex-wrap justify-content-between">
                    <div class="col-lg-12 p-0 column1 hotspots-img-pointers">
                        <div class="col-lg-12 p-0">
						
						</div>
                    </div>
                </article>
            </div>
        </div>
    </section>

    <section class="hotspots-pointers pointer5">
        <div class="container-fluid pointerborder pointer5border">
            <div class="row">
                <article class="col-lg-12 p-0 inrow-1 col-wrapper d-flex flex-row flex-wrap justify-content-between">
                    <div class="col-lg-12 p-0 column1 hotspots-img-pointers">
                        <div class="col-lg-12 p-0">
						
						</div>
                    </div>
                </article>
            </div>
        </div>
    </section>

    <section class="hotspots-pointers pointer6">
        <div class="container-fluid pointerborder pointer6border">
            <div class="row">
                <article class="col-lg-12 p-0 inrow-1 col-wrapper d-flex flex-row flex-wrap justify-content-between">
                    <div class="col-lg-12 p-0 column1 hotspots-img-pointers">
                        <div class="col-lg-12 p-0">
						
						</div>
                    </div>
                </article>
            </div>
        </div>
    </section>


    <!-- on load modal popup -->
    <section class="modal-footer modal-hotspots-wrap" style="padding:0px;">

        <div class="modal-footer modal fade modal-hotspots" id="hotspotsModal" tabindex="-1" role="dialog" aria-labelledby="hotspotsModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    
                    <div class="modal-header-wrap">
                    
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><span style="font-size: 30px !important; font-weight: normal !important;">&times;</span></span>
                        </button>
                    </div>

                <div class="modal-body col-md-12 m-auto text-left">
                        <h5 class="modal-title mb-4 pb-2 px-1" id="hotspotsModalLabel">
                            <p>
                                The Mewar school of painting that flourished between the seventeenth and eighteenth centuries, was patronised by the Sisodia dynasty in the Rajput state of Mewar. The prolific court workshops of this state produced paintings that covered several genres and. Read our article, <a href="#" class="tooltip-test" title="Tooltip">What do stepwells tell us about our relationship to the environment, and each other?</a> to find out more.
                            </p>
                        </h5>
                </div>

            </div>
        </div>

    </section>


</main>

<script type="text/javascript">
    $(window).on('load', function() {
        $('.modal-hotspots').modal('show');
    });
</script>

<?php get_footer(); ?>

