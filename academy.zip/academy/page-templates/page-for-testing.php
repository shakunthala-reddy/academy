<?php
/*
* Template Name: Test Page
*/

//get_header();
/* fetch hotspots */

$args = array(
    'numberposts' => 2000,
    'post_type' => 'glossary',

);

$the_query = new WP_Query($args);

?>
<?php if ($the_query->have_posts()):
    $count = 0;
    ?>


    <?php while ($the_query->have_posts()) : $the_query->the_post();
    $count++;
    ?>

    <?=$count?>;;<?php the_title(); ?>;"[""<?php the_title(); ?>""]";<?php the_permalink(); ?>;1;_self;;;1;;;;0<br>

<?php endwhile; ?>

<?php endif; ?>

<?php wp_reset_query();     // Restore global post data stomped by the_post(). ?>


<?php //get_footer();
?>