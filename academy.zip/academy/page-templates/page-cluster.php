<?php 
/*
    Template Name: Cluster
*/
get_header();
?>

<!--Desktop-->
<div class="desktop-version">
    <div class="main-wrapper-div">
        
        <section class="blog-section one-col-section">
            <div class="container">
                <div class="short-course-details-wrap">
                    <hr class="hr-border top1">
                    <p class="h2titlecaps"><?php echo get_field( "top_heading");  ?></p>
                    <p class="subheading"><?php echo get_field( "top_subheading");  ?></p>
                    <hr class="hr-border bottom">
                </div>
                <!-- <div class="row">
                    <div class="col-lg-12">
                        <h2 class="cluster-type-hrading"><?php the_field('top_heading'); ?></h2>
                        <p class="cluster-sub-hrading"><?php the_field('top_subheading'); ?></p>
                    </div>
                </div> -->
                <div class="row">
                    <?php
                  
                    $myposts = get_posts( array(
                        'post_type' => 'cluster',
                        'orderby'   => 'post_date',
                        'posts_per_page' => 6,
                        'meta_key'      => 'feature_cluster',
                        'meta_value'    => 'yes'
                    ) ); 
                    if ( $myposts ) :
                        foreach ( $myposts as $post ) : 
                            setup_postdata( $post );            
                            $post_id = $post->ID; 
                            $clsimage_mid = get_post_thumbnail_id($post->ID);
                            $clsimage_malt = get_post_meta($clsimage_mid, '_wp_attachment_image_alt', TRUE);
                     
                    ?>
                    <div class="col-lg-6 col-6 mb-0">
                        <div class="cluster-cart-wrapper">
                            <a href="<?php the_permalink(); ?>"><img src="<?php echo get_the_post_thumbnail_url($post->ID); ?>" class="img-fluid w-100" alt="<?php echo $clsimage_malt; ?>"></a>
                            <div class="cluster-part">
                                <p class="label-title cluster-card">CLUSTER</p>
                                <p class="cluster-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></p>

                                <p class="cluster-description"><?php echo mb_strimwidth( get_the_content(), 0, 120, '...'); ?></p>
                                
                                <div class="cluster-article-circle-image">
                                    <?php 
                                   $post_id;
                             
                                    $list = get_the_terms( $post_id, 'cluster_cat' );
                                    foreach ( $list as $tax ) {
                                    ?>
                                    <?php 
                                    $args = array('post_type' => 'article',
                                        'post_status' => 'publish',
                                        'orderby'        => 'post_date',
                                        'order' => 'DESC',
                                        'posts_per_page'=> -1,
                                            'tax_query' => array(
                                                array(
                                                    'taxonomy' => 'cluster_cat',
                                                    'field' => 'slug',
                                                    'terms' => $tax->name,
                                                ),
                                            ),
                                        );
                                    $loop = new WP_Query($args);
                                    if($loop->have_posts()) : 
                                        $count = $loop->post_count; 
                                       
                                                        ?>
                                    <?php if($count > 1) { ?>
                                        <p class="include-article-lable">Includes <?php echo $count; ?> articles</p>
                                    <?php } else { ?>
                                        <p class="include-article-lable">Includes <?php echo $count; ?> article</p>
                                    <?php } ?>
                                    
                                    <?php  
                                    global $post;
                                    while($loop->have_posts()) : $loop->the_post();?>                            
                                    <a class="animated-circle" href="<?php the_permalink(); ?>">
                                   <?php  
                                  // print_r ($loop);
                                   $artimage_mid = get_post_thumbnail_id($post->ID);
                                   $artimage_malt = get_post_meta($artimage_mid, '_wp_attachment_image_alt', TRUE);?>
          
              
                                        <?php if ( get_the_post_thumbnail_url() ) { ?>
                                        <img src="<?php echo get_the_post_thumbnail_url(); ?>" class="art-circle" alt="<?php echo $artimage_malt; ?>">
                                        <?php } else { ?>
                                        <img src="<?php echo get_template_directory_uri(); ?>/images/map-academy-default-article-thumb.jpg" class="art-circle" alt="<?php echo $artimage_malt; ?>">
                                        <?php } ?>
                                        <span class="animated-title"><?php the_title(); ?></span>
                                    </a>
                                    <?php endwhile; endif; wp_reset_query(); ?>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; endif; wp_reset_query(); ?>
                </div>
            </div>
        </section>
        <?php 
        $args = array('post_type' => 'cluster',
            'orderby'   => 'post_date',
            'meta_key'      => 'feature_cluster',
            'meta_value'    => 'no'
        );
        $query = new WP_Query($args);
        if($query->have_posts()):
            while($query->have_posts()): $query->the_post();
                $post_id = $post->ID;
                $clsimage_mid = get_post_thumbnail_id($post->ID);
                $clsimage_malt = get_post_meta($clsimage_mid, '_wp_attachment_image_alt', TRUE);
         
        ?>

        <div class="print-section-cluster" id="p-<?php echo $post_id; ?>">

        <?php
            get_template_part('/template-parts/divider/divider');
        ?>

        <section class="photograpers-banner-section">
            <div class="container-fluid">
                <div class="row">
                    <article class="col-lg-12 p-0">
                        <a href="<?php the_permalink(); ?>"><img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid w-100 d-lg-block d-none" alt="<?php echo $clsimage_malt; ?>"></a>
                        <a href="<?php the_permalink(); ?>"><img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid w-100 d-lg-none d-block " alt="<?php echo $clsimage_malt; ?>"></a>
                    </article>
                </div>
            </div>
        </section>

        <section class="photographer-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12"></div>
                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                        <div class="label-section">
                            <h5 class="label-title cluster">CLUSTER</h5>
                            <h2 class="phtograph-heading"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            <?php
                                get_template_part('/template-parts/author/author-details');
                            ?>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
                    </div>
                </div>
            </div>
        </section>

        <section class="cluster-description-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
                        <aside class="left-sidebar">
                            <div class="author-details">
                                <div class="wrap-filed-info">
                                    <p class="first-published">FIRST PUBLISHED</p>
                                    <p class="published-date"><?php the_time('F j, Y'); ?></p>
                                </div>
                            </div>
                            <?php
                                get_template_part('/template-parts/social-icon/social-icon');
                            ?>
                        </aside>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                        <div class="pcontent">
                            <?php the_content(); ?>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
                        <aside class="right-sidebar d-none d-lg-block">
                            <div class="right-section"></div>
                            <?php
                                get_template_part('/template-parts/related-content/related-content');
                            ?>
                        </aside>
                    </div>
                </div>
            </div>
        </section>

        <section class="article-section one-col-section article-listing">
            <div class="container">
                <div class="row">                
                    <?php 
                    $post_id;
                    $list = get_the_terms( $post_id, 'cluster_cat' );
                    foreach ( $list as $tax ) {
                    ?>
                    <?php 
                    $args = array('post_type' => 'article',
                        'post_status' => 'publish',
                        'orderby'        => 'post_date',
                        'order' => 'DESC',
                        'posts_per_page'=> -1,
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'cluster_cat',
                                    'field' => 'slug',
                                    'terms' => $tax->name,
                                ),
                            ),
                        );
                    $loop = new WP_Query($args);
                        if($loop->have_posts()) : 
                        global $post;
                        while($loop->have_posts()) : $loop->the_post();
                        $artimage_mid = get_post_thumbnail_id($post->ID);
                        $artimage_malt = get_post_meta($artimage_mid, '_wp_attachment_image_alt', TRUE);

                    ?>
                    <div class="col-lg-3 col-6">
                        <a href="<?php the_permalink(); ?>">
                            <?php
                                if (get_the_post_thumbnail_url()) {
                                    $thumb_url = get_the_post_thumbnail_url();
                                } else {
                                    $thumb_url = get_field('default_thumbnail', 'option');
                                }
                            ?>
                            <img src="<?php echo $thumb_url; ?>" class="img-responsive" alt="<?php echo $artimage_malt; ?>">
                        </a>
                        <div class="btm-part">
                            <p class="article-lable">ARTICLE</p>
                            <div class="article-summary-wrap">
                                <a class="article-title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                <?php
                                $content=wp_trim_words(get_post_field('post_content'), 38);
                                $pattern = "/(\[)(.*?)(\])/";
                                $content = preg_replace($pattern, '', $content);
                                ?>
                                <p class="article-description"><?php echo $content; ?></p>
                            </div>
                            <div class="col-12 p-0 double-part d-flex flex-row flex-wrap justify-content-between">
                                <div class="read-more p-0"><?php //echo $est; ?> <a href="<?php the_permalink(); ?>">Read More</a></div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; endif; wp_reset_query(); ?>
                    <?php } ?>                
                </div>
            </div>
        </section>


        </div>


        <?php endwhile; endif; wp_reset_query(); ?>


    </div>
</div>
<!--end Desktop-->

<!--Mobile-->
<div class="mobile-version">
    <div class="main-wrapper-div mt-4">
        <section class="blog-section one-col-section">
            <div class="container">
                <div class="short-course-details-wrap">
                    <hr class="hr-border top1">
                    <p class="h2titlecaps"><?php echo get_field( "top_heading");  ?></p>
                    <p class="subheading"><?php echo get_field( "top_subheading");  ?></p>
                    <img src="https://mapeia.langoorqa.net/wp-content/uploads/2022/04/cluster-icon.svg" class="icon-title mobile-view" width="60px" alt="<?php echo get_field( "top_heading");  ?>">
                    <hr class="hr-border bottom">
                </div>

                <ul class="d-block d-lg-none p-0">
                    <?php
                    global $post;
                    $myposts = get_posts( array(
                        'post_type' => 'cluster',
                        'orderby'   => 'post_date',
                        'posts_per_page' => 6,
                        'meta_key'      => 'feature_cluster',
                        'meta_value'    => 'yes'
                    ) );
                    if ( $myposts ) :
                    foreach ( $myposts as $post ) :
                    setup_postdata( $post );
                    global $post;
                    $artimage_mid = get_post_thumbnail_id($post->ID);
                    $artimage_malt = get_post_meta($artimage_mid, '_wp_attachment_image_alt', TRUE);

                            ?>
                            <li class="media list-view">
                                <a href="<?php echo get_the_permalink(); ?>">
                                    <?php
                                    if (get_field('thumbnail_image')) {
                                        $thumb_url=get_field('thumbnail_image');
                                    } else {
                                        if (get_the_post_thumbnail_url()) {
                                            $thumb_url = get_the_post_thumbnail_url($post->ID, 'thumbnail');
                                        } else {
                                            $thumb_url = get_template_directory_uri() . '/images/map-academy-default-article-thumb.jpg';
                                        }
                                    }
                                    ?>
                                    <img src="<?php echo $thumb_url ?>" class="art-img" alt="<?php echo $artimage_malt; ?>">
                                </a>
                                <div class="media-body">
                                    <h5 class="mt-0 mb-3"><a href="<?php echo get_the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                    <div class="d-flex align-items-center justify-content-start mb-3">
                                        <div class="cluster-article-circle-image mb-0">
                                            <?php
                                            $post_id;
                                            $list = get_the_terms($post_id, 'cluster_cat');
                                            foreach ($list as $tax) {
                                                ?>
                                                <?php
                                                
                                                $args = array('post_type' => 'article',
                                                    'post_status' => 'publish',
                                                    'orderby' => 'post_date',
                                                    'order' => 'DESC',
                                                    'posts_per_page' => -1,
                                                    'tax_query' => array(
                                                        array(
                                                            'taxonomy' => 'cluster_cat',
                                                            'field' => 'slug',
                                                            'terms' => $tax->name,
                                                        ),
                                                    ),
                                                );
                                                $loop = new WP_Query($args);
                                                if ($loop->have_posts()) :
                                                    $count = $loop->post_count;
                                                    
                                                       ?>


                                                    <?php while ($loop->have_posts()) : $loop->the_post(); ?>
                                                    <?php  $artimage_mid = get_post_thumbnail_id($post->ID);
                                                    $artimage_malt = get_post_meta($artimage_mid, '_wp_attachment_image_alt', TRUE);
                                                     ?>
                                                    <a class="animated-circle" href="<?= get_the_permalink() ?>">
                                                        <?php if (get_the_post_thumbnail_url()) { ?>
                                                            <img src="<?php echo get_the_post_thumbnail_url($post->ID, 'thumbnail'); ?>"
                                                                 class="art-circle" alt="<?php echo $artimage_malt; ?>">
                                                        <?php } else { ?>
                                                            <img src="<?php echo get_template_directory_uri(); ?>/images/map-academy-default-article-thumb.jpg"
                                                                 class="art-circle" alt="<?php echo $artimage_malt;?>">
                                                        <?php } ?>
                                                        <span class="animated-title"><?php the_title(); ?></span>
                                                    </a>

                                                <?php endwhile; endif;
                                                wp_reset_query(); ?>
                                            <?php } ?>
                                        </div>
                                        <?php if ($count > 1) { ?>
                                            <p class="include-article-lable"><?php echo $count; ?> articles</p>
                                        <?php } else { ?>
                                            <p class="include-article-lable"><?php echo $count; ?> article</p>
                                        <?php } ?>
                                    </div>

                                    <hr class="hr-border">
                                </div>
                            </li>
                            <?php wp_reset_postdata(); endforeach; endif; ?>

                </ul>
            </div>
        </section>
    </div>
    <?php
    global $post; 
    $myposts = get_posts( array(
        'post_type' => 'cluster',
        'orderby'   => 'post_date',
        'meta_key'      => 'feature_cluster',
        'meta_value'    => 'no'
    ) ); 
    if ( $myposts ) :
        foreach ( $myposts as $post ) : 
            setup_postdata( $post );            
            $post_id = $post->ID; 
           ?>
    <!--1st section-->
    <div class="print-section-cluster" id="p-<?php echo $post_id; ?>">

    <section class="photographer-section">
        <div class="container">
            <div class="row">
                <article class="col-lg-12 inrow-1 col-wrapper d-flex flex-row flex-wrap justify-content-between p-0">
                    <div class="col-lg-2 col-md-12 col-sm-12 col-xs-12">
                    </div>
                    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12 p-0 mx-auto column1">
                        <div class="center-section">
                            <div class="col-12 p-0">
                                <div class="col-lg-12 col-12 p-0">
                                    <h5 class="label-title cluster">CLUSTER</h5>
                                    <h2 class="phtograph-heading"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-12 col-sm-12 col-xs-12">
                    </div>
                </article>
            </div>
        </div>
    </section>

    <section class="photograpers-banner-section">
        <div class="container-full">
            <div class="row">
                <article class="col-12 p-0">
                    <a href="<?php the_permalink(); ?>"><img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid w-100 d-lg-block d-none" alt="<?php the_title(); ?>"></a>
                    <a href="<?php the_permalink(); ?>"><img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid w-100 d-lg-none d-block " alt="<?php the_title(); ?>"></a>
                    <span class="cluster-photo-caption d-none">
                        <?php
                        $comma=0;
                        if(get_field('artist_name')){
                            echo get_field('artist_name');
                            $comma=1;
                        }
                        if(get_field('artwork_name')){
                            if($comma){ echo ', '; }
                            echo get_field('artwork_name');
                            $comma=1;
                        }
                        if(get_field('courtesy')){
                            if($comma){ echo ', '; }
                            echo get_field('courtesy');
                            $comma=1;
                        }
                        if(get_field('copyright')){
                            if($comma){ echo ', '; }
                            echo get_field('copyright');
                            $comma=1;
                        }
                        if($comma){ echo '. '; }

                        ?>

                    </span>
                </article>
            </div>
        </div>
    </section>

    <section class="cluster-description-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 order-1 order-md-0 p-0 d-none">
                    <aside class="left-sidebar">
                        <div class="author-details-cluster">
                            <p class="author-lable">AUTHOR(S)</p>
                            <p class="author-title"><?php the_field('author_name'); ?></p>
                            <p class="first-published">FIRST PUBLISHED</p>
                            <p class="published-date"><?php the_time('F j, Y'); ?></p>
                        </div>
                        <div class="icon-section">
                            <span class="icon-upload"><img src="<?php echo get_template_directory_uri(); ?>/images/upload-icon.svg"></span>                        
                            <span class="icon-download" onclick="print_this('p-<?php echo $post_id; ?>')"><img src="<?php echo get_template_directory_uri(); ?>/images/download-icon.svg"></span>
                            <span class="icon-quote"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/quote-icon.svg"></a></span> 
                        </div>
                        <div class="share-icons">
                            <span class="facebook-share"><a href="https://www.facebook.com/sharer?u=<?php the_permalink();?>&t=<?php the_title(); ?>" target="_blank"><i class="icon icon-facebook"></i></a></span>
                            <span class="twitter-share"><a href="http://twitter.com/intent/tweet?text=Currently reading <?php the_title(); ?>&url=<?php the_permalink(); ?>;" target="_blank"><i class="icon icon-twitter"></i></a></span>
                            <span class="email-share"><a href="mailto:vivek.kumar@langoor.com?&subject=&cc=&bcc=&body=<?php the_title(); ?>&url=<?php the_permalink(); ?>;%0A" target="_blank"><i class="icon icon-mail"></i></a></span>
                            <span class="whatsaap-share"><a href="https://api.whatsapp.com/send?text=<?php the_title(); ?>%20%E2%80%93%20<?php the_permalink(); ?>" target="_blank"><i class="icon icon-whatsapp"></i></a></span>
                        </div>
                    </aside>
                </div>
                <div class="col-lg-6 p-0">
                    <div class="pcontent">
                        <?php the_content(); ?>
                    </div>
                </div>
                <div class="col-lg-3">&nbsp;</div>
            </div>
        </div>
    </section>


        <div class="container">
            <div class="row">
                <div class="col px-0">
        <ul class="d-block d-lg-none p-0 pb-5">
            <?php
            $post_id;
            $list = get_the_terms( $post_id, 'cluster_cat' );
            foreach ( $list as $tax ) {
            ?>
            <?php
            $args = array('post_type' => 'article',
                'post_status' => 'publish',
                'orderby'        => 'post_date',
                'order' => 'DESC',
                'posts_per_page'=> -1,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'cluster_cat',
                        'field' => 'slug',
                        'terms' => $tax->name,
                    ),
                ),
            );
            $loop = new WP_Query($args);
            if($loop->have_posts()) :
               
                while($loop->have_posts()) : $loop->the_post();

                $artimage_mid = get_post_thumbnail_id($post->ID);
                $artimage_malt = get_post_meta($artimage_mid, '_wp_attachment_image_alt', TRUE);
    
                    if (get_the_post_thumbnail_url($post->ID)) {
                        $thumb_url = get_the_post_thumbnail_url($post->ID, 'thumbnail');
                    } else {
                        $thumb_url = get_field('default_thumbnail', 'option');
                    }
                    ?>
                    <li class="media list-view">
                        <a href="<?php the_permalink(); ?>">
                            <img src="<?php echo $thumb_url; ?>" class="art-img" alt="<?php echo $artimage_malt; ?>">
                        </a>
                        <div class="media-body">
                            <h5 class="mt-0"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                            <p class="pb-2"><?php
                                $content = wp_trim_words(get_post_field('post_content'), 15);
                                $pattern = "/(\[)(.*?)(\])/";
                                $content = preg_replace($pattern, '', $content);
                                echo $content;
                                ?></p>

                            <hr class="hr-border mt-4">
                        </div>
                    </li>
                    <?php wp_reset_postdata(); endwhile; endif; } ?>

        </ul>
                </div>
            </div>
        </div>
    </div>

    <?php endforeach; endif; wp_reset_query(); ?>

</div>
<!--end Mobile-->
    


<?php get_footer(); ?>


