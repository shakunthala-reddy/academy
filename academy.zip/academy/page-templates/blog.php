<?php 
/*
* Template Name: Blog
*/
get_header();
?>

<!--Desktop-->
<div class="desktop-version">
<div class="main-wrapper-div">
<section class="blog-section one-col-section blog-listing">
    <div class="container">
        <div class="short-course-details-wrap">
            <hr class="hr-border top1">
            <p class="h2titlecaps"><?php echo get_field( "top_heading");  ?></p>
            <p class="subheading"><?php echo get_field( "top_subheading");  ?></p>
            <hr class="hr-border bottom">
        </div>
        <!-- <div class="row">
            <div class="col-lg-12">
                <?php //if( get_field('top_heading') ): ?>
                <h2 class="blog-type-hrading"><?php //the_field('top_heading'); ?></h2>
                <?php //endif; ?>
                <?php //if( get_field('top_subheading') ): ?>
                <p class="blog-sub-hrading"><?php //the_field('top_subheading'); ?></p>
                <?php //endif; ?>
            </div>
        </div> -->
        <div class="row">
            <?php
            global $post;
            $args = array(
                'post_type' => 'post',
                'order' => 'DESC',
            );
            $query = new WP_Query($args);
            if($query->have_posts()):
                while($query->have_posts()): $query->the_post();
                $blogimage_mid = get_post_thumbnail_id($post->ID);
                $blogimage_malt = get_post_meta($blogimage_mid, '_wp_attachment_image_alt', TRUE);
         
            ?>
            <div class="col-lg-3 col-md-3 col-sm-12 py-3 px-3">
                <div class="well wellcourses-blog">
                    <div class="courses-image">
                        <?php
                        if (get_the_post_thumbnail_url($post->ID)) {
                            $thumb_url = get_the_post_thumbnail_url($post->ID,'large');
                        } else {
                            $thumb_url = get_field('default_thumbnail', 'option');
                        }
                        ?>
                        <a href="<?php the_permalink(); ?>"><img src="<?php echo $thumb_url; ?>" alt="<?php echo $blogimage_malt ?>"/></a>
                    </div>
                    <div class="btm-part border-0" >
                        <a href="<?php the_permalink(); ?>" class="ellipses-title"><?php the_title(); ?></a>
                        <!-- start default and custom author fetching -->
                        <?php
                        $author_check = get_field('default_author');
                        if ($author_check == 'Yes') {
                            global $post;
                            $author_id = $post->post_author;
                            ?>
                        <div class="blog-author-profile">
                            <img src="<?php the_field('default_author_profile', 'user_'. $author_id ); ?>"  class="postauth-thumb" alt="<?php the_field('default_author_name', 'user_'. $author_id ); ?>"><span class="auth-title"><?php the_field('default_author_name', 'user_'. $author_id ); ?></span>
                        </div>
                        <?php } else { ?>
                        <div class="blog-author-profile">
                            <img src="<?php the_field('author_profile'); ?>"  class="postauth-thumb" alt="<?php the_field('author_name'); ?>"><span class="auth-title"><?php the_field('author_name'); ?></span>
                        </div>
                        <?php } ?>
                        <!-- end default and custom author fetching -->
                    </div>
                </div>
            </div>
            <?php endwhile; endif; wp_reset_query(); ?>
        </div>
    </div>
</section>


<?php 
// $args = array(
//     'post_type' => 'post',
//     'order' => 'DESC',
//     'posts_per_page' => 8,
//     'meta_key'      => 'popular_post',
//     'meta_value'    => 'yes'
// );
// $query = new WP_Query($args);
// if($query->have_posts()): ?>
<!-- <section class="blog-section one-col-section blog-listing">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <?php if( get_field('bottom_heading') ): ?>
                <h2 class="blog-type-hrading"><?php the_field('bottom_heading'); ?></h2>
                <?php endif; ?>
                <?php if( get_field('bottom_subheading') ): ?>
                <p class="blog-sub-hrading"><?php the_field('bottom_subheading'); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <?php 
            $args = array(
                'post_type' => 'post',
                'order' => 'DESC',
                'posts_per_page' => 8,
                'meta_query' => array( 
                    'relation' => 'OR',
                    array(
                        'key'     => 'popular_post',
                        'value'   => 'yes',
                    ),
                    array(
                        'key' => 'my_post_viewed',
                        'orderby' => 'meta_value_num',      
                    ),
                ),                
            );
            $query = new WP_Query($args);
            if($query->have_posts()):
                while($query->have_posts()): $query->the_post();
                $blogimage_mid = get_post_thumbnail_id($post->ID);
                $blogimage_malt = get_post_meta($blogimage_mid, '_wp_attachment_image_alt', TRUE);
         
                $mycontent = $post->post_content; 
                $word = str_word_count(strip_tags($mycontent));
                $m = floor($word / 200);
                $s = floor($word % 200 / (200 / 60));
                $est = $m . ' min' . ($m == 1 ? '' : 's') ;
            ?>
            <div class="col-lg-3 col-6 mb-0">
                <?php
                if (get_the_post_thumbnail_url($post->ID)) {
                    $thumb_url = get_the_post_thumbnail_url($post->ID,'large');
                } else {
                    $thumb_url = get_field('default_thumbnail', 'option');
                }
                ?>
                <a href="<?php the_permalink(); ?>"><img src="<?php echo $thumb_url; ?>" class="img-responsive"></a>
                <div class="blog-part">
                    <p class="blog-lable">BLOG</p>
                    <div class="blog-summary-wrap">
                        <a class="blog-title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        <p class="blog-description"><?php echo wp_strip_all_tags(get_the_content()); ?></p>
                    </div>
                    <div class="col-12 p-0 double-part d-flex flex-row flex-wrap justify-content-between">
                        <div class="read-more p-0"><a href="<?php the_permalink(); ?>">Read More</a></div>
                        <?php if ($m == 0) { ?>
                         <div class="read-time p-0">1 min read</div>   
                        <?php } else { ?>
                           <div class="read-time p-0"><?php echo $est; ?> read</div>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <?php endwhile; endif; wp_reset_query(); ?>
        </div>
    </div>
</section> -->
<?php //endif; ?>




</div>
</div>
<!--end desktop-->

<!-- Mobile Version -->

<!--Mobile-->
<div class="mobile-version">
    <div class="main-wrapper-div mt-4">
        <section class="blog-section one-col-section">
            <div class="container">
                <div class="short-course-details-wrap">
                    <hr class="hr-border top1">
                    <p class="h2titlecaps"><?php echo get_field( "top_heading");  ?></p>
                    <p class="subheading"><?php echo get_field( "top_subheading");  ?></p>

                    <img src="https://mapeia.langoorqa.net/wp-content/uploads/2022/04/blog-icon.svg" class="icon-title mobile-view" width="30px" alt="<?php echo get_field( "top_heading");  ?>">
                    <hr class="hr-border bottom">
                </div>
                <ul class="d-block d-lg-none p-0">
                    <?php
                    $args = array(
                        'post_type' => 'post',
                        'order' => 'DESC',
                    );
                    $loop = new WP_Query($args);
                    if ($loop->have_posts()) :
                        while ($loop->have_posts()) : $loop->the_post();
                        $blogimage_mid = get_post_thumbnail_id($post->ID);
                        $blogimage_malt = get_post_meta($blogimage_mid, '_wp_attachment_image_alt', TRUE);
                 
                   
                            ?>
                            <?php
                            if (get_the_post_thumbnail_url($post->ID)) {
                                $thumb_url = get_the_post_thumbnail_url($post->ID, 'thumbnail');
                            } else {
                                $thumb_url = get_field('default_thumbnail', 'option');
                            }
                            ?>
                            <li class="media list-view">

                                <a href="<?php the_permalink(); ?>"><img src="<?php echo $thumb_url; ?>" class="art-img"
                                                                         alt="<?php echo $blogimage_malt ?>"/></a>
                                <div class="media-body">
                                    <h5 class="mt-0 mb-1 ellipses-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                    <p class="publish">published: <?php echo get_the_date( 'd/m/Y' ); ?></p>

                                    <?php
                                    if ($author_check == 'Yes') {
                                        global $post;
                                        $author_id = $post->post_author;
                                        ?>
                                        <div class="blog-author-profile">
                                            <img src="<?php the_field('default_author_profile', 'user_' . $author_id); ?>"
                                                 class="postauth-thumb"><span
                                                    class="auth-title"><?php the_field('default_author_name', 'user_' . $author_id); ?></span>
                                        </div>
                                    <?php } else { ?>
                                        <div class="blog-author-profile">
                                            <img src="<?php the_field('author_profile'); ?>" class="postauth-thumb"><span
                                                    class="auth-title"><?php the_field('author_name'); ?></span>
                                        </div>
                                    <?php } ?>

                                    <hr class="hr-border">
                                </div>
                            </li>
                        <?php endwhile; endif;
                    wp_reset_query(); ?>
                </ul>

            </div>
        </section>
    </div>
</div>
<!--end mobile-->

<?php get_footer(); ?>

<script>
    $('.owl-carousel').owlCarousel({
        loop:true,
        margin:10,
        autoplay:true,
        nav:false,
        dots: false,
        responsive:{
            0:{
                items:1.1
            },
            
            1000:{
                items:3.5
            }
        }
    });
</script>
