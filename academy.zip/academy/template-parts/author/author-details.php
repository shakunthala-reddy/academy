<?php 
/*
* Author Details
*/
?>
<?php
$current_post_id = get_the_ID();
$author_check = get_field('default_author'); 
if ($author_check == 'Yes') {
	global $post;
    $author_id = $post->post_author;
    //$authord = get_the_author_meta( 'user_email', $author_id);
    //echo $authord;
	
?>
<div class="custom-author">
    <span class="author-profile hover-img" data-wrap="auth-<?php echo $current_post_id; ?>"><img src="<?php the_field('default_author_profile', 'user_'. $author_id ); ?>" class="img-responsive" alt="<?php the_field('default_author_name', 'user_'. $author_id ); ?>"></span><span class="author-title"><?php the_field('default_author_name', 'user_'. $author_id ); ?></span>
    <div class="author-hover-details" id="auth-<?php echo $current_post_id; ?>">
<!--    	<div class="author-detail-profile">-->
<!--    		<div class="profile">-->
<!--    			<img src="--><?php //the_field('default_author_profile', 'user_'. $author_id); ?><!--" class="img-fluid">-->
<!--    		</div>-->
<!--    		<div class="title-designation">-->
<!--    			<p class="author-title">--><?php //the_field('default_author_name', 'user_'. $author_id); ?><!--</p><p class="author-designation">--><?php //the_field('default_author_designation', 'user_'. $author_id); ?><!--</p>-->
<!--    		</div>-->
<!--    	</div>-->
    	<div class="short-description">
    		<p><?php the_field('default_author_short_description', 'user_'. $author_id); ?></p>
    	</div>
    	<!-- <div class="social-media-details">
    		<?php
			if( have_rows('default_author_social_connection', 'user_'. $author_id) ):
			    while( have_rows('default_author_social_connection', 'user_'. $author_id) ) : the_row();
			    	$default_social_icon = get_sub_field('default_social_icon');
			    	$default_social_link = get_sub_field('default_social_link');
			    	
			?>
    		<span class="<?php echo $default_social_icon; ?>-link"><a href="<?php echo $default_social_link; ?>" target="_blank"><i class="icon icon-<?php echo $default_social_icon; ?>"></i></a></span>
		    <?php endwhile; endif;  ?>
    	</div> -->
    </div>
</div>
<?php } else { ?>

<div class="custom-author">
    <span class="author-profile hover-img" data-wrap="auth-<?php echo $current_post_id; ?>"><img src="<?php the_field('author_profile'); ?>" class="img-responsive" alt="<?php the_field('author_name'); ?>"/></span><span class="author-title"><?php the_field('author_name'); ?></span>
    <div class="author-hover-details" id="auth-<?php echo $current_post_id; ?>">
<!--    	<div class="author-detail-profile">-->
<!--    		<div class="profile">-->
<!--    			<img src="--><?php //the_field('author_profile'); ?><!--" class="img-responsive" alt="--><?php //the_field('author_name'); ?><!--">-->
<!--    		</div>-->
<!--    		<div class="title-designation">-->
<!--    			<p class="author-title">--><?php //the_field('author_name'); ?><!--</p><p class="author-designation">--><?php //the_field('author_designation'); ?><!--</p>-->
<!--    		</div>-->
<!--    	</div>-->
    	<div class="short-description">
            <?php if(get_field('author_designation')) { ?>
                <p class="author-designation"><?php the_field('author_designation'); ?></p>
                <?php
            }
            ?>
    		<p><?php the_field('author_short_description'); ?></p>
    	</div>
    	<!-- <div class="social-media-details">
    		<?php
			if( have_rows('author_social_connection') ):
			    while( have_rows('author_social_connection') ) : the_row();
			    	$social_icon = get_sub_field('social_icon');
			    	$social_link = get_sub_field('social_link');
			?>
    		<span class="<?php echo $social_icon; ?>-link"><a href="<?php echo $social_link; ?>" target="_blank"><i class="icon icon-<?php echo $social_icon; ?>"></i></a></span>
		    <?php endwhile; endif; ?>
    	</div> -->
    </div>
</div>

<?php } ?>



