<?php 
/*
* Author Details
*/
?>
<?php
$author_id = 1;
$current_post_id = get_the_ID();
?>
<div class="custom-author">
    <span class="author-profile hover-img" data-wrap="auth-<?php echo $current_post_id; ?>">
    	<img src="<?php the_field('default_author_profile', 'user_'. $author_id ); ?>" class="img-responsive" alt="Map Academy"></span>
    	<span class="author-title"><?php the_field('default_author_name', 'user_'. $author_id ); ?></span>
<!--    Change Class name to "author-hover-details" to enable popup-->
    <div class="author-hover-details" id="auth-<?php echo $current_post_id; ?>">
<!--    	<div class="author-detail-profile">-->
<!--    		<div class="profile">-->
<!--    			<img src="--><?php //the_field('default_author_profile', 'user_'. $author_id); ?><!--" class="img-fluid">-->
<!--    		</div>-->
<!--    		<div class="title-designation">-->
<!--    			<p class="author-title">--><?php //the_field('default_author_name', 'user_'. $author_id); ?><!--</p><p class="author-designation">--><?php //the_field('default_author_designation', 'user_'. $author_id); ?><!--</p>-->
<!--    		</div>-->
<!--    	</div>-->
    	<div class="short-description">
    		<p><?php the_field('default_author_short_description', 'user_'. $author_id); ?></p>
    	</div>
    	<!-- <div class="social-media-details">
    		<?php
			if( have_rows('default_author_social_connection', 'user_'. $author_id) ):
			    while( have_rows('default_author_social_connection', 'user_'. $author_id) ) : the_row();
			    	$default_social_icon = get_sub_field('default_social_icon');
			    	$default_social_link = get_sub_field('default_social_link');
			    	
			?>
    		<span class="<?php echo $default_social_icon; ?>-link"><a href="<?php echo $default_social_link; ?>" target="_blank"><i class="icon icon-<?php echo $default_social_icon; ?>"></i></a></span>
		    <?php endwhile; endif;  ?>
    	</div> -->
    </div>
</div>
<?php



