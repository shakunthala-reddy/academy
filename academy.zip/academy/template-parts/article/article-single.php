<?php
$current_post_id = get_the_ID();
?>
<script>
    imageData=[];
    catalogue=[];
</script>

<article class="article-post article-post-new" id="p-<?php echo $current_post_id; ?>" data-id="<?=$current_post_id?>">

    <div class="container entry-header">
        <div class="row">
            <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12"></div>
            <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                <div class="label-section">
                    <h5 class="label-title article">ARTICLE </h5>
                    <h2 class="phtograph-heading"><?php the_title(); ?> <?php if( get_field('dobd') ): ?><span class="dobd"><?php the_field('dobd'); ?></span><?php endif; ?></h2>
                    <?php
                        get_template_part('/template-parts/author/author-details-article');
                    ?>
                </div>
            </div>
            <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12"></div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 order-1 order-md-0">
                <aside class="left-sidebar">
                    <div class="author-details">
                        <div class="wrap-filed-info">
                            <p class="filed-under-lable">FILED UNDER</p>
                            <p class="under-listing">
                                <?php
                                $filed_taxterms = get_the_terms(get_the_ID(), 'department');
                                foreach ($filed_taxterms as $filed_list) { ?>
                                    <a href="<?php echo home_url(); ?>/encyclopedia-search/?&department=<?php echo $filed_list->slug; ?>"><?php echo $filed_list->name;
                                        ?>
                                    </a>
                                <?php } ?>
                            </p>
                            
                            <p class="first-published">FIRST PUBLISHED</p>
                            <p class="published-date"><?php the_time('F j, Y'); ?></p>
                            <?php if( get_field('last_updated') ): ?>
                            <p class="first-published">LAST UPDATED</p>
                            <p class="published-date"><?php the_field('last_updated'); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php
                        get_template_part('/template-parts/social-icon/social-icon');
                    ?>
                    <!-- below is copy message, filed-under-lable class is used just to make the text look like "Filed Under" -->
                    <div id="copy-message" class="filed-under-lable" style="display: none; text-align: center;"> 
                        <p> Text Copied to ClipBoard!!</p>
                        </div>
                </aside>
            </div>

            <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 initial-content-box">
                <div class="main-content-area">
                    <div class="content-section ">
                        <?php                        
                            the_content();
                        ?>
                    </div>
                    <?php
                    if (!empty($list_cluster_cat)) { ?>
                        <p class="photograph-description small-font">This article is part of the <a href="<?php the_permalink(2); ?>">Five photographers who changed modern India</a> Cluster.</p>
                    <?php } ?>
                </div>
            </div>
            <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
                <aside class="right-sidebar d-none d-lg-block">
                    <div class="right-section"></div>
                    <?php
                        get_template_part('/template-parts/related-content/related-content');
                    ?>
                </aside>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
                <div class="blank-area">&nbsp;</div>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                <div class="bio-feed-section">
                    <div class="biblo-feed ">
                        <h6 class="bio" data-wrap="<?php echo $current_post_id; ?>">Bibliography</h6>
                        <div class="bio_wrap" id="bio_wrap_<?php echo $current_post_id; ?>">
                            <?php the_field('bibliography'); ?>
                        </div>
                    </div>
                    <div class="biblo-feed ">
                        <h6 class="feed" data-wrap="<?php echo $current_post_id; ?>">Feedback</h6>
                        <div class="feed_wrap"  id="feed_wrap_<?php echo $current_post_id; ?>">
                            <div class="feedback-form"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
                <div class="blank-area">&nbsp;</div>
            </div>
        </div>
    </div>
</article>

<?php
    get_template_part('/template-parts/divider/divider');
?>


<script>
    $('.article-post:last').css("visibility","hidden");
    postData.push({
        postid: "<?=$current_post_id ?>",
        image: imageData
    });

    displayData=([{
        post:postData
    }]);
   console.log(displayData);
    localStorage.setItem("postData", JSON.stringify(displayData));

//    Just to output the data
    var display = localStorage.getItem('postData');
    console.log("Image Data For Carousel");
    console.log(display);
</script>


