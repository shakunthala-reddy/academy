<?php 
/*
Social Icon Section
*/
?>
<?php 
$current_post_id = get_the_ID(); 
$current_post_type =  get_post_type($current_post_id);
?>
<div class="icon-section">
	<span class="facebook-share"><a href="https://www.facebook.com/sharer?u=<?php the_permalink();?>&t=<?php the_title(); ?>" target="_blank"><i class="icon icon-facebook"></i></a></span>
	<span class="twitter-share"><a href="http://twitter.com/intent/tweet?text=Currently reading <?php the_title(); ?>&url=<?php the_permalink(); ?>;" target="_blank"><i class="icon icon-twitter"></i></a></span>
	<span class="email-share"><a href="mailto:vivek.kumar@langoor.com?&subject=&cc=&bcc=&body=<?php the_title(); ?>&url=<?php the_permalink(); ?>;%0A" target="_blank"><i class="icon icon-mail"></i></a></span>
	<span class="whatsaap-share"><a href="https://api.whatsapp.com/send?text=<?php the_title(); ?>%20%E2%80%93%20<?php the_permalink(); ?>" target="_blank"><i class="icon icon-whatsapp"></i></a></span>
	<span class="quote-share" data-toggle="modal" data-target="#citation-<?php echo $current_post_id; ?>"><i class="icon icon-quote"></i></span>
	<!-- <span class="download-share" onclick="print_this('p-<?php echo $current_post_id; ?>')"><i class="icon icon-download"></i></span> -->

    <!--  copy button-->
    <span onClick='copyToClipboard("#copytext");'> <i  class="customicon customicon-copy-text"></i>
                    <div id="copytext" style="display: none;" >
                            
                            <?php 
                            
                            // $title_text = get_the_title();
                            $title_text = wp_strip_all_tags( get_the_title() );
                            // $content_text = get_the_content();
                            $content_text = wp_strip_all_tags( get_the_content() );
                            
                            echo $title_text;
                            echo "%newline%";
                            echo $content_text;
                            
                            ?>      
                    </div>
                        
    </span>
    <br>
    <!-- hindi translation language switcher -->
    <?php 
    $post_link = get_field('translate');
    ?> 
    <?php if($post_link): ?>
        <span>
            <a href= "<?php echo $post_link ?>">
            <i class="customicon customicon-translate-la">
            </i>
            </a>
        </span>
    <?php endif; ?>
</div>

<!--Citation-->                    
<div class="modal fade citation-main" id="citation-<?php echo $current_post_id; ?>" tabindex="-1" role="dialog" aria-labelledby="citationModalLabel-<?php echo $current_post_id; ?>" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">     
            <div class="modal-header-wrap">     
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true"><i class="icon icon-cross"></i></span>
                </button>
            </div>
            <?php if($current_post_type == 'post'){ ?>
            <div class="modal-body m-auto text-center">
                <h5 class="cite-heading">Cite this text</h5>
                <table class="table-responsive citation-detail-wrapper">
                    <tr>
                        <td class="lable-text">Chicago</td>
                        <td class="copy-text" id="chicago-<?php echo $current_post_id; ?>">MAP Academy Blog. “<?php the_title(); ?>”. Accessed <?php echo date('F j, Y'); ?>. <?php the_permalink(); ?></td>
                        <td class="copy-btn"><button class="copyiconbtn" onclick="CopyToClipboard('chicago-<?php echo $current_post_id; ?>')"><i class="icon icon-copy"></i></button></td>
                    </tr>
                    <tr>
                        <td class="lable-text">MLA</td>
                        <td class="copy-text" id="mla-<?php echo $current_post_id; ?>">“<?php the_title(); ?>.” <i>MAP Academy Blog. </i><?php the_permalink(); ?>. Accessed <?php echo date('j, F, Y'); ?>. </td>
                        <td class="copy-btn"><button class="copyiconbtn" onclick="CopyToClipboard('mla-<?php echo $current_post_id; ?>')"><i class="icon icon-copy"></i></button></td>
                    </tr>
                    <tr>
                        <td class="lable-text">Harvard</td>
                        <td class="copy-text" id="harvard-<?php echo $current_post_id; ?>">MAP Academy Blog. (2022) <i><?php the_title(); ?></i>. [Online]. Available at: <?php the_permalink(); ?>. (Accessed: <?php echo date('j, F, Y'); ?>) </td>
                        <td class="copy-btn"><button class="copyiconbtn" onclick="CopyToClipboard('harvard-<?php echo $current_post_id; ?>')"><i class="icon icon-copy"></i></button></td>
                    </tr>
                    <span id="custom-tooltip">Copied!</sapn>
                </table>
            </div>
            <?php }elseif($current_post_type=='cluster') { ?>
            <div class="modal-body m-auto text-center">
                <h5 class="cite-heading">Cite this text</h5>
                <table class="table-responsive citation-detail-wrapper">
                    <tr>
                        <td class="lable-text">Chicago</td>
                        <td class="copy-text" id="chicago-<?php echo $current_post_id; ?>">MAP Academy Cluster . “<?php the_title(); ?>”. Accessed <?php echo date('F j, Y'); ?>. <?php the_permalink(); ?></td>
                        <td class="copy-btn"><button class="copyiconbtn" onclick="CopyToClipboard('chicago-<?php echo $current_post_id; ?>')"><i class="icon icon-copy"></i></button></td>
                    </tr>
                    <tr>
                        <td class="lable-text">MLA</td>
                        <td class="copy-text" id="mla-<?php echo $current_post_id; ?>">“<?php the_title(); ?>.” <i>MAP Academy Cluster . </i><?php the_permalink(); ?>. Accessed <?php echo date('j, F, Y'); ?>. </td>
                        <td class="copy-btn"><button class="copyiconbtn" onclick="CopyToClipboard('mla-<?php echo $current_post_id; ?>')"><i class="icon icon-copy"></i></button></td>
                    </tr>
                    <tr>
                        <td class="lable-text">Harvard</td>
                        <td class="copy-text" id="harvard-<?php echo $current_post_id; ?>">MAP Academy Cluster . (2022) <i><?php the_title(); ?></i>. [Online]. Available at: <?php the_permalink(); ?>. (Accessed: <?php echo date('j, F, Y'); ?>) </td>
                        <td class="copy-btn"><button class="copyiconbtn" onclick="CopyToClipboard('harvard-<?php echo $current_post_id; ?>')"><i class="icon icon-copy"></i></button></td>
                    </tr>
                    <span id="custom-tooltip">Copied!</sapn>
                </table>
            </div>
            <?php }else{ ?>
            <div class="modal-body m-auto text-center">
                <h5 class="cite-heading">Cite this article</h5>
                <table class="table-responsive citation-detail-wrapper">
                    <tr>
                        <td class="lable-text">Chicago</td>
                        <td class="copy-text" id="chicago-<?php echo $current_post_id; ?>">MAP Academy Encyclopedia of Art. “<?php the_title(); ?>”. Accessed <?php echo date('F j, Y'); ?>. <?php the_permalink(); ?></td>
                        <td class="copy-btn"><button class="copyiconbtn" onclick="CopyToClipboard('chicago-<?php echo $current_post_id; ?>')"><i class="icon icon-copy"></i></button></td>
                    </tr>
                    <tr>
                        <td class="lable-text">MLA</td>
                        <td class="copy-text" id="mla-<?php echo $current_post_id; ?>">“<?php the_title(); ?>.” <i>MAP Academy Encyclopedia of Art. </i><?php the_permalink(); ?>. Accessed <?php echo date('j, F, Y'); ?>. </td>
                        <td class="copy-btn"><button class="copyiconbtn" onclick="CopyToClipboard('mla-<?php echo $current_post_id; ?>')"><i class="icon icon-copy"></i></button></td>
                    </tr>
                    <tr>
                        <td class="lable-text">Harvard</td>
                        <td class="copy-text" id="harvard-<?php echo $current_post_id; ?>">MAP Academy Encyclopedia of Art. (2022) <i><?php the_title(); ?></i>. [Online]. Available at: <?php the_permalink(); ?>. (Accessed: <?php echo date('j, F, Y'); ?>) </td>
                        <td class="copy-btn"><button class="copyiconbtn" onclick="CopyToClipboard('harvard-<?php echo $current_post_id; ?>')"><i class="icon icon-copy"></i></button></td>
                    </tr>
                    <span id="custom-tooltip">Copied!</sapn>
                </table>
            </div>
            <?php } ?>
            

        </div>
    </div>
</div>                    
<!-- End -->