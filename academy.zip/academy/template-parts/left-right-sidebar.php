<?php 
/*
* Template Name: Left-right-sidbar template
*/

get_header();

?>
<style>
    
</style>
<div class="main-wrapper-div">
<section class="container-fluid left-right-sidebar-template p-0">
    <div class="container">
        <div class="row"> 
            <div class="col-md-3 left-sidebar-content-wrap">
                <?php //echo do_shortcode('[ez-toc]'); ?>
                    <?php 
                        $shorcode = get_field('sidebarshortcode');
                        echo do_shortcode($shorcode); 
                    ?>
            </div>

            <div class="col-lg-6 main-content-wrap">
                    <?php the_content(); ?>
            </div>
            
            <div class="col-lg-3 right-sidebar-content-wrap">
            </div>

            
        </div>        
    </div>
</section>

</div>


<?php get_footer(); ?>

<script>
    $('.left-sidebar-content-wrap li > a').click(function() {
        $('.left-sidebar-content-wrap li > a').removeClass();
        $(this).addClass('active');
    })
</script>

<script>
    jQuery(function() {
        jQuery('a[href*=#]:not([href=#])').click(function() {
            if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {

                var target = jQuery(this.hash);
                target = target.length ? target : jQuery('[name=' + this.hash.slice(1) +']');
                if (target.length) {
                    jQuery('html,body').animate({
                    scrollTop: target.offset().top -130
                    }, 0);
                    return false;
                }
            }
        });
    });
    
</script>


