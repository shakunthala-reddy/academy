<?php
// get the post obj
[
    'post_id' => $post_id
] = $args;
setup_postdata($post_id);
global $post;
?>
    </div></div></div>

<?php
global $post;
$current_post_id = $post->ID;
$index=0;
if (have_rows('carousel_data', $post_id)):
    while (have_rows('carousel_data', $post_id)): the_row();
        $image = get_sub_field('image');
        $title_of_the_image = get_sub_field('title');
        $artistsmakers = get_sub_field('artistsmakers');
        $date = get_sub_field('date');
        $medium = get_sub_field('medium');
        $dimensions = get_sub_field('dimensions');
        $courtesy = get_sub_field('courtesy');
        $index++;
        //$imageIndex="img-".$post_id.$index;
        $imageIndex=$post_id.$index;
        $high_res_available=0;
        $high_image_url = 0;
        if (get_sub_field('high_resolution_image')) {
            $high_image = get_sub_field('high_resolution_image');
            $high_image_url = $high_image['url'];
            $high_res_available = 1;
        }
        ?>

        <?php
        $imageDetails="";
        if ($title_of_the_image):
            $imageDetails=$imageDetails.$title_of_the_image . "; ";
        endif;
        if ($artistsmakers):
            $imageDetails=$imageDetails. $artistsmakers;
            if ($date || $medium || $dimensions || $courtesy) {
                $imageDetails=$imageDetails. "; ";
            }
        endif;
        if ($date):
            $imageDetails=$imageDetails. $date;
            if ($medium || $dimensions || $courtesy) {
                $imageDetails=$imageDetails. "; ";
            }
        endif;
        if ($medium):
            $imageDetails=$imageDetails. $medium;
            if ($dimensions || $courtesy) {
                $imageDetails=$imageDetails. "; ";
            }
        endif;
        if ($dimensions):
            $imageDetails=$imageDetails. $dimensions;
            if ($courtesy) {
                $imageDetails=$imageDetails. "; ";
            }
        endif;
        if ($courtesy):
            $imageDetails=$imageDetails. $courtesy;
        endif;


        ?>
        <script>
            imageData.push({
                id:'<?=$imageIndex?>',
                url: '<?=$image['url'] ?>',
                high_res_url: '<?=$high_image_url ?>',
                catalogue: [
                    {catalogue: '<?php echo $imageDetails ?>'},
                ],
            });
        </script>
        <?php
    endwhile;
endif;
?>
    <div class="content-carousel carousel-right-below-extended">
        <?php
        $index=0;
        if (have_rows('carousel_data', $post_id)):
            while (have_rows('carousel_data', $post_id)): the_row();
                $image = get_sub_field('image');
                $title_of_the_image = get_sub_field('title');
                $artistsmakers = get_sub_field('artistsmakers');
                $date = get_sub_field('date');
                $medium = get_sub_field('medium');
                $dimensions = get_sub_field('dimensions');
                $courtesy = get_sub_field('courtesy');
                $index++;
                //$imageIndex="img-".$post_id.$index;
                $imageIndex=$post_id.$index;
                $high_res_available = 0;
                if (get_sub_field('high_resolution_image')) {
                    $high_image = get_sub_field('high_resolution_image');
                    $high_res_available = 1;
                } else {
                    $high_image = get_sub_field('image');
                }
                ?>

                <div>
                    <div class="slide">
                        <figure class="slide-image">
                            <img class="d-none d-md-block" id="<?=$imageIndex?>" src="<?php echo $image['url']; ?>"
                                 alt="<?php echo $image['alt']; ?>" data-toggle="modal" data-target="#myModal"
                                 onclick="openSlider(<?= $current_post_id ?>,'<?php echo $high_image['url']; ?>','<?=$imageIndex?>','<?php echo site_url(); ?>', <?=$high_res_available?>)">
                            <!--                             Disabling Modal popup on mobile phone by not passing modal data attributes-->
                            <img class="d-block d-md-none" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>">

                        </figure>
                        <button class='pp1 slick-prev'><span class='icon icon-arrow-left'></span></button>
                        <button class='nn1 slick-next'><span class='icon icon-arrow-right'></span></button>
                        <div class="gallery-details">
                            <div class="gallery-info">

                                <?php
                                $imageDetails="";
                                if ($title_of_the_image):
                                    $imageDetails=$imageDetails.$title_of_the_image . "; ";
                                endif;
                                if ($artistsmakers):
                                    $imageDetails=$imageDetails. $artistsmakers;
                                    if ($date || $medium || $dimensions || $courtesy) {
                                        $imageDetails=$imageDetails. "; ";
                                    }
                                endif;
                                if ($date):
                                    $imageDetails=$imageDetails. $date;
                                    if ($medium || $dimensions || $courtesy) {
                                        $imageDetails=$imageDetails. "; ";
                                    }
                                endif;
                                if ($medium):
                                    $imageDetails=$imageDetails. $medium;
                                    if ($dimensions || $courtesy) {
                                        $imageDetails=$imageDetails. "; ";
                                    }
                                endif;
                                if ($dimensions):
                                    $imageDetails=$imageDetails. $dimensions;
                                    if ($courtesy) {
                                        $imageDetails=$imageDetails. "; ";
                                    }
                                endif;
                                if ($courtesy):
                                    $imageDetails=$imageDetails. $courtesy;
                                endif;

                                echo $imageDetails;
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; endif;
        wp_reset_query(); ?>
    </div>


    <!--Right sidebar to load right side carousel-->
    <div class="col-lg-3 right-slider-location slider-sidebar">
    </div>

    <div class="col-lg-6 offset-lg-3 added-by-right-slider">
        <div class="main-content-area">
            <div class="content-section">
<?php
wp_reset_postdata();