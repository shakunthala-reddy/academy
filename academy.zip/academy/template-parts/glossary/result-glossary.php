<?php
global $post;
$excludedArticlePosts = $_POST['excludedArticlePosts'];
$excludedBlogPosts = $_POST['excludedBlogPosts'];

$query = new WP_Query($args);
if ($query->have_posts()) {
    while ($query->have_posts()) {
        $query->the_post();

        ?>

        <div class="container">
            <div class="row result-subbox" data-postID="<?= get_the_ID() ?>">
                <div class="w-100">
                    <h5 class="result-label-title glossary">Glossary</h5>

                </div>
                <a href="<?php echo get_permalink() ?>"><h4><?php the_title(); ?></h4></a>
                <?php the_content() ?>
                <div class="icon-box">
            <span><a href="" class="mx-3"><img
                            src="<?php echo get_template_directory_uri(); ?>/images/up.svg"
                            class="img-fluid" alt="<?php the_title(); ?>"></a></span>
                    <span><a href="" class="mx-3"><img
                                    src="<?php echo get_template_directory_uri(); ?>/images/up.svg"
                                    class="img-fluid rotate-180" alt="up"></a></span>
                </div>
            </div>
        </div>

        <?php
        $counter = $_POST['counter'];
        $current_post_id = get_the_ID();

        if ($counter == 3) {
            $tax = 'custom_category';
            $counter = 0;

           ?>

                <section class="blog-section one-col-section">
                    <div class="container">
                        <div class="row">

                        </div>
                        <div class="row">
                            <?php
                            $terms = get_the_terms($current_post_id, $tax);
                                    shuffle($terms);
                            $term_slug = $terms[0]->slug;
                            $tax_query = [
                                'taxonomy' => $tax,
                                'field' => 'slug',
                                'terms' => $term_slug
                            ];
                            $args3 = array(
                                'post_type' => 'article',
                                'posts_per_page' => 4,
                                'post__not_in' => $excludedArticlePosts,
                                'tax_query' => $tax_query,
                            );
                            $postCountQuery3 = new WP_Query($args3);
                            $postCount3 = $postCountQuery3->found_posts;
                            if ($postCount3 < 4) {
                                $excludedArticlePosts = [];
                                $args3 = array(
                                    'post_type' => 'article',
                                    'posts_per_page' => 4,
                                    'post__not_in' => $excludedArticlePosts,
                                    'tax_query' => $tax_query,
                                );
                            }

                            $query3 = new WP_Query($args3);
                            if ($query3->have_posts()):
                                while ($query3->have_posts()): $query3->the_post();
                                    $mycontent = $post->post_content; // wordpress users only
                                    $word = str_word_count(strip_tags($mycontent));
                                    $m = floor($word / 200);
                                    $s = floor($word % 200 / (200 / 60));
                                    $est = $m . 'min' . ($m == 1 ? '' : 's');
                                    $image_mid = get_post_thumbnail_id($post->ID);
                                    $image_malt = get_post_meta($image_mid, '_wp_attachment_image_alt', TRUE);
                             
                                    ?>

                                    <script>
                                        var currentPostID =<?=get_the_ID() ?>;
                                        WP_URLS.excluded_article_posts.push(currentPostID);
                                    </script>

                                    <div class="col-lg-3 col-6 mb-0">
                                        <a href="<?php the_permalink(); ?>"><img
                                                    src="<?php echo get_the_post_thumbnail_url(); ?>"
                                                    class="img-fluid w-100" alt="<?php echo $image_malt;?>"></a>
                                        <div class="blog-part">
                                            <p class="blog-lable">Article</p>
                                            <p class="blog-title"><a
                                                        href="<?php the_permalink(); ?>"><?php the_title(); ?></a></p>
                                            <p class="blog-description"><?php echo mb_strimwidth(get_the_content(), 0, 120, '...'); ?></p>
                                            <div class="col-12 p-0 double-part d-flex flex-row flex-wrap justify-content-between">
                                                <div class="read-more p-0"><a href="<?php the_permalink(); ?>">Read
                                                        More</a></div>
                                                <div class="read-time p-0"><?php echo $est; ?> read</div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; endif;
                            wp_reset_query(); ?>
                        </div>
                    </div>
                </section>

            <?php

        }
        $counter++;

        ?>

        <script>
            WP_URLS.counter =<?=$counter ?>;
            var currentPostID =<?=$current_post_id ?>;
            WP_URLS.current_post_id = currentPostID;
            WP_URLS.excluded_blog_posts.push(currentPostID);
        </script>


    <?php } ?>

<?php } else { ?>
    <script>
        runAjax = false;
    </script>
    <div class="row no-more">
        <div class="col-4 pl-0 pr-0 pt-2">
            <div class="line"></div>
        </div>
        <div class="col-4 pl-0 pr-0 text-center">No more results.</div>
        <div class="col-4 pl-0 pr-0 pt-2">
            <div class="line"></div>
        </div>
    </div>

<?php }

wp_reset_postdata();
