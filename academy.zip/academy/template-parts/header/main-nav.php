<!--Navbar-->
<div class="headertop_wrap">
    <nav class="navbar" id="activeexplore">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="form-group has-search m-0" id="mobileSearch">
                        <div class="center-section">
                            <form action="<?php echo site_url(); ?>/encyclopedia-search/" method="get">
                                <div class="search-input">
                                    <a href="" target="_blank" hidden></a>
                                    <i class="icon icon-search form-control-feedback search-icn-black"></i>
                                    <span class="clearable">
                                        <input type="text"  name="result" class="form-control desktp-search-box"
                                            placeholder="Search over 10,000 years of art history" id="adv_search" minlength="1"
                                            value="<?php if(!empty($_GET['result'])){ echo $_GET['result']; } ?>" autocomplete="off">
                                        <span class="go-btn d-none"><i class="icon icon-arrow-right"></i></span>
                                        <span class="clear-lable"><i class="clearable__clear">&times;</i></span>
                                    </span>
                                    <div id="search_listing" class="autocomplete-box">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="left px-0">
            <!-- Collapse button -->
            <button class="navbar-toggler" type="button" id="navbarToggler" data-target="#mainMenu">
                <i class="icon icon-menu"></i>
            </button>
            <!-- Navbar brand -->
            <a class="navbar-brand" href="<?php echo home_url(); ?>">
                <?php
                if ( is_front_page() ) :
                ?>
                    <lottie-player src="<?php echo get_template_directory_uri(); ?>/images/lottie/MAP_LogoAnim_Black-over-Alpha.json" background="transparent"  speed="1"  style="width: 185px; height: 33px; margin-left: -7px;" alt="mapacademy" autoplay></lottie-player>
                <?php else : ?>
                    <img src="<?php the_field('logo', 'option'); ?>" class="img-fluid" alt="mapacademy">
                <?php endif; ?>
            </a>
        </div>
        
        <!-- Search Toggler Mobile Devices -->
        <div class="right d-inline-block d-lg-none">
            <button class="search-toggler" type="button" id="searchToggler" data-target="#mobileSearch">
                <i class="icon icon-search"></i>
            </button>
        </div>

        <!-- <div class="col-auto px-0 form-group has-search d-lg-block d-none mb-0">
            <div class="center-section">
                <form action="<?php echo site_url(); ?>/encyclopedia-search/" method="get">

                    <div class="search-input">
                        <a href="" target="_blank" hidden></a>
                        <span class="fa fa-search form-control-feedback search-icn-black"></span>
                        <span class="clearable">
                            <input type="text" name="result" class="form-control desktp-search-box"
                                placeholder="Search over 10,000 years of art history" id="adv_search" minlength="4"
                                value="<?php if($_GET['result']){ echo $_GET['result']; } ?>" autocomplete="off">
                            <span class="clear-lable"><i class="clearable__clear">&times; Clear</span></i>
                        </span>
                        <div id="search_listing" class="autocomplete-box">
                        </div>
                    </div>
                </form>
            </div>
        </div> -->


        <!-- <button class="header-subscribe px-3 py-1 d-lg-block d-none">Subscribe</button> -->

        <div class="d-none d-lg-flex flex-row align-items-center justify-content-end right px-0">
            <?php if( get_field('subscription_form_button_label', 'option') ): ?>
            <button class="header-subscribe px-3 py-1" data-toggle="modal" data-target="#subscribeModal" ><?php the_field('subscription_form_button_label', 'option'); ?></button>
            <?php endif; ?>
            <button class="explore-toggler" id="exploreMenuToggler" type="button"><i class="icon icon-candybox"></i></button>
        </div>

        <!-- mobile seach part start -->
        <button class="mobile-hide-search-icon d-block" id="show-hidden-menus" type="button" data-toggle="collapse"
            data-target="collapse-search">
            <i class="fas fa-search" aria-hidden="true"></i>
        </button>
        <div class="col-12 p-0 searchy bg-white">
            <div class="col-lg-12 hidden-menu" style="display: none !important;float: right">
                <form action="<?php echo site_url(); ?>/encyclopedia-search/" method="get">
                    <div class="input-group mb-lg-4 d-flex flex-row flex-wrap justify-content-end">
                        <input type="text" name="result" class="form-control search-field font-lato"
                            placeholder="Search over 10,000 years of art history" id="adv_searchmobile" minlength="4">
                        <div class="input-group-append">
                            <a href="<?php echo site_url(); ?>/encyclopedia-search/"
                                class="btn btn-success font-lato color-000000"><img
                                    src="<?php echo get_template_directory_uri(); ?>/images/close-icon.png"></a>
                        </div>
                        <div id="search_listingmobile" class="autocomplete-box">
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- mobile seach part ends -->

    </nav>


    <!-- explore mega menu -->
    <div class="menu_overlay explore-menu" id="exploreMenu">
        <div class="menu-wrap">
            <?php 
            wp_nav_menu(
                array(
                'theme_location' => 'explore-menu', 
                'menu_class' => 'list', 
                'container' => ''
            ));
            ?>
        </div>
    </div>

    <!-- Collapsible content -->
    <div class="main-menu" id="mainMenu">
        <div class="menu-wrapper">
            <div class="row">
                <div class="col-12 px-none">
                <?php wp_nav_menu(array('theme_location' => 'menu-1', 'menu_class' => 'navbar-nav text-lg-center', 'container' => '')); ?>
                </div>
                <div class="col-md-6 d-none">
                    <div class="menu-image">
                        <img src="<?php the_field('menu_banner_image', 'option'); ?>">
                    </div>
                </div>
                <div class="col-md-3 d-none"></div>
            </div>
        </div>
        <div class="menu-footer-wrapper">
            <div class="row">
                <div class="col-12">
                    <ul class="social-icon pl-0">
                        <li>
                            <a href="<?php the_field('instagram_link', 'option'); ?>" target="_blank">
                                <span class="icon-ins mr-1"><i class="icon icon-instagram"></i></span>
                                <span class="label-ins"> <?php the_field('instagram_text', 'option'); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-6 d-none">
                    <div class="footer-content-middle">
                        <p><?php the_field('menu_footer_content', 'option', false, false); ?><i class="icon icon-arrow-right"></i></p>
                    </div>
                </div>
                <div class="col-md-3 d-none">
                    <div class="designedby">
                        <p><?php the_field('designed_by_text', 'option'); ?> <img src="<?php the_field('designed_by_image', 'option'); ?>"></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Collapsible content -->

    <div class="container dummy-container">
        <div class="row">
            <div class="col-md-6"></div>
        </div>
    </div>
</div>
<!--/.Navbar-->