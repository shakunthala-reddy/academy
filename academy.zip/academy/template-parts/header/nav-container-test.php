<!--Navbar-->
<div class="headertop_wrap">
    
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="left px-0">
                        <!-- Collapse button -->
                        <button class="navbar-toggler" type="button" id="navbarToggler" data-target="#mainMenu">
                            <i class="icon icon-menu"></i>
                        </button>
                        <!-- Navbar brand -->
                        <a class="navbar-brand" href="<?php echo home_url(); ?>">
                            <span class="text-bold">MAP</span>
                            ACADEMY
                        </a>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group has-search m-0">
                        <div class="center-section">
                            <form action="<?php echo site_url(); ?>/encyclopedia-search/" method="get">
                                <div class="search-input">
                                    <a href="" target="_blank" hidden></a>
                                    <i class="icon icon-search form-control-feedback search-icn-black"></i>
                                    <span class="clearable">
                                        <input type="text"  name="result" class="form-control desktp-search-box"
                                            placeholder="Search over 10,000 years of art history" id="adv_search" minlength="4"
                                            value="<?php if($_GET['result']){ echo $_GET['result']; } ?>" autocomplete="off">
                                        <span class="clear-lable"><i class="clearable__clear">&times; Clear</span></i>
                                    </span>
                                    <div id="search_listing" class="autocomplete-box">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="d-none d-lg-flex flex-row align-items-center justify-content-end right px-0">
                           <button class="header-subscribe px-3 py-1" data-toggle="modal" data-target="#subscribeModal" >Subscribe</button>
                        <button class="explore-toggler" id="exploreMenuToggler" type="button">
                            <i class="icon icon-candy-box"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        

        

        <!-- mobile seach part start -->
        <button class="mobile-hide-search-icon d-block d-none" id="show-hidden-menus" type="button" data-toggle="collapse"
            data-target="collapse-search">
            <i class="fas fa-search" aria-hidden="true"></i>
        </button>
        <div class="col-12 p-0 searchy bg-white">
            <div class="col-lg-12 hidden-menu" style="display: none !important;float: right">
                <form action="<?php echo site_url(); ?>/encyclopedia-search/" method="get">
                    <div class="input-group mb-lg-4 d-flex flex-row flex-wrap justify-content-end">
                        <input type="text" name="result" class="form-control search-field font-lato"
                            placeholder="Search over 10,000 years of art history" id="adv_searchmobile" minlength="4">
                        <div class="input-group-append">
                            <a href="<?php echo site_url(); ?>/encyclopedia-search/"
                                class="btn btn-success font-lato color-000000"><img
                                    src="<?php echo get_template_directory_uri(); ?>/images/close-icon.png"></a>
                        </div>
                        <div id="search_listingmobile" class="autocomplete-box">
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- mobile seach part ends -->

   


    <!-- explore mega menu -->
    <div class="menu_overlay explore-menu" id="exploreMenu">
        <div class="menu-wrap">
            <?php 
            wp_nav_menu(
                array(
                'theme_location' => 'explore-menu', 
                'menu_class' => 'list', 
                'container' => ''
            ));
            ?>
        </div>
    </div>

    <!-- Collapsible content -->
    <div class="main-menu" id="mainMenu">
        <?php wp_nav_menu(array('theme_location' => 'menu-1', 'menu_class' => 'navbar-nav text-lg-center', 'container' => '')); ?>
        <ul class="social-icon pl-0">
            <li>
                <a href="">
                    <span class="icon-ins mr-1"><i class="fab fa-instagram"></i></span>
                    <span class="label-ins"> Find us on instagram</span>
                </a>
            </li>
        </ul>
    </div>
    <!-- Collapsible content -->

    <div class="container dummy-container">
        <div class="row">
            <div class="col-md-6"></div>
        </div>
    </div>
</div>
<!--/.Navbar-->


<style>
    button#exploreMenuToggler {
        margin-left: 40px;
        border: none;
        background: transparent;
    }
    #exploreMenuToggler i.icon.icon-candy-box {
        margin-top: 5px;
        width: 36px;
        height: 36px;
        padding: 7px 10px;
        border-radius: 50px;
    }
    i.icon.icon-candy-box:hover {
        background: #f1f1f1;
    }
    button#navbarToggler {
        display: contents;
    }
    .headertop_wrap {
        background: #fff;
        padding: 4px 0px;
    }
    i.icon.icon-menu {
        width: 36px;
        height: 36px;
        padding: 7px 10px;
        border-radius: 50px;
        margin-right: 5px;
    }
    i.icon.icon-menu:hover {
        background: #f1f1f1;
    }
    .center-section {
        padding-top: 5px;
    }
    .icon-candy-box:before {
        position: relative;
        top: 2px;
    }
    .icon-menu:before {
        position: relative;
        top: 2px;
    }
    header .explore-menu, header .main-menu {
        position: fixed;
        top: 49px;
    }
</style>