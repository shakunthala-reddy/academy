<?php
/*
* Related Content
*/
?>
<?php
$current_post_id = get_the_ID();
$current_post_type =  get_post_type($current_post_id);
?>

<div class="related-content-wrapper">
    <?php if($current_post_type=='post'){ ?>
    <h3>Elsewhere on the blog…</h3>
    <?php } elseif($current_post_type=='cluster') {?>
    <h3>Discover more Clusters…</h3>
    <?php } else {?>
    <h3>Elsewhere on the Encyclopedia…</h3>
    <?php } ?>
    <div class="related-content">
        <?php
        $args = array(
            'post_type'     => $current_post_type,
            'post_status'   => 'publish',
            'orderby'       => 'rand',
            'posts_per_page' => 4,
            'post__not_in'  => array($current_post_id),
            'tax_query'     => array(
                array(
                    'taxonomy' => 'department',
                    'field' => 'slug',
                    'operator' => 'EXISTS',
                ),
            ),
        );
        $relate_loop = get_posts($args);
        if (!empty($relate_loop)) :
            foreach ($relate_loop as $rp) :
                $post_perma = get_the_permalink($rp->ID);
                $post_title = get_the_title($rp->ID);
                $post_thumb = get_the_post_thumbnail_url($rp->ID, 'thumbnail');
                $clsimage_mid = get_post_thumbnail_id($rp->ID);
                $clsimage_malt = get_post_meta($clsimage_mid, '_wp_attachment_image_alt', TRUE);
         
        ?>
                <div class="row related-card">
                    <div class="col-3">
                        <div class="thumb">
                            <a href="<?php echo $post_perma; ?>" class="d-block">
                                <figure class="mb-0">
                                    <?php
                                    if ($post_thumb) {
                                        $thumb_url = get_the_post_thumbnail_url($rp->ID, 'thumbnail');
                                    } else {
                                        $thumb_url = get_field('default_thumbnail', 'option');
                                    }
                                    ?>
                                    <img src="<?php echo $thumb_url; ?>" alt="<?php echo $clsimage_malt; ?>" class="img-fluid">
                                </figure>
                            </a>
                        </div>
                    </div>
                    <div class="col-9">
                        <div class="summary">
                            <a href="<?php echo $post_perma; ?>" class="d-block">
                                <h6 class="mb-0"><?php echo $post_title; ?></h6>
                                <?php
                                $content=$rp->post_content;
                                $pattern = "/(\[)(.*?)(\])/";
                                $content = preg_replace($pattern, '', $content);
                                $content=wp_strip_all_tags(wp_trim_words($content, 15, null));

                                ?>
                                <p class="mb-0"><?php echo $content ?></p>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="row no-gutters related-card d-none">
                    <div class="related-thumb col-auto">
                        <a href="<?php the_permalink(); ?>">
                            <figure class="mb-0">
                                <?php
                                if ($post_thumb) {
                                    $thumb_url = get_the_post_thumbnail_url($rp->ID, 'thumbnail');
                                } else {
                                    $thumb_url = get_field('default_thumbnail', 'option');
                                }
                                ?>
                                <img src="<?php echo $thumb_url; ?>" alt="<?php echo $clsimage_malt; ?>" class="img-fluid">
                            </figure>
                        </a>
                    </div>
                    <div class="related-body col">
                        <h6><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h6>
                        <p class="mb-0"><?php echo wp_strip_all_tags(wp_trim_words($rp->post_content, 15, null)); ?></p>
                    </div>
                </div>
        <?php
            endforeach;
        endif;
        ?>
    </div>
</div>

<script>
    var page_article_desk = 1,
        article_added = false;
    jQuery(function($) {
        $(window).on("scroll", function() {

            if (page_article_desk < $('.article-post').length) {
                page_article_desk = $('.article-post').length;
                article_added = true;
                relatedContentPosition();
            } else {
                article_added = false;
            }
        });
    });


    jQuery(document).ready(function($) {
        relatedContentPosition();
    });

    /* Related Content Position function */
    function relatedContentPosition() {

        setTimeout(() => {
            $('.article-post').each(function(i, elem) {
                let mainContent = $(this).find('.content-section'),
                    mainContentPositionTop = $(this).find('.content-section').position().top,
                    mainContentSize = mainContentPositionTop + mainContent.height(),
                    fullSliderContent = $(this).find('.carousel-left-content-full-image'),
                    fullSliderContentTop = fullSliderContent.length > 0 ? fullSliderContent.position().top - mainContentPositionTop : 0,
                    fullSliderContentSize = fullSliderContentTop + fullSliderContent.height(),
                    fullSliderOffset = fullSliderContent.length > 0 ? fullSliderContent.position().top - mainContentPositionTop : 0,
                    relatedContent = $(this).find('.related-content-wrapper'),
                    relatedContentSize = relatedContent.position().top + relatedContent.height(),
                    topRightSliderContent = $(this).find('.carousel-right-below-extended'),
                    topRightSliderContentSize = topRightSliderContent.length > 0 ? topRightSliderContent.position().top + topRightSliderContent.height() : 0,
                    centerSliderMeta = $(this).find('.carousel-center-extended-meta'),
                    centerSliderMetaSize = centerSliderMeta.length > 0 ? centerSliderMeta.position().top + centerSliderMeta.height() : 0,
                    relatedContPositionTop = 0;
                    relatedContPosition = 'relative';

                if (fullSliderContent.length > 0) {
                    if (fullSliderOffset < relatedContent.position().top || fullSliderOffset < relatedContentSize) {
                        relatedContPosition = 'absolute';
                        relatedContPositionTop = fullSliderContentSize;
                    }
                    if (centerSliderMeta.length > 0 && (fullSliderContentSize + relatedContent.height()) > centerSliderMeta.position().top) {
                        relatedContPositionTop = centerSliderMetaSize;
                        relatedContPosition = 'absolute';
                    }
                    relatedContentSize = relatedContPositionTop + relatedContent.height();
                }

                if (centerSliderMeta.length > 0) {
                    if (relatedContentSize > centerSliderMeta.position().top) {
                        relatedContPositionTop = centerSliderMetaSize;
                        relatedContPosition = 'absolute';
                    }
                }

                if (relatedContentSize > mainContentSize) {
                    relatedContent.css({
                        display: 'none'
                    });
                }

                relatedContent.css({
                    position: relatedContPosition,
                    top: relatedContPositionTop + 30 + 'px'
                });
            });
        }, 200);
    }
</script>