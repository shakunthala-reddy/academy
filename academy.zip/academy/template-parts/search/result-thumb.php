<?php
$query = new WP_Query($args);
if ($query->have_posts()) {
    while ($query->have_posts()) {
        $query->the_post();

        $postType = get_post_type();
        if ($postType == 'post') {
            $postType = 'blog';
        }
        $post_id = $post->ID;

        ?>

        <div class="row result-subbox">
            <div class="print-section-cluster" id="p-<?php echo $post_id; ?>">
                <div class="w-100">
                    <h5 class="result-label-title <?= $postType ?>"><?= $postType ?></h5>
                </div>
                <a href="<?php echo get_permalink() ?>"><h4><?php the_title(); ?></h4></a>
                <div class="row">
                    <div class="col no-padding-mobile">
                        <div class="media">
                            <?php
                            $image_mid = get_post_thumbnail_id($post->ID);
                            $image_malt = get_post_meta($image_mid, '_wp_attachment_image_alt', TRUE);
                        
                            if (get_the_post_thumbnail_url()) {
                                $thumb_url = get_the_post_thumbnail_url($post_id, 'thumbnail');
                            } else {
                                $thumb_url = get_field('default_thumbnail', 'option');
                            }
                            ?>

                            <img src="<?= $thumb_url ?>" class="mr-3 img-fluid" alt="<?php echo $image_malt; ?>">


                            <div class="media-body">
                                <?php
                                $content=wp_trim_words(get_post_field('post_content'), 38);
                                $pattern = "/(\[)(.*?)(\])/";
                                $content = preg_replace($pattern, '', $content);
                                ?>
                                <p class="photograph-descriptionsearch "><?php echo $content ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        

    <?php } ?>

<?php } else { ?>
    <script>
        runAjax = false;
        $(".filter-feedback").hide();
    </script>
    <div class="row no-more">
        <div class="col-4 pl-0 pr-0 pt-2">
            <div class="line"></div>
        </div>
        <div class="col-4 pl-0 pr-0 text-center">No more results.</div>
        <div class="col-4 pl-0 pr-0 pt-2">
            <div class="line"></div>
        </div>
    </div>

<?php }

wp_reset_postdata(); ?>



