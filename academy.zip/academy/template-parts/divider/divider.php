<?php 
/*
* Divider
*/
?>
<div class="divider-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="divider">
                    <span></span>
                    <span>Related Content</span>
                    <span></span>
                </div>
            </div>
        </div>
    </div>
</div>