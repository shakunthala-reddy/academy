<?php
$current_post_id = get_the_ID();
?>
<article class="blog-post article-post" id="p-<?php echo $current_post_id; ?>">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12"></div>
            <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                <div class="label-section">
                    <h5 class="label-title blog"><a href="<?php the_permalink(15); ?>">BLOG</a></h5>
                    <h2 class="phtograph-heading"><?php the_title(); ?></h2>
                    <?php
                        get_template_part('/template-parts/author/author-details');
                    ?>
                </div>
            </div>
            <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12"></div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 order-1 order-md-0">
                <aside class="left-sidebar">
                    <div class="author-details">
                        <div class="wrap-filed-info">
                            <p class="filed-under-lable">FILED UNDER</p>
                            <p class="under-listing">
                                <?php
                                $filed_taxterms = get_the_terms( get_the_ID(), 'department' );
                                foreach($filed_taxterms as $filed_list){ ?>
                                    <a href="<?php echo home_url(); ?>/encyclopedia-search/?&department=<?php echo $filed_list->slug; ?>"><?php echo $filed_list->name;
                                        ?>
                                    </a>
                                <?php } ?>
                            </p>
                            <p class="first-published">FIRST PUBLISHED</p>
                            <p class="published-date"><?php the_time('F j, Y'); ?></p>
                        </div>
                    </div>
                    <?php
                        get_template_part('/template-parts/social-icon/social-icon');
                    ?>
                    <div class="left-content"></div>
                </aside>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 initial-content-box">
                <div class="main-content-area">
                    <div class="content-section ">
                        <?php
                        the_content();
                        ?>
                    </div>

                </div>
            </div>
            <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
                <aside class="right-sidebar d-none d-lg-block">
                    <div class="right-section"></div>
                    <?php
                    get_template_part('/template-parts/related-content/related-content');
                    ?>
                </aside>
            </div>
        </div>
    </div>
</article>
<?php
    get_template_part('/template-parts/divider/divider');
?>