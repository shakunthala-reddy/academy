<?php

$excludedArticlePosts = $_POST['excludedArticlePosts'];
$excludedBlogPosts = $_POST['excludedBlogPosts'];

$query = new WP_Query($args);
if ($query->have_posts()) {
    while ($query->have_posts()) {
        $query->the_post();

        ?>

        <?php
        get_template_part('/template-parts/blog/blog-section');
        ?>
        <?php
        $counter = $_POST['counter'];
        $current_post_id = get_the_ID();

        if ($counter == 3) {
            $tax = 'custom_category';
            $counter = 0;

           ?>

                <section class="blog-section one-col-section article-listing d-none d-lg-block">
                    <div class="container">

                        <div class="row">
                            <?php
                            wp_reset_query();
                            $terms = get_the_terms($current_post_id, $tax);
//                                    shuffle($terms);
                            $term_slug = $terms[0]->slug;
                            $tax_query = [
                                'taxonomy' => $tax,
                                'field' => 'slug',
                                'terms' => $term_slug
                            ];
                            $args3 = array(
                                'post_type' => 'article',
                                'posts_per_page' => 4,
                                'post__not_in' => $excludedArticlePosts,
                                'tax_query' => $tax_query,
                            );
//                            $postCountQuery3 = new WP_Query($args3);
//                            $postCount3 = $postCountQuery3->found_posts;
//                            if ($postCount3 < 4) {
////                                $excludedArticlePosts = [];
//                                $args3 = array(
//                                    'post_type' => 'article',
//                                    'posts_per_page' => 4,
//                                    'post__not_in' => $excludedArticlePosts,
//                                    'tax_query' => $tax_query,
//                                );
//                            }

                            $query3 = new WP_Query($args3);
                            if ($query3->have_posts()):
                                while ($query3->have_posts()): $query3->the_post();
                                    $mycontent = $post->post_content; // wordpress users only
                                    $word = str_word_count(strip_tags($mycontent));
                                    $m = floor($word / 200);
                                    $s = floor($word % 200 / (200 / 60));
                                    $est = $m . 'min' . ($m == 1 ? '' : 's');
                                    ?>

                                    <script>
                                        var currentPostID =<?=get_the_ID() ?>;
                                        WP_URLS.excluded_article_posts.push(currentPostID);
                                    </script>


                                    <div class="col-lg-3 col-6 mb-0">
                                        <?php
                                         $image_mid = get_post_thumbnail_id($post->ID);
                                         $image_malt = get_post_meta($image_mid, '_wp_attachment_image_alt', TRUE);
                                  
                                        if (get_the_post_thumbnail_url($post->ID)) {
                                            $thumb_url = get_the_post_thumbnail_url($post->ID,'thumbnail');
                                        } else {
                                            $thumb_url = get_field('default_thumbnail', 'option');
                                        }
                                        ?>
                                        <a href="<?php the_permalink(); ?>"><img
                                                    src="<?php echo $thumb_url; ?>"
                                                    class="img-responsive" alt="<?php echo $image_malt; ?>"></a>
                                        <div class="blog-part">
                                            <p class="blog-lable">Article</p>
                                            <div class="article-summary-wrap">
                                                <a class="article-title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                                <p class="article-description"><?php echo wp_strip_all_tags(get_the_content()); ?></p>
                                            </div>
                                            <div class="col-12 p-0 double-part d-flex flex-row flex-wrap justify-content-between">
                                                <div class="read-more p-0"><a href="<?php the_permalink(); ?>">Read
                                                        More</a></div>
                                                <div class="read-time p-0"><?php //echo $est; ?> </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; endif;
                            wp_reset_query(); ?>
                        </div>
                    </div>
                </section>
            <div class="container">

                        <ul class="d-block d-lg-none p-0">
                            <?php
                            $terms = get_the_terms($current_post_id, $tax);
                            //                                    shuffle($terms);
                            $term_slug = $terms[0]->slug;
                            $tax_query = [
                                'taxonomy' => $tax,
                                'field' => 'slug',
                                'terms' => $term_slug
                            ];
                            $args3 = array(
                                'post_type' => 'article',
                                'posts_per_page' => 4,
                                'post__not_in' => $excludedArticlePosts,
                                'tax_query' => $tax_query,
                            );
                            $postCountQuery3 = new WP_Query($args3);
                            $postCount3 = $postCountQuery3->found_posts;
                            if ($postCount3 < 4) {
                                $excludedArticlePosts = [];
                                $args3 = array(
                                    'post_type' => 'article',
                                    'posts_per_page' => 4,
                                    'post__not_in' => $excludedArticlePosts,
                                    'tax_query' => $tax_query,
                                );
                            }

                            $query3 = new WP_Query($args3);
                            if ($query3->have_posts()):
                                while ($query3->have_posts()): $query3->the_post();
                                    $mycontent = $post->post_content; // wordpress users only
                                    $word = str_word_count(strip_tags($mycontent));
                                    $m = floor($word / 200);
                                    $s = floor($word % 200 / (200 / 60));
                                    $est = $m . 'min' . ($m == 1 ? '' : 's');
                                    $image_mid = get_post_thumbnail_id($post->ID);
                                    $image_malt = get_post_meta($image_mid, '_wp_attachment_image_alt', TRUE);
                             
                                    if (get_the_post_thumbnail_url($post->ID)) {
                                        $thumb_url = get_the_post_thumbnail_url($post->ID, 'thumbnail');
                                    } else {
                                        $thumb_url = get_field('default_thumbnail', 'option');
                                    }
                                    ?>
                                    <li class="media list-view">
                                        <a href="<?php the_permalink(); ?>">
                                            <img src="<?php echo $thumb_url; ?>" class="art-img" alt="<?php echo  $image_malt; ?>">
                                        </a>
                                        <div class="media-body">
                                            <h5 class="mt-0"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                            <p class="pb-2"><?php
                                                $content = wp_trim_words(get_post_field('post_content'), 15);
                                                $pattern = "/(\[)(.*?)(\])/";
                                                $content = preg_replace($pattern, '', $content);
                                                echo $content;
                                                ?></p>

                                            <hr class="hr-border mt-4">
                                        </div>
                                    </li>
                                    <?php wp_reset_postdata(); endwhile; endif; ?>

                        </ul>

            </div>

                <?php
                    get_template_part('/template-parts/divider/divider');
                ?>

            <?php

        }
        $counter++;

        ?>

        <script>
            WP_URLS.counter =<?=$counter ?>;
            var currentPostID =<?=$current_post_id ?>;
            WP_URLS.current_post_id = currentPostID;
            WP_URLS.excluded_blog_posts.push(currentPostID);
            console.log(WP_URLS.excluded_blog_posts);
        </script>


    <?php } ?>

<?php } else { ?>
    <script>
        runAjax = false;
    </script>
    <div class="row no-more">
        <div class="col-4 pl-0 pr-0 pt-2">
            <div class="line"></div>
        </div>
        <div class="col-4 pl-0 pr-0 text-center">No more results.</div>
        <div class="col-4 pl-0 pr-0 pt-2">
            <div class="line"></div>
        </div>
    </div>

<?php }

wp_reset_postdata();
